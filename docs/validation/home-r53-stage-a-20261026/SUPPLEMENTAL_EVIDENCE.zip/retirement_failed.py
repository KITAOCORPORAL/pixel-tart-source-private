from pathlib import Path
import xml.etree.ElementTree as E
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
for label in ['core','wpf']:
 p=Path('N:/pixart/Guangjing-R53-Home-20261026/retirement-development')/label/'results.trx';root=E.parse(p)
 for x in root.findall('t:Results/t:UnitTestResult',ns):
  if x.attrib['outcome']=='Failed':
   m=x.find('.//t:Message',ns);print(label,x.attrib['testName'],(m.text if m is not None else '')[-650:])