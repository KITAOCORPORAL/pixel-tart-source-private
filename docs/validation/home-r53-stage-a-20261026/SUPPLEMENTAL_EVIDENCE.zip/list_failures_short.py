from pathlib import Path
import xml.etree.ElementTree as E
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};p=Path('N:/pixart/Guangjing-R53-Home-20261026/retirement-development/wpf/results.trx');doc=E.parse(p)
for x in doc.findall('t:Results/t:UnitTestResult',ns):
 if x.attrib['outcome']=='Failed':
  m=x.find('.//t:Message',ns);print(x.attrib['testName'],repr((m.text if m is not None else '')[-190:]))