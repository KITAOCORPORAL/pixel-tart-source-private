from pathlib import Path
import re
r=Path('N:/pixart/guangjing-r53-stage-a-20261026')
for p in (r/'src').rglob('*'):
 if not p.is_file() or p.suffix not in ['.cs','.xaml','.resx','.json'] or any(x in p.parts for x in ['obj','bin']):continue
 s=p.read_text(encoding='utf-8-sig')
 if p.suffix=='.cs':
  for i,line in enumerate(s.splitlines(),1):
   if line.lstrip().startswith('//'):continue
   for literal in re.findall(r'"(?:[^"\\]|\\.)*"',line):
    if re.search(r'PixelTart|Pixel Tart|像素蛋挞',literal,re.I):print(str(p.relative_to(r))+':'+str(i),literal[:190])