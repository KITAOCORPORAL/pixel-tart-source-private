from pathlib import Path
import xml.etree.ElementTree as E,re,json
r=Path('N:/pixart/guangjing-r53-stage-a-20261026');found=[];visible={'Title','Text','Content','Header','ToolTip','Name','HelpText','AutomationName','ToolTipText','AutomationProperties.Name','AutomationProperties.HelpText','Watermark'}
for p in (r/'src').rglob('*.xaml'):
 if any(x in p.parts for x in ['obj','bin']):continue
 root=E.parse(p).getroot()
 for node in root.iter():
  for key,value in node.attrib.items():
   name=key.split('}')[-1]
   if name not in visible or value.startswith('{'):continue
   if re.search(r'Pixel\s*Tart|像素蛋挞',value,re.I):found.append(dict(path=str(p.relative_to(r)),attribute=name,value=value))
print(json.dumps(found,ensure_ascii=False,indent=2))