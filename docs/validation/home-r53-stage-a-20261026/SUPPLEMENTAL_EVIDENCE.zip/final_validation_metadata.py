from pathlib import Path
import subprocess,json,xml.etree.ElementTree as E,re,hashlib,shutil,datetime
r=Path('N:/pixart/guangjing-r53-stage-a-20261026');o=Path('N:/pixart/Guangjing-R53-Home-20261026');v=r/'docs/validation/home-r53-stage-a-20261026';pkg=o/'Guangjing-R53-StageA-TutorialRetired-Diagnostic-win-x64';sha='901061433ce56dbb85e49ff5cc8c95ecd82760fe';ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def js(name,data): (v/name).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
def h(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
# Archive was sealed after final test completion. Separate explicit summary for distinct startup runs.
rows=[]
for scenario in ['first','upgrade','restart']:
 f=o/'retirement-fullapp-final-r10'/scenario;process=json.loads((f/'process.json').read_text());result=json.loads((f/'RESULT.json').read_text());doc=E.parse(f/'results.trx');assert process['exitCode']==0;assert doc.find('t:ResultSummary/t:Counters',ns).get('passed')=='1';rows.append(dict(scenario=scenario,process=process,result=result,trxSha256=h(f/'results.trx')))
js('FULL_APP_STARTUP_CASES.json',dict(sourceSha=sha,passed=3,failed=0,notRun=0,separateProcesses=True,notPhysicalMouse=True,cases=rows))
# Prepared session only changes the provided synthetic image's path, preserving exact date strings/identity.
a=json.loads((o/'final-r10/samples/r53-stage-a.ptstudio.json').read_text(encoding='utf-8'));b=json.loads((o/'prepared-sample-final-r10/r53-stage-a.ptstudio.json').read_text(encoding='utf-8'));assert Path(b['targets'][0]['path']).is_file();a['targets'][0]['path']=b['targets'][0]['path'];assert a==b
js('SAMPLE_REBIND.json',dict(scriptExecuted=True,powershellVersion='7.6',requires='7.5 or later -DateKind String',path=str(o/'prepared-sample-final-r10/r53-stage-a.ptstudio.json'),onlyPathChanged=True,sourceIdentityRetained=True,nativeOpenNotRun=True))
# Visible XML attributes, translation values and installer display names. Internal names/path keys documented separately.
old=re.compile(r'像素蛋挞|Pixel\s*Tart',re.I);attrs={'Title','Text','Content','Header','ToolTip','AutomationProperties.Name','AutomationProperties.HelpText','AutomationName','ToolTipText'};findings=[];xmlCount=0
for p in (r/'src').rglob('*.xaml'):
 if any(x in p.parts for x in ['obj','bin']):continue
 xmlCount+=1
 for n in E.parse(p).getroot().iter():
  for key,value in n.attrib.items():
   if key.split('}')[-1] in attrs and not value.startswith('{') and old.search(value):findings.append(dict(file=str(p.relative_to(r)),value=value))
translationCount=0
for p in (r/'src/RAWSelectionAssistant/Resources/Studio').glob('*.json'):
 for key,value in json.loads(p.read_text(encoding='utf-8-sig')).items():
  translationCount+=1
  if isinstance(value,str) and old.search(value):findings.append(dict(file=str(p.relative_to(r)),key=key,value=value))
installer=[]
for p in (r/'installer').glob('*.iss'):
 for line in p.read_text(encoding='utf-8-sig').splitlines():
  if re.search(r'像素蛋挞|Pixel Tart',line,re.I) and not line.startswith(';'):
   installer.append(dict(file=str(p.relative_to(r)),line=line,boundary='retained compatibility install path' if line.startswith('DefaultDirName=') else 'unexpected'))
assert not findings;assert all(x['boundary'].startswith('retained') for x in installer)
js('BRAND_AUDIT.json',dict(sourceSha=sha,xamlFiles=xmlCount,translationValues=translationCount,visibleFindings=findings,installerLegacyPaths=installer,internalNamesPreserved=['assembly names','namespaces','PixelTart resource keys','legacy translation keys','drag formats','DB and migration paths','proof salt','old file metadata'],notRewritten=['user-authored project/watermark titles','existing photo metadata','historical documentation'],installerBuilt=False,rootCause='Hardcoded old tutorial welcome/upgrade/help and other visible literals bypassed Branding.ProductName; startup still active for new profiles'))
js('DESKTOP_STATUS.json',dict(sourceSha=sha,nativeExeStartup='PASS_PROCESS_IDENTITY_ONLY',nativeExeSameRootRestart='PASS_PROCESS_IDENTITY_ONLY',nativeEditSaveExportMouse='NOT_RUN',nativeDpi100125150='NOT_RUN',screenshots='OFFSCREEN_WPF_ONLY',fullAppFirstUpgradeRestart='PASS_AUTOMATED_IN_PROCESS_COMPOSITION_DISTINCT_TESTHOSTS',restriction='User global AGENTS prohibits Computer Use, Browser, WebView/CDP; not re-enabled',priorDiscoveryError='unsupported custom tool call: exec',priorErrorScope='Earlier same-batch discovery error, not a native product click failure',manual='MANUAL_RETEST.md',stepsNotRun=['planning package import/list/JPEG/shot/preview','shot external import owned','simple-professional-save-mouse-restart-export','rapid A/B physical UI','15-section summary physical export','other isolated root package import physical'],noScreenshotClaim=True))
# Stage matrix, not an inflated completion claim.
js('STAGE_MATRIX.json',dict(A=dict(status='PARTIAL',implemented=['shared editor and serial stack across modes','variant stable IDs original/main/rating/label','user/system lock mutation guards','confirm archive and session undo deletion','900ms existing-path autosave and close flush/concurrency protection','DIP responsive layout; wide dedicated 3D region; narrow explicit focus view','B brush-only and backslash compare with held compare release'],partial=['resource/filter/instant arrangement','serial node selection/right parameters','variant filmstrip expansion','3D existing real-image cloud reuse'],notImplemented=['real local brush/eraser mask and persisted mask undo','generic blend/opacity engine','2-4 variants synchronized pan/zoom comparison','physical DPI and pointer acceptance','full R5.3 polish/scopes/collage frozen update lifecycle']),B=dict(status='NOT_STARTED_THIS_BATCH',scope='existing math retained, no scientific improvement claim; no new pixel algorithms'),C=dict(status='NOT_STARTED_THIS_BATCH',scope='existing R3/V3 retained, not R53 full port; prototype175 not product results'),D=dict(status='NOT_STARTED_THIS_BATCH',scope='existing owned source validation/80ms merge kept; .ptplan v1 excludes canvas'),E=dict(status='NOT_STARTED_THIS_BATCH',scope='all existing15 planning sections kept, no R53 full cross-module claim'),addition=dict(status='PRODUCT_COMPLETE_AUTOMATED_VERIFIED',nativeAcceptance='NOT_RUN',scope='retired old tutorial/no private data cleanup; visible branding updated; new guide deferred')))
js('RELEASE_GATE.json',dict(sourceSha=sha,diagnosticOnly=True,isInstaller=False,releaseAllowed=False,reason=['R53 Stage A partial','native physical UI/DPI not executed','authorized RAW corpus opt-in missing','B/C/D/E not implemented this batch'],algorithmChange=False,pv4pv5pv6MathChanged=False,metadataOnlyBrandChanges=['TIFF Software','JPEG ApplicationName','LUT comment'],legacyProjectSessionVersion=1,legacyStackVersion=2,additiveState=True,ptplanCanvasIncluded=False,thirdPartyDesignResourcesShipped=False))
# Raw wide static failure boundaries, no old failure erased.
js('DEVELOPMENT_FAILURES_NOTE.json',dict(raw='RAW_EVIDENCE.zip',retainedRuns=['affected-development','scoped-r6','safety-before','safety-before-r2','retirement-development','retirement-development-r2','final-r8 build','final-r9 core'],resolved=['initial initialization null','panel Tag','original/main migration identity','legacy locked look mutation','test fixture no valid reference','missing XML test extension','old theme assertion'],remainingWideStaticFailures=['2 finance text literal assertions','3 document panel literal assertions','2 tether literal assertions'],remainingWideScope='7 unchanged old copy mirrors from broad Version230 fixture, not current product/runtime failure; raw 7 failures retained; no business safety assertions removed',latestBoundedFailures=0,notCountedAsPass=True))
# Final package evidence documents copied only after sealing report later.
print(json.dumps(dict(fullAppCases=len(rows),visibleXaml=xmlCount,visibleOldBrandFindings=len(findings),translationValues=translationCount,dependencies=264),indent=2))