from pathlib import Path
import json,xml.etree.ElementTree as ET,hashlib,zipfile
r=Path('N:/pixart/guangjing-r53-stage-a-20261026');v=r/'docs/validation/home-r53-stage-a-20261026';o=Path('N:/pixart/Guangjing-R53-Home-20261026');ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
s={}
for label in ['core','wpf']:
 root=ET.parse(o/f'final-r6/tests-{label}/results.trx');counts=root.find('t:ResultSummary/t:Counters',ns).attrib;results=root.findall('t:Results/t:UnitTestResult',ns)
 s[label]=dict(total=len(results),passed=sum(x.attrib['outcome']=='Passed' for x in results),failed=sum(x.attrib['outcome']=='Failed' for x in results),notRun=sum(x.attrib['outcome']=='NotExecuted' for x in results),sourceSha='592ecccb5e71d2a798a52196110717c936d0566f',counters=counts,notes='NotExecuted counted from UnitTestResult; TRX aggregate notExecuted can be zero; individual UnitTestResult outcome is authoritative for omitted tests')
(v/'TEST_SUMMARY.json').write_text(json.dumps(s,indent=2),encoding='utf-8')
p=o/'collect_delivery_evidence.py';text=p.read_text(encoding='utf-8').replace("notRun=int(c['notExecuted'])","notRun=sum(x.attrib['outcome']=='NotExecuted' for x in doc.findall('t:Results/t:UnitTestResult',ns))");p.write_text(text,encoding='utf-8')
# Validate prepared synthetic session references and paths without changing source sample evidence.
p=o/'prepared-sample-r6b/r53-stage-a.ptstudio.json';doc=json.loads(p.read_text(encoding='utf-8-sig'));assert Path(doc['targets'][0]['path']).is_file();original=json.loads((o/'final-r6/samples/r53-stage-a.ptstudio.json').read_text(encoding='utf-8'));prepared=json.loads(p.read_text(encoding='utf-8-sig'));original['targets'][0]['path']=prepared['targets'][0]['path'];assert original==prepared
(v/'SAMPLE_REBIND.json').write_text(json.dumps(dict(scriptExecuted=True,session=str(p),onlySourcePathChanged=True,preservesStableIds=True,originalEvidenceUnchanged=True,openInNativeUI=False),indent=2),encoding='utf-8')
print(json.dumps(s,indent=2))