from pathlib import Path
import json
o=Path('N:/pixart/Guangjing-R53-Home-20261026');a=json.loads((o/'final-r6/samples/r53-stage-a.ptstudio.json').read_text());b=json.loads((o/'prepared-sample-r6/r53-stage-a.ptstudio.json').read_text(encoding='utf-8-sig'))
def walk(a,b,p=''):
 if type(a)!=type(b) and not isinstance(a,(int,float)):
  print(p,repr(a)[:90],repr(b)[:90]);return
 if isinstance(a,dict):
  for k in a:walk(a[k],b.get(k),p+'/'+k)
 elif isinstance(a,list):
  for i,(x,y) in enumerate(zip(a,b)):walk(x,y,p+'/'+str(i))
 elif a!=b:print(p,repr(a)[:90],repr(b)[:90])
walk(a,b)