from pathlib import Path
r=Path.cwd()/'guangjing-r53-stage-a-20261026';p=r/'src/RAWSelectionAssistant/Views/ReferenceColorWorkspaceView.CanvasToolbar.cs';s=p.read_text().replace('internal enum ColorStudioCanvasTool { Select, Hand, Zoom, ColorSample }','internal enum ColorStudioCanvasTool { Select, Hand, Zoom, ColorSample, Brush }');s=s.replace('if (key == Key.B) { SetCanvasOriginalHeld(true); return true; }','''if(key==Key.B){ActiveCanvasTool=ColorStudioCanvasTool.Brush;if(DataContext is ReferenceColorWorkspaceViewModel workspace)workspace.StatusText="画笔：当前局部蒙版处理未批准接入，不生成假结果。";return true;}
        if(key==Key.Oem5){ToggleCanvasOriginal();return true;}''');s=s.replace('''{ if (e.Key == Key.B && _canvasOriginalHeld) { ReleaseCanvasOriginal(); e.Handled = true; } }''','''{ /* B is brush, never a comparison hold. Mouse comparison releases via capture. */ }''');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.Versions.cs';s=p.read_text().replace('''        Editor.CopyCurrentLookTo([target]);CaptureEditVersion(target);
        target.ActiveEditVersionId=Guid.NewGuid();''','''        Editor.CopyCurrentLookTo([target]);CaptureEditVersion(target);EnsureR53Variants(target);
        target.ActiveEditVersionId=Guid.NewGuid();''');s=s.replace('''        await ActivateTargetAsync(target);StatusText="当前编辑版本："+version.Name;''','''        await ActivateTargetAsync(target);NotifyR53Variants();StatusText="当前编辑版本："+version.Name;''');# correct phantom lookup original archived
s=s.replace('''var version=target.EditVersions.SingleOrDefault(v=>v.Id==id);if(version is null)return;''','''var version=target.EditVersions.SingleOrDefault(v=>v.Id==id&&!v.Archived);if(version is null){StatusText="引用变体已删除或不可用，未替换为其他变体。";return;}''');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.R53.cs';s=p.read_text();needle='''        NotifyR53Variants();
    }
    private void NotifyR53Variants''';s=s.replace(needle,'''        Editor.ReadOnlyTarget=target.EditVersions.FirstOrDefault(v=>v.Id==target.ActiveEditVersionId)?.IsOriginal==true;
        NotifyR53Variants();
    }
    private void NotifyR53Variants''');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/ViewModels/TetherReferenceModeViewModel.cs';s=p.read_text();needle='''    private void ChangeStack(Func<IReadOnlyList<ColorAdjustmentStackNode>''';s=s.replace(needle,'''    private bool _readOnlyTarget;
    public bool ReadOnlyTarget{get=>_readOnlyTarget;set=>SetProperty(ref _readOnlyTarget,value);}
'''+needle);s=s.replace('''        _presetPreviewNode = null; NotifyPresetPreview();
        var previous = EffectiveEditingStack();''','''        if(ReadOnlyTarget){StatusText="原始变体只读，请按F2从原始新建或F3复制当前。";return;}
        _presetPreviewNode = null; NotifyPresetPreview();
        var previous = EffectiveEditingStack();''');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/Views/PhotoGradePageView.R53.cs';s=p.read_text().replace('''            if(Keyboard.Modifiers==ModifierKeys.Control&&e.Key is Key.D1 or Key.D2)''','''            if(Keyboard.Modifiers==ModifierKeys.Control&&(e.Key is Key.D1 or Key.D2))''');s=s.replace('''model.R53Professional=e.Key==Key.D2;ApplyR53Layout();e.Handled''','''model.R53Professional=e.Key==Key.D2;ApplyR53Layout();EditModes.SelectedIndex=model.R53Professional?2:0;e.Handled''');s=s.replace('''var resources=r53ResourcesRequested&&width>=1200;''','''var resources=r53ResourcesRequested&&width>=1200;''');# 3D no blank and explicit layout conflict
s=s.replace('''var cloud=new ColorSpace3DViewport{MinWidth=420,MinHeight=300,Height=340};content.Children.Add(cloud);''','''var cloud=new ColorSpace3DViewport{MinWidth=420,MinHeight=300,Height=340,DataContext=model};content.Children.Add(cloud);
        if(model.ColorSpaceModel is {} current)cloud.SetModel(current);
        var ownerModel=model;
        System.ComponentModel.PropertyChangedEventHandler update=(_,args)=>{if(args.PropertyName==nameof(ownerModel.ColorSpaceModel)&&ownerModel.ColorSpaceModel is {} changed)cloud.SetModel(changed);};
        ownerModel.PropertyChanged+=update;''');s=s.replace('''r53Inspect.Closed+=(_,_)=>r53Inspect=null;r53Inspect.Show();''','''r53Inspect.Closed+=(_,_)=>{ownerModel.PropertyChanged-=update;r53Inspect=null;};r53Inspect.Show();''');p.write_text(s,encoding='utf8')
# Direct cloud state setter invokes real graph. Keep explicit focus route until docked wide inspector finished.
# Prevent legacy Ctrl+1 zoom handler from stealing mode shortcut.
p=r/'src/RAWSelectionAssistant/Views/PhotoGradePageView.xaml.cs';s=p.read_text().replace('''   if(Keyboard.Modifiers!=ModifierKeys.Control)return;''','''   if(e.Handled||Keyboard.Modifiers!=ModifierKeys.Control)return;''').replace('''   else if(e.Key==Key.D1){PhotoViewport.State.SetZoom(1);e.Handled=true;}''','');p.write_text(s,encoding='utf8')
# Tests use actual source / editor / session store / export, not two mock models.
(r/'tests/RAWSelectionAssistant.WpfTests/R53DarkroomStageATests.cs').write_text('''using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using RAWSelectionAssistant.Core.Models;
using RAWSelectionAssistant.Core.Services.Projects;
using RAWSelectionAssistant.Services;
using RAWSelectionAssistant.ViewModels;
using RAWSelectionAssistant.Views;
using static RAWSelectionAssistant.WpfTests.RuntimeCorrectionWpfTests;
namespace RAWSelectionAssistant.WpfTests;
[TestClass][DoNotParallelize]public sealed class R53DarkroomStageATests
{
    static string Image(string root){var p=Path.Combine(root,"synthetic.png");StudioQuickExport.Encode(BitmapSource.Create(32,24,96,96,PixelFormats.Rgb24,null,Enumerable.Repeat((byte)90,32*24*3).ToArray(),32*3),p,p,StudioExportFormat.Png);return p;}
    static ColorStudioToolParameter Exposure=>ColorStudioToolCatalog.GetParameters(ColorStudioNodeType.BasicTone).Single(p=>p.Key=="exposure");
    static async Task Render(ReferenceColorWorkspaceViewModel vm){await vm.Editor.RenderAsync();await vm.AnalysisWork;}
    static byte[] Pixels(BitmapSource image){var rgb=new FormatConvertedBitmap(image,PixelFormats.Rgb24,null,0);var b=new byte[rgb.PixelWidth*rgb.PixelHeight*3];rgb.CopyPixels(b,rgb.PixelWidth*3,0);return b;}
    [TestMethod]public Task SamePhotoSimpleProfessionalSaveReopenAndExportShareDefinition()=>RunSta(async()=>
    {
        EnsureTestApplication();var root=Path.Combine(Path.GetTempPath(),"r53-shared-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);
        try{var input=Image(root);var dialogs=new Dialogs(root);using var vm=new ReferenceColorWorkspaceViewModel(dialogs);await vm.LoadTargetAsync(input);vm.Editor.SetToolParameter(Exposure,.5);await Render(vm);var selected=vm.Editor.SelectedAdjustmentNode?.Id;var definition=JsonSerializer.Serialize(vm.Editor.AdjustmentStack);var pixels=Pixels(vm.Editor.MatchedImage!);
        vm.R53Professional=true;vm.Editor.SetToolParameter(Exposure,.75);await Render(vm);vm.R53Professional=false;Assert.AreEqual(.75,vm.Editor.ToolValue(Exposure));vm.Editor.UndoAdjustmentCommand.Execute(null);await Render(vm);Assert.AreEqual(definition,JsonSerializer.Serialize(vm.Editor.AdjustmentStack));CollectionAssert.AreEqual(pixels,Pixels(vm.Editor.MatchedImage!));
        var session=Path.Combine(root,"shared.ptstudio.json");await vm.SaveSessionAsync(session);using var reopened=new ReferenceColorWorkspaceViewModel(dialogs);await reopened.LoadSessionAsync(session);await Render(reopened);Assert.AreEqual(definition,JsonSerializer.Serialize(reopened.Editor.AdjustmentStack));CollectionAssert.AreEqual(pixels,Pixels(reopened.Editor.MatchedImage!));reopened.ActiveTarget!.IsSelected=true;await reopened.ExportSelectedCommand.ExecuteAsync(null);var exported=Directory.GetFiles(root,"*_仿色.png").Single();var receipt=JsonSerializer.Deserialize<StudioExportReceipt>(await File.ReadAllTextAsync(exported+".kitao-export.json"))!;Assert.AreEqual(reopened.ActiveTarget.ActiveEditVersionId,receipt.EditVersionId);Assert.AreEqual(reopened.Editor.AdjustmentStack.ProcessingVersion,receipt.ProcessingVersion);
        var evidence=Environment.GetEnvironmentVariable("KITAO_R53_EVIDENCE");if(!string.IsNullOrWhiteSpace(evidence)){Directory.CreateDirectory(evidence);File.Copy(session,Path.Combine(evidence,"shared.ptstudio.json"));File.Copy(exported,Path.Combine(evidence,"shared-export.png"));File.Copy(input,Path.Combine(evidence,"synthetic.png"));}
        }finally{Directory.Delete(root,true);}
    });
    [TestMethod]public Task OriginalAndMainVariantDeleteConfirmUndoAndIsolationPersist()=>RunSta(async()=>
    {
        EnsureTestApplication();var root=Path.Combine(Path.GetTempPath(),"r53-variants-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);
        try{var dialogs=new Dialogs(root);using var vm=new ReferenceColorWorkspaceViewModel(dialogs);await vm.LoadTargetAsync(Image(root));var original=vm.R53Variants.Single(v=>v.IsOriginal);var first=vm.ActiveTarget!.ActiveEditVersionId;vm.Editor.SetToolParameter(Exposure,.3);await Render(vm);await vm.CreateR53VariantAsync(false);var copy=vm.ActiveTarget.ActiveEditVersionId;Assert.AreNotEqual(first,copy);vm.Editor.SetToolParameter(Exposure,.8);await Render(vm);await vm.SwitchEditVersionAsync(first!.Value);Assert.AreEqual(.3,vm.Editor.ToolValue(Exposure));await vm.SwitchEditVersionAsync(copy!.Value);Assert.AreEqual(.8,vm.Editor.ToolValue(Exposure));vm.SetR53MainVariant();Assert.AreEqual(copy,vm.R53MainVariantId);
        dialogs.Accept=false;await vm.DeleteR53VariantAsync();Assert.IsFalse(vm.ActiveTarget.EditVersions.Single(v=>v.Id==copy).Archived);dialogs.Accept=true;await vm.DeleteR53VariantAsync();Assert.IsTrue(vm.ActiveTarget.EditVersions.Single(v=>v.Id==copy).Archived);await vm.UndoR53VariantDeleteAsync();Assert.IsFalse(vm.ActiveTarget.EditVersions.Single(v=>v.Id==copy).Archived);await vm.SwitchEditVersionAsync(original.Id);await vm.DeleteR53VariantAsync();Assert.IsFalse(vm.ActiveTarget.EditVersions.Single(v=>v.Id==original.Id).Archived);vm.Editor.SetToolParameter(Exposure,2);Assert.AreEqual(0d,vm.Editor.ToolValue(Exposure));await vm.CreateR53VariantAsync(true);Assert.AreEqual(0d,vm.Editor.ToolValue(Exposure));
        var path=Path.Combine(root,"variants.ptstudio.json");await vm.SaveSessionAsync(path);using var next=new ReferenceColorWorkspaceViewModel(dialogs);await next.LoadSessionAsync(path);Assert.AreEqual(copy,next.R53MainVariantId);Assert.HasCount(1,next.R53Variants.Where(v=>v.IsOriginal));await next.PrepareR53MainExportAsync();Assert.AreEqual(copy,next.ActiveTarget!.ActiveEditVersionId);Assert.AreEqual(.8,next.Editor.ToolValue(Exposure));}
        finally{Directory.Delete(root,true);}
    });
    [TestMethod]public Task LockedNodesBlockParametersNameOrderDeleteButKeepVisibilityUndo()=>RunSta(async()=>
    {
        EnsureTestApplication();var root=Path.Combine(Path.GetTempPath(),"r53-lock-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);
        try{using var vm=new ReferenceColorWorkspaceViewModel(new Dialogs(root));await vm.LoadTargetAsync(Image(root));vm.Editor.AddAdjustmentNodeCommand.Execute("BasicTone");vm.Editor.SetToolParameter(Exposure,.4);var node=vm.Editor.ToolNode(ColorStudioNodeType.BasicTone)!;vm.Editor.SelectedAdjustmentNode=node;vm.Editor.SelectedNodeLocked=true;var before=JsonSerializer.Serialize(vm.Editor.AdjustmentStack);vm.Editor.SetToolParameter(Exposure,1.4);vm.Editor.RenameSelectedAdjustmentNode("must-not-change");vm.Editor.DeleteAdjustmentNodeCommand.Execute(null);Assert.AreEqual(before,JsonSerializer.Serialize(vm.Editor.AdjustmentStack));vm.Editor.SelectedNodeEnabled=false;Assert.IsFalse(vm.Editor.SelectedNodeEnabled);vm.Editor.UndoAdjustmentCommand.Execute(null);Assert.IsTrue(vm.Editor.SelectedNodeEnabled);Assert.IsTrue(vm.Editor.SelectedNodeLocked);vm.Editor.SelectedNodeLocked=false;vm.Editor.SetToolParameter(Exposure,.6);Assert.AreEqual(.6,vm.Editor.ToolValue(Exposure));}
        finally{Directory.Delete(root,true);}await Task.CompletedTask;
    });
    [TestMethod]public Task DipBreakpointsAndProfessionalNodeFilmstripOrderAreRealLayout()=>RunSta(async()=>
    {
        EnsureTestApplication();using var vm=new ReferenceColorWorkspaceViewModel(new Dialogs(Path.GetTempPath()));var view=new PhotoGradePageView{DataContext=vm};
        foreach(var width in new[]{1100d,1366d,1600d}){view.Measure(new Size(width,900));view.Arrange(new Rect(0,0,width,900));view.UpdateLayout();view.ApplyR53Layout();Assert.AreEqual(width>=1200?Visibility.Visible:Visibility.Collapsed,((Border)view.FindName("R53Resources")).Visibility);}
        vm.R53Professional=true;view.ApplyR53Layout();Assert.AreEqual(Visibility.Visible,((Border)view.FindName("R53SerialNodes")).Visibility);Assert.IsTrue(Grid.GetRow((Border)view.FindName("FilmstripArea"))>Grid.GetRow((Border)view.FindName("R53SerialNodes")));view.DataContext=null;await Task.CompletedTask;
    });
    sealed class Dialogs(string root):IDialogService
    {public bool Accept=true;public IReadOnlyList<string> ChooseFiles(string t,string f,bool m)=>[];public string? ChooseFolder(string t,string? p=null)=>root;public string? ChooseSaveFile(string t,string f,string e,string? n=null)=>null;public bool Confirm(string m,string t)=>Accept;public void ShowInfo(string m){}public void ShowError(string m){}public IReadOnlyList<string>? ManageQuickTools(IReadOnlyList<string>x)=>x;public HelpAction ShowHelp()=>HelpAction.None;public void ShowFeedback(){}public RawFileEntry? ChooseRawCandidate(IReadOnlyList<RawFileEntry>x)=>null;public bool ShowMediaDetails(MediaSelectionItem i,bool b)=>false;public void RevealFile(string p){}}
}
''',encoding='utf8')
