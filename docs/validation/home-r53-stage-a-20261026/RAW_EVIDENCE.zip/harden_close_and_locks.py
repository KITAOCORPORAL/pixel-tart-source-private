from pathlib import Path
r=Path('N:/pixart/guangjing-r53-stage-a-20261026')
def edit(name, old, new):
 p=r/name;s=p.read_text(encoding='utf-8-sig');assert old in s,(name,old[:100]);p.write_text(s.replace(old,new),encoding='utf-8')
f='src/RAWSelectionAssistant/ViewModels/TetherReferenceModeViewModel.cs'
edit(f,'public bool SelectedNodeEditable=>SelectedAdjustmentNode?.IsLocked!=true;','public bool SelectedNodeEditable=>!ReadOnlyTarget && SelectedAdjustmentNode?.IsLocked!=true;')
edit(f,'public bool ReadOnlyTarget{get=>_readOnlyTarget;set=>SetProperty(ref _readOnlyTarget,value);}', '''public bool ReadOnlyTarget
    {
        get => _readOnlyTarget;
        set { if (SetProperty(ref _readOnlyTarget, value)) OnPropertyChanged(nameof(SelectedNodeEditable)); }
    }
    private bool CanEditLegacyReference()
    {
        if (!ReadOnlyTarget && !AdjustmentStack.Nodes.Any(n => n.Type == ColorStudioNodeType.ReferenceMatch && n.IsLocked)) return true;
        StatusText = "原始变体或参考图层已锁定，未修改参数。";
        return false;
    }
    private bool CanReplaceLegacyScheme()
    {
        if (!ReadOnlyTarget && !AdjustmentStack.Nodes.Any(n => n.IsLocked)) return true;
        StatusText = "原始变体或图层已锁定，未替换方案。";
        return false;
    }''')
edit(f,'if(ReadOnlyTarget&&!_refreshingLookChoices){StatusText="原始变体只读，请先新建变体。";return;}', 'if(!_refreshingLookChoices&&!CanReplaceLegacyScheme())return;')
edit(f,'if (!double.IsFinite(value)) throw new ArgumentException("参数必须为有限数值。");\n        value = Math.Clamp(value, 0, 100); fallback = value;', 'if (!double.IsFinite(value)) throw new ArgumentException("参数必须为有限数值。");\n        if (!CanEditLegacyReference()) return;\n        value = Math.Clamp(value, 0, 100); fallback = value;')
edit(f,'set { _keepOriginalTone = value; if (SelectedLook is not null)', 'set { if(!CanEditLegacyReference())return; _keepOriginalTone = value; if (SelectedLook is not null)')
edit(f,'private void RestoreScheme()\n    {\n', 'private void RestoreScheme()\n    {\n        if (!CanReplaceLegacyScheme()) return;\n')
edit(f,'if (!_allowReferenceManagement) return;', 'if (!_allowReferenceManagement || !CanEditLegacyReference()) return;')
edit(f,'private async Task SaveReferencesAsync(ReferenceLook look, IReadOnlyList<ReferenceLookSource> sources)\n    {', 'private async Task SaveReferencesAsync(ReferenceLook look, IReadOnlyList<ReferenceLookSource> sources)\n    {\n        if (!CanEditLegacyReference()) return;')
t='src/RAWSelectionAssistant/ViewModels/TetherReferenceModeViewModel.Tools.cs'
edit(t,'var changed = node with { NumericParameters = new Dictionary<string, double>(node.NumericParameters) { [parameter.Key] = value } };', 'if (ReadOnlyTarget || node.IsLocked) { StatusText = "原始变体或图层已锁定，未修改参数。"; return; }\n        var changed = node with { NumericParameters = new Dictionary<string, double>(node.NumericParameters) { [parameter.Key] = value } };')
edit(t,'var values = node.NumericParameters.Where(p => !p.Key.StartsWith(channel', 'if (ReadOnlyTarget || node.IsLocked) { StatusText = "原始变体或曲线图层已锁定。"; return; }\n        var values = node.NumericParameters.Where(p => !p.Key.StartsWith(channel')
f='src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.R53.cs'
edit(f,'Layout=Layout with{R53Professional=value};OnPropertyChanged();','Layout=Layout with{R53Professional=value};OnPropertyChanged();ScheduleR53Autosave();')
edit(f,'private bool _r53Autosaving;', '''private bool _r53Autosaving;
    private long _r53EditRevision;
    private long _r53SavedRevision;''')
edit(f,'try{await SaveSessionAsync(SessionPath);R53SaveStatus="已保存";}', 'try{await SaveSessionAsync(SessionPath);}')
edit(f,'if(!_r53Autosaving&&!IsLoading&&e.PropertyName==nameof(Editor.AdjustmentStack))ScheduleR53Autosave();','if(!IsLoading&&!_applyingActiveSnapshot&&e.PropertyName is nameof(Editor.AdjustmentStack) or nameof(Editor.SelectedLook) or nameof(Editor.FilmSettings))ScheduleR53Autosave();')
edit(f,'if(_disposed)return;R53SaveStatus=SessionPath is null?', 'if(_disposed)return;_r53EditRevision++;R53SaveStatus=SessionPath is null?')
marker='    private void NotifyR53Variants()'
method='''    /// <summary>Called by the real shell close path. A failed save keeps the window open.</summary>
    public async Task<bool> FlushR53BeforeCloseAsync()
    {
        _r53Autosave.Stop();
        if (Targets.Count == 0) return true;
        if (IsLoading || IsExporting || IsInstantGenerating)
        {
            R53SaveStatus = "请等待当前任务完成后退出";
            OnPropertyChanged(nameof(R53SaveStatus));
            return false;
        }
        var path = SessionPath;
        if (path is null)
        {
            await SaveSessionCommand.ExecuteAsync(null);
            if (SessionPath is null)
                return _dialogs.Confirm("暗室工作尚未保存。放弃本次未保存修改并退出？源照片不会删除。", "退出光镜");
            return true;
        }
        try
        {
            await SaveSessionAsync(path);
            // If editing resumed while IO was pending, do not close over a newer edit.
            if (_r53SavedRevision != _r53EditRevision) return false;
            return true;
        }
        catch (Exception error) when (error is IOException or UnauthorizedAccessException or ArgumentException or System.Text.Json.JsonException or InvalidOperationException)
        {
            System.Diagnostics.Trace.TraceError("R53 close save: " + error);
            R53SaveStatus = "保存失败 · 窗口保持打开，请重试保存";
            OnPropertyChanged(nameof(R53SaveStatus));
            return false;
        }
    }
'''
p=r/f;s=p.read_text(encoding='utf-8');assert marker in s;p.write_text(s.replace(marker,method+marker),encoding='utf-8')
f='src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.Session.cs'
edit(f,'var document = new ColorStudioSessionDocument(Targets.Select', 'var savingRevision = _r53EditRevision;\n        var document = new ColorStudioSessionDocument(Targets.Select')
edit(f,'SessionPath = Path.GetFullPath(path); OnPropertyChanged(nameof(SessionPath));R53SaveStatus="已保存";OnPropertyChanged(nameof(R53SaveStatus)); StatusText = "SessionSaved";', '''SessionPath = Path.GetFullPath(path); OnPropertyChanged(nameof(SessionPath));
        _r53SavedRevision = savingRevision;
        if (_r53EditRevision == savingRevision) { _r53Autosave.Stop(); R53SaveStatus = "已保存"; }
        else { R53SaveStatus = "待保存"; _r53Autosave.Stop(); _r53Autosave.Start(); }
        OnPropertyChanged(nameof(R53SaveStatus)); StatusText = "SessionSaved";''')
edit(f,'_sessionFingerprints[Path.GetFullPath(path)]=fingerprint;\n', '_sessionFingerprints[Path.GetFullPath(path)]=fingerprint;\n        _r53SavedRevision = _r53EditRevision; _r53Autosave.Stop(); R53SaveStatus = "已保存"; OnPropertyChanged(nameof(R53SaveStatus));\n')
f='src/RAWSelectionAssistant/MainWindow.xaml.cs'
edit(f,'    private bool _planningCloseFlushed;', '    private bool _darkroomCloseSaving;\n    private bool _darkroomCloseFlushed;\n    private bool _planningCloseFlushed;')
edit(f,'        // Drain dispatcher-affine preview work', '''        if (!_darkroomCloseFlushed && _viewModel?.ReferenceColorPage is { } darkroom)
        {
            e.Cancel = true;
            if (_darkroomCloseSaving) return;
            _darkroomCloseSaving = true;
            try
            {
                if (await darkroom.FlushR53BeforeCloseAsync())
                {
                    _darkroomCloseFlushed = true;
                    _ = Dispatcher.BeginInvoke(new Action(Close));
                }
                else _planningCloseFlushed = false;
            }
            finally { _darkroomCloseSaving = false; }
            return;
        }

        // Drain dispatcher-affine preview work''')