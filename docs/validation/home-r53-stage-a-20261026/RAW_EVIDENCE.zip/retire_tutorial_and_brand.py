from pathlib import Path
import re,json
r=Path('N:/pixart/guangjing-r53-stage-a-20261026');out=Path('N:/pixart/Guangjing-R53-Home-20261026')
def write(path,s): (r/path).write_text(s,encoding='utf-8')
def edit(path,old,new):
 p=r/path;s=p.read_text(encoding='utf-8-sig');assert old in s,(path,old[:80]);p.write_text(s.replace(old,new),encoding='utf-8')
write('src/RAWSelectionAssistant.Core/Services/OnboardingService.cs','''using System.Security.Cryptography;
using System.Text;
using RAWSelectionAssistant.Core.Models;

namespace RAWSelectionAssistant.Core.Services;

/// <summary>
/// Compatibility boundary for retired onboarding settings and callers.
/// The old split tutorial cannot be activated, resumed or create example files.
/// Existing settings, projects and tutorial directories are deliberately untouched.
/// </summary>
public sealed class OnboardingService(
    SettingsService settingsService,
    TutorialDataService tutorialDataService,
    ILogService? logService = null)
{
    private const string ProofSalt = "KitaoPhotoSelector-Onboarding-1.2.0-Completion";
    private static readonly TutorialStep InactiveStep = new(0, "", "", TutorialAction.BeginTutorial,
        TutorialTarget.Welcome, false, false, "", "", null);
    public TutorialState State { get; } = new();
    public TutorialSandboxPaths Sandbox => tutorialDataService.Paths;
    public long SessionVersion => 0;
    public bool NeedsUpgradeOffer => false;
    public IReadOnlyList<TutorialStep> Steps => [];
    public TutorialStep CurrentStep => InactiveStep;

    public Task InitializeAsync(AppSettings settings, bool existingUser, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        State.Mode = TutorialMode.Inactive;
        State.ErrorMessage = string.Empty;
        State.VisitedCategories.Clear();
        State.VisitedOutputModes.Clear();
        // Do not forge a completion proof, reset user settings, or touch old demo files.
        return Task.CompletedTask;
    }
    public Task AcceptUpgradeOfferAsync(bool startTutorial, CancellationToken cancellationToken = default) => Task.CompletedTask;
    public Task StartReplayAsync(CancellationToken cancellationToken = default) => Task.CompletedTask;
    public void ExitReplay() { }
    public Task ExitAsync(CancellationToken cancellationToken = default) => Task.CompletedTask;
    public bool DetachForExit() => false;
    public bool CanPerform(TutorialAction action) => true;
    public Task<TutorialValidationResult> PerformAsync(TutorialAction action, TutorialActionContext context,
        CancellationToken cancellationToken = default) => Task.FromResult(TutorialValidationResult.Success());
    public Task<TutorialValidationResult> PerformForSessionAsync(long sessionVersion, TutorialAction action,
        TutorialActionContext context, CancellationToken cancellationToken = default) => Task.FromResult(TutorialValidationResult.Success());
    public Task<bool> BackAsync(CancellationToken cancellationToken = default) => Task.FromResult(false);
    public Task<TutorialSandboxPaths> ResetTutorialDataAsync(CancellationToken cancellationToken = default) => Task.FromResult(Sandbox);
    public Task<TutorialSandboxPaths> EnsureTutorialDataAsync(CancellationToken cancellationToken = default) => Task.FromResult(Sandbox);
    public void DeleteTutorialData(string path) { }
    public bool IsTutorialPath(string path) => tutorialDataService.IsWithinTutorial(path);
    public void EnsureTutorialPath(string path) => tutorialDataService.EnsureWithinTutorial(path);

    // Read-only historical compatibility; never used to decide whether the retired UI is shown.
    public static bool IsCompletionProofValid(AppSettings settings)
    {
        if (!settings.OnboardingCompleted || settings.OnboardingCompletedAt is null) return false;
        var value = $"{ProofSalt}|{settings.OnboardingVersion}|{settings.OnboardingCompletedAt.Value:O}";
        var expected = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(value)));
        return CryptographicOperations.FixedTimeEquals(Encoding.UTF8.GetBytes(expected),
            Encoding.UTF8.GetBytes(settings.OnboardingCompletionProof ?? string.Empty));
    }
}
''')
p=r/'src/RAWSelectionAssistant.Core/Services/TutorialDataService.cs';s=p.read_text(encoding='utf-8-sig');s=re.sub(r'    private const string DemoJpegBase64 = .*?;\n','',s)
a=s.index('    public async Task<TutorialSandboxPaths> EnsureCreatedAsync');b=s.index('    public bool IsWithinTutorial',a)
s=s[:a]+'''    // Retired compatibility methods must not generate, overwrite or delete any files.
    public Task<TutorialSandboxPaths> EnsureCreatedAsync(CancellationToken cancellationToken = default) => Task.FromResult(Paths);
    public Task<TutorialSandboxPaths> ResetAsync(CancellationToken cancellationToken = default) => Task.FromResult(Paths);
    public void Delete(string path) { }

'''+s[b:];p.write_text(s,encoding='utf-8')
f='src/RAWSelectionAssistant/ViewModels/MainViewModel.cs';p=r/f;s=p.read_text(encoding='utf-8-sig');a=s.index('        var existingUserDetector = new ExistingUserDetectionService();');b=s.index('        var savedSources = ',a);s=s[:a]+'''        // Old tutorial retirement applies to new installs, upgrades and interrupted old steps.
        // No recursive history scan and no demo setup is necessary for product startup.
        await _onboardingService.InitializeAsync(Settings, existingUser: true);
'''+s[b:]
a=s.index('    private async Task ShowHelpAsync()');b=s.index('    private async Task PrepareTutorialWorkspaceAsync',a);s=s[:a]+'''    private Task ShowHelpAsync()
    {
        // Legacy HelpAction values remain deserializable but cannot restart/delete demo data.
        _dialogService.ShowHelp();
        return Task.CompletedTask;
    }

'''+s[b:]
a=s.index('    public async Task RespondToUpgradeOfferAsync(bool startTutorial)');b=s.index('    private bool CanTutorial',a);s=s[:a]+'''    public Task RespondToUpgradeOfferAsync(bool startTutorial) => Task.CompletedTask;

'''+s[b:]
# Remove the two automatic activation branches rather than relying solely on saved completion flags.
a=s.index('        if (IsOnboardingActive)\n        {\n            NavigateToSurface("Workflow", recordHistory: false);\n            await RestoreTutorialWorkspaceAsync();');b=s.index('        StatusMessage = IndexedMediaCount',a);s=s[:a]+'''#if MODULAR_HARNESS_DEV_PREVIEW
        NavigateToSurface(PrimaryNavigationPolicy.Workbench, recordHistory: false);
#else
        NavigateToSurface(PrimaryNavigationPolicy.Normalize(Settings.LastPrimaryPage), recordHistory: false);
#endif
'''+s[b:];s=s.replace('        if (_onboardingService.NeedsUpgradeOffer) UpgradeTutorialOfferRequested?.Invoke(this, EventArgs.Empty);\n','');p.write_text(s,encoding='utf-8')
# Remove actual tutorial overlay tree and placement/keyboard focus authority.
f='src/RAWSelectionAssistant/MainWindow.xaml';p=r/f;s=p.read_text(encoding='utf-8-sig');a=s.index('        <Canvas x:Name="TutorialOverlay"');b=s.index('        </Canvas>',a)+len('        </Canvas>');s=s[:a]+s[b:];p.write_text(s,encoding='utf-8')
f='src/RAWSelectionAssistant/MainWindow.xaml.cs';p=r/f;s=p.read_text(encoding='utf-8-sig');s=s.replace('    private readonly TutorialSpotlightLayoutService _spotlightLayoutService = new();\n','').replace('    private bool _tutorialLayoutPending;\n','').replace('    private TutorialTarget? _lastTutorialTarget;\n','')
a=s.index('        if (_viewModel?.NeedsUpgradeTutorialOffer == true)');b=s.index('\n    }',a);s=s[:a]+s[b:];s=s.replace('private async void MainWindow_Loaded','private void MainWindow_Loaded')
a=s.index('        if (_viewModel?.IsOnboardingActive == true && e.Key == Key.Tab)');b=s.index('        if (Keyboard.Modifiers == ModifierKeys.Control',a);s=s[:a]+s[b:]
a=s.index('        TutorialOverlay.Visibility = Visibility.Collapsed;');b=s.index('        InputRoutingDiagnostics.RecordShellEvent(',a);s=s[:a]+'''        // Compatibility escape seam only; no retired overlay remains in the visual tree.
'''+s[b:];s=s.replace('        if (TutorialOverlay.Visibility == Visibility.Visible) return nameof(TutorialOverlay);\n','')
a=s.index('    private void ScheduleTutorialLayout()');b=s.index('    private static T? FindVisualChild<T>',a);s=s[:a]+'''    // Kept for old diagnostic callbacks; no layout work, focus trap, masks or callouts.
    private void ScheduleTutorialLayout() { }

'''+s[b:]
a=s.index('    private static void SetMask(Shape shape,');s=s[:a]+'}\n';p.write_text(s,encoding='utf-8')
# Help is a normal product dialog, with no tutorial action buttons.
write('src/RAWSelectionAssistant/Views/HelpWindow.xaml','''<Window x:Class="RAWSelectionAssistant.Views.HelpWindow"
        xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="帮助 - 光镜" Width="520" Height="300" ResizeMode="NoResize"
        WindowStartupLocation="CenterOwner" Icon="../Assets/AppIcon.ico" Background="{DynamicResource WindowBackgroundBrush}">
    <Grid Margin="24">
        <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
        <TextBlock Text="光镜" Style="{StaticResource AppTitleText}"/>
        <TextBlock Grid.Row="1" Text="版本 2.3.0" Foreground="{DynamicResource TextSecondaryBrush}" Margin="0,12"/>
        <Button Grid.Row="2" Content="关闭" Style="{StaticResource SecondaryButton}" HorizontalAlignment="Right" Width="90" Click="Close_Click" IsCancel="True"/>
    </Grid>
</Window>
''')
write('src/RAWSelectionAssistant/Views/HelpWindow.xaml.cs','''using System.Windows;
using RAWSelectionAssistant.Services;
namespace RAWSelectionAssistant.Views;
public partial class HelpWindow : Window
{
    public HelpWindow() => InitializeComponent();
    public HelpAction SelectedAction => HelpAction.None;
    private void Close_Click(object sender, RoutedEventArgs e) => Close();
}
''')
# Remove the old upgrade view, including conditional diagnostic use.
f='src/RAWSelectionAssistant/MainWindow.AutomatedDpiAcceptance.cs';p=r/f;s=p.read_text(encoding='utf-8-sig').replace('_automatedAuxiliaryWindow = new UpgradeTutorialWindow','_automatedAuxiliaryWindow = new HelpWindow');p.write_text(s,encoding='utf-8')
# Only user-facing old brand strings: internal identifiers, resource keys and data paths stay.
changes=[]
for p in (r/'src').rglob('*'):
 if not p.is_file() or p.suffix not in ['.cs','.xaml','.json','.md','.csproj'] or any(x in p.parts for x in ['obj','bin']):continue
 s=p.read_text(encoding='utf-8-sig');original=s
 if '像素蛋挞' in s:s=s.replace('像素蛋挞','光镜')
 if p.suffix=='.json' and p.parent.name=='Studio':
  # Keep old translation keys so older templates remain compatible.
  s=re.sub(r'("Pixel Tart 胶片"\s*:\s*")([^"]+)(")',lambda m:m[1]+re.sub(r'Pixel Tart','光镜',m[2],flags=re.I)+m[3],s)
 else:
  # Strings with spaces are display labels/metadata in these files, not PixelTart identifiers.
  s=re.sub(r'(?<![A-Za-z])Pixel Tart(?=[^A-Za-z]|$)','光镜',s,flags=re.I)
 if s!=original:p.write_text(s,encoding='utf-8');changes.append(str(p.relative_to(r)))
p=r/'Directory.Build.props';s=p.read_text(encoding='utf-8-sig');p.write_text(s.replace('像素蛋挞','光镜'),encoding='utf-8')
for p in (r/'installer').glob('*.iss'):
 s=p.read_text(encoding='utf-8-sig');lines=[]
 for line in s.splitlines(keepends=True):
  if 'DefaultDirName=' not in line and 'OutputBaseFilename' not in line:
   line=line.replace('像素蛋挞','光镜');line=re.sub(r'Pixel Tart','光镜',line,flags=re.I)
  lines.append(line)
 p.write_text(''.join(lines),encoding='utf-8')
# Modern translation lookup name too; old JSON keys are retained purely for compatibility.
p=r/'src/RAWSelectionAssistant/Views/ReferenceColorWorkspaceView.xaml';s=p.read_text(encoding='utf-8');s=s.replace("Key='光镜 胶片'","Key='Pixel Tart 胶片'");p.write_text(s,encoding='utf-8')
(out/'brand-changed-files.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2),encoding='utf-8')