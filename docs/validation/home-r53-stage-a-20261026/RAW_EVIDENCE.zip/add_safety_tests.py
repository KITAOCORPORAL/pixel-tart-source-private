from pathlib import Path
p=Path('N:/pixart/guangjing-r53-stage-a-20261026/tests/RAWSelectionAssistant.WpfTests/R53DarkroomStageATests.cs')
s=p.read_text(encoding='utf-8-sig')
i=s.index('    sealed class Dialogs(')
s=s[:i]+'''    [TestMethod]
    public Task LegacySimpleControlsCannotBypassReferenceLocksOrOriginalReadOnly() => RunSta(async () =>
    {
        EnsureTestApplication();
        using var editor = new TetherReferenceModeViewModel();
        var now = DateTimeOffset.UtcNow;
        var look = new ReferenceLook(Guid.NewGuid(), "锁定参考", null, [], new(MatchStrength: 37), now, now);
        var reference = ColorStudioLegacyMigration.Migrate(look).Stack;
        var locked = reference with { Nodes = reference.Nodes.Select(n => n with { UserLocked = true }).ToArray() };
        editor.ApplyTargetSnapshot(look, null, locked, false, Guid.NewGuid());
        var before = JsonSerializer.Serialize(editor.AdjustmentStack);
        var lookBefore = JsonSerializer.Serialize(editor.SelectedLook);
        editor.MatchStrength = 80;
        editor.KeepOriginalTone = !editor.KeepOriginalTone;
        editor.SelectedLook = look with { Name = "不能替换", Parameters = new(MatchStrength: 80) };
        editor.RestoreSchemeCommand.Execute(null);
        Assert.AreEqual(before, JsonSerializer.Serialize(editor.AdjustmentStack));
        Assert.AreEqual(lookBefore, JsonSerializer.Serialize(editor.SelectedLook), "Locked stack must also protect legacy look fields used by save/export");
        editor.ApplyTargetSnapshot(null, null, null, false, Guid.NewGuid());
        editor.Enabled = false;
        editor.ReadOnlyTarget = true;
        editor.SetToolParameter(Exposure, .8);
        editor.MatchStrength = 80;
        editor.KeepOriginalTone = true;
        editor.FilmEnabled = true;
        Assert.HasCount(0, editor.AdjustmentStack.Nodes);
        Assert.IsFalse(editor.Enabled, "Rejected edit must not change render-enable state");
        Assert.AreEqual(100, editor.MatchStrength);
        Assert.IsFalse(editor.FilmEnabled);
        await Task.CompletedTask;
    });
''' + s[i:]
p.write_text(s,encoding='utf-8')