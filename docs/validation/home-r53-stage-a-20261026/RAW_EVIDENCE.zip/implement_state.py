from pathlib import Path
r=Path.cwd()/'guangjing-r53-stage-a-20261026'
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/StudioEditVersion.cs';s=p.read_text().replace('    public bool Archived { get; init; }','''    public bool Archived { get; init; }
    public bool IsOriginal {get;init;}
    public bool IsMain {get;init;}
    public int Rating {get;init;}
    public string? ColorLabel {get;init;}
''');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/ColorStudioModels.cs';s=p.read_text().replace('''    public IReadOnlyDictionary<string, double> NumericParameters { get; init; } = NumericParameters ?? new Dictionary<string, double>();''','''    // Editing permission only; never a processing switch. Locked nodes still render.
    public bool UserLocked {get;init;}
    public bool SystemLocked {get;init;}
    [System.Text.Json.Serialization.JsonIgnore] public bool IsLocked=>UserLocked||SystemLocked;
    public IReadOnlyDictionary<string, double> NumericParameters { get; init; } = NumericParameters ?? new Dictionary<string, double>();''');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/ViewModels/TetherReferenceModeViewModel.cs';s=p.read_text();needle='''        if (previous.Nodes.SequenceEqual(nodes)) return;''';s=s.replace(needle,'''        // Enforce at the mutation boundary, including tool panels, curves and drag reorder.
        // Visibility and user-lock toggles are allowed; system locks cannot be removed.
        foreach(var locked in previous.Nodes.Where(n=>n.IsLocked))
        {
            var replacement=nodes.FirstOrDefault(n=>n.Id==locked.Id);
            if(replacement is null || Array.FindIndex(nodes,n=>n.Id==locked.Id)!=previous.Nodes.ToList().FindIndex(n=>n.Id==locked.Id) ||
                System.Text.Json.JsonSerializer.Serialize(locked with{Enabled=true,UserLocked=false})!=System.Text.Json.JsonSerializer.Serialize(replacement with{Enabled=true,UserLocked=false}))
            {StatusText="图层已锁定；仅允许切换可见性或解除用户锁定。";return;}
        }
'''+needle);s=s.replace('''        var copy = selected.Normalize()''','''        var copy = selected.Normalize()''');# selected lock property handled central
needle='''    public string SelectedNodeName {''';s=s.replace(needle,'''    public bool SelectedNodeLocked
    {
        get=>SelectedAdjustmentNode?.IsLocked==true;
        set{if(SelectedAdjustmentNode is {} node && !node.SystemLocked)ChangeStack(nodes=>nodes.Select(n=>n.Id==node.Id?n with{UserLocked=value}:n).ToArray(),render:false);OnPropertyChanged();}
    }
    public bool SelectedNodeEditable=>SelectedAdjustmentNode?.IsLocked!=true;
'''+needle);s=s.replace('''OnPropertyChanged(nameof(SelectedNodeName)); OnPropertyChanged(nameof(KeepOriginalLuminance));''','''OnPropertyChanged(nameof(SelectedNodeName)); OnPropertyChanged(nameof(SelectedNodeLocked));OnPropertyChanged(nameof(SelectedNodeEditable)); OnPropertyChanged(nameof(KeepOriginalLuminance));''');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.Versions.cs';s=p.read_text().replace('''Archived=existing?.Archived??false,OriginVersionId''','''IsOriginal=existing?.IsOriginal??false,IsMain=existing?.IsMain??false,Rating=existing?.Rating??0,ColorLabel=existing?.ColorLabel,Archived=existing?.Archived??false,OriginVersionId''');s=s.replace('''        target.ActiveEditVersionId=Guid.NewGuid();CaptureEditVersion(target);''','''        target.ActiveEditVersionId=Guid.NewGuid();CaptureEditVersion(target);''');old='''        ArchiveEditVersionCommand=new AsyncRelayCommand(async _=>{if(ActiveTarget is not {} target)return;CaptureEditVersion(target);var next=target.EditVersions.FirstOrDefault(v=>v.Id!=target.ActiveEditVersionId&&!v.Archived);if(next is null){StatusText="至少保留一个版本";return;}var index=target.EditVersions.ToList().FindIndex(v=>v.Id==target.ActiveEditVersionId);var old=target.EditVersions[index];await SwitchEditVersionAsync(next.Id);target.EditVersions[index]=old with{Archived=true};});''';new='''        ArchiveEditVersionCommand=new AsyncRelayCommand(async _=>await DeleteR53VariantAsync());''';assert old in s;s=s.replace(old,new);p.write_text(s,encoding='utf8')
(r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.R53.cs').write_text('''using System.Collections.ObjectModel;
using RAWSelectionAssistant.Core.Services.Projects;
using RAWSelectionAssistant.Utilities;
namespace RAWSelectionAssistant.ViewModels;
public sealed partial class ReferenceColorWorkspaceViewModel
{
    private bool _r53Professional;
    public bool R53Professional{get=>_r53Professional;set=>SetProperty(ref _r53Professional,value);}
    public IReadOnlyList<StudioEditVersion> R53Variants=>ActiveTarget?.EditVersions.Where(v=>!v.Archived).ToArray()??[];
    public Guid? R53MainVariantId=>ActiveTarget?.EditVersions.FirstOrDefault(v=>v.IsMain&&!v.Archived)?.Id;
    public string R53VariantStatus=>ActiveTarget is {} t?$"变体 {Array.FindIndex(R53Variants.ToArray(),v=>v.Id==t.ActiveEditVersionId)+1}/{R53Variants.Count} · {t.EditVersions.FirstOrDefault(v=>v.Id==t.ActiveEditVersionId)?.Name} · 主变体 {t.EditVersions.FirstOrDefault(v=>v.IsMain&&!v.Archived)?.Name}":"未选择照片";
    private readonly Dictionary<Guid,Stack<StudioEditVersion[]>> _r53Deleted=[];
    private void EnsureR53Variants(ReferenceTargetItem target)
    {
        if(target.EditVersions.All(v=>!v.IsOriginal))
        {
            var bytes=System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes("Guangjing.Original.v1:"+target.Id));
            var original=new StudioEditVersion(new Guid(bytes.AsSpan(0,16)),"原始",DateTimeOffset.UtcNow,target.LibraryId,target.AssetId,target.SourceHash,null,null,null,ColorStudioMatchEngine.Stable,MatchV4ExecutionMode.Auto){IsOriginal=true};
            target.EditVersions.Insert(0,original);
        }
        if(target.EditVersions.All(v=>!v.IsMain||v.Archived))
        {var index=target.EditVersions.ToList().FindIndex(v=>v.Id==target.ActiveEditVersionId&&!v.Archived);if(index<0)index=0;target.EditVersions[index]=target.EditVersions[index] with{IsMain=true};}
        NotifyR53Variants();
    }
    private void NotifyR53Variants(){OnPropertyChanged(nameof(R53Variants));OnPropertyChanged(nameof(R53VariantStatus));OnPropertyChanged(nameof(R53MainVariantId));}
    public async Task CreateR53VariantAsync(bool fromOriginal)
    {
        if(ActiveTarget is not {} target||IsLoading||IsExporting||IsInstantGenerating)return;
        Editor.CopyCurrentLookTo([target]);CaptureEditVersion(target);EnsureR53Variants(target);
        var source=fromOriginal?target.EditVersions.First(v=>v.IsOriginal):target.EditVersions.Single(v=>v.Id==target.ActiveEditVersionId);
        var next=source with{Id=Guid.NewGuid(),Name=fromOriginal?"原始新建 "+R53Variants.Count:"副本 "+R53Variants.Count,IsOriginal=false,IsMain=false,Archived=false,CreatedAt=DateTimeOffset.UtcNow,OriginVersionId=source.Id,Stack=source.Stack?.DeepClone()};
        target.EditVersions.Add(next);await SwitchEditVersionAsync(next.Id);NotifyR53Variants();
    }
    public void SetR53MainVariant()
    {
        if(ActiveTarget is not {} target||IsLoading||IsExporting||IsInstantGenerating)return;
        CaptureEditVersion(target);EnsureR53Variants(target);
        for(int i=0;i<target.EditVersions.Count;i++)target.EditVersions[i]=target.EditVersions[i] with{IsMain=target.EditVersions[i].Id==target.ActiveEditVersionId};
        NotifyR53Variants();StatusText="主变体已设置；保存项目后保留。";
    }
    public async Task DeleteR53VariantAsync()
    {
        if(ActiveTarget is not {} target||IsLoading||IsExporting||IsInstantGenerating)return;
        Editor.CopyCurrentLookTo([target]);CaptureEditVersion(target);EnsureR53Variants(target);var active=target.EditVersions.Single(v=>v.Id==target.ActiveEditVersionId);
        if(active.IsOriginal){StatusText="原始变体不可删除；源照片保持只读。";return;}
        if(!_dialogs.Confirm("删除变体“"+active.Name+"”？可撤销；不删除源照片文件。已有项目引用会显示该变体不可用，不替换为其他变体。","删除变体"))return;
        var before=target.EditVersions.ToArray();var next=target.EditVersions.First(v=>v.IsOriginal&&!v.Archived);await SwitchEditVersionAsync(next.Id);
        if(!ReferenceEquals(target,ActiveTarget)||target.ActiveEditVersionId!=next.Id)return;
        if(!_r53Deleted.TryGetValue(target.Id,out var undo))_r53Deleted[target.Id]=undo=new();undo.Push(before);
        var index=target.EditVersions.ToList().FindIndex(v=>v.Id==active.Id);target.EditVersions[index]=active with{Archived=true,IsMain=false};
        if(active.IsMain){var n=target.EditVersions.ToList().FindIndex(v=>v.Id==next.Id);target.EditVersions[n]=target.EditVersions[n] with{IsMain=true};}
        NotifyR53Variants();StatusText="变体已删除，可撤销；源照片未修改。";
    }
    public async Task UndoR53VariantDeleteAsync()
    {
        if(ActiveTarget is not {} target||IsLoading||IsExporting||IsInstantGenerating||!_r53Deleted.TryGetValue(target.Id,out var history)||history.Count==0)return;
        var before=history.Pop();var deleted=before.FirstOrDefault(v=>target.EditVersions.Any(x=>x.Id==v.Id&&x.Archived&&!v.Archived));
        target.EditVersions.Clear();foreach(var v in before)target.EditVersions.Add(v);if(deleted is not null)await SwitchEditVersionAsync(deleted.Id);NotifyR53Variants();
    }
    public async Task PrepareR53MainExportAsync()
    {
        if(ActiveTarget is not {} target)return;Editor.CopyCurrentLookTo([target]);CaptureEditVersion(target);EnsureR53Variants(target);
        var main=target.EditVersions.Single(v=>v.IsMain&&!v.Archived);await SwitchEditVersionAsync(main.Id);NotifyR53Variants();
    }
}
''',encoding='utf8')
# Restore metadata through all session load paths; old versions remain intact, original is additive.
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.cs';s=p.read_text().replace('''            ScheduleTargetThumbnail(target);
            if (ReferenceEquals(FailedTarget, target))''','''            CaptureEditVersion(target);EnsureR53Variants(target);
            ScheduleTargetThumbnail(target);
            if (ReferenceEquals(FailedTarget, target))''');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.Session.cs';s=p.read_text().replace('''        foreach(var target in Targets) CaptureEditVersion(target);''','''        foreach(var target in Targets){CaptureEditVersion(target);EnsureR53Variants(target);}''');p.write_text(s,encoding='utf8')
