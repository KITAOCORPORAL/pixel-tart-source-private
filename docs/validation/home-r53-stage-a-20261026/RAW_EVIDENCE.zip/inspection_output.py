from pathlib import Path
r=Path.cwd()/'guangjing-r53-stage-a-20261026'
p=r/'src/RAWSelectionAssistant/Views/PhotoGradePageView.xaml';s=p.read_text().replace('<Grid Grid.Row="2"><Grid.ColumnDefinitions>','<Grid Grid.Row="2" x:Name="R53MainLayout"><Grid.ColumnDefinitions>');s=s.replace('''<ColumnDefinition x:Name="PanelColumn" Width="304" MinWidth="280" MaxWidth="460"/>''','''<ColumnDefinition x:Name="PanelColumn" Width="304" MinWidth="280" MaxWidth="460"/><ColumnDefinition x:Name="R53InspectColumn" Width="0"/>''');needle='''   <Grid Grid.Column="4" x:Name="RightPanel"''';# add dock before right
s=s.replace(needle,'''   <Border Grid.Column="5" x:Name="R53InspectDock" Visibility="Collapsed" Background="#1D1D20" BorderBrush="#303034" BorderThickness="1,0,0,0"/>
'''+needle);p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/Views/PhotoGradePageView.R53.cs';s=p.read_text();start=s.index('    private void R53Inspect3D(');s=s[:start]+'''    private Action? closeR53Inspection;
    private void R53Inspect3D(object s,RoutedEventArgs e)
    {
        if(model is null)return;
        if(closeR53Inspection is not null){closeR53Inspection();return;}
        var ownerModel=model;
        var content=new StackPanel{Margin=new Thickness(8)};
        content.Children.Add(new TextBlock{Text="3D 色彩 · 当前真实图像数据",FontSize=14,Margin=new Thickness(0,8,0,8)});
        var cloud=new ColorSpace3DViewport{MinWidth=420,MinHeight=300,Height=340,DataContext=model};content.Children.Add(cloud);
        if(model.ColorSpaceModel is {} current)cloud.SetModel(current);
        System.ComponentModel.PropertyChangedEventHandler update=(_,args)=>{if(args.PropertyName==nameof(ownerModel.ColorSpaceModel)&&ownerModel.ColorSpaceModel is {} changed)cloud.SetModel(changed);};
        ownerModel.PropertyChanged+=update;
        content.Children.Add(new Button{Content="从当前图像生成",Command=model.BuildColorSpaceModelCommand});
        var undock=new Button{Content="解除停靠（浮动）"};content.Children.Add(undock);var back=new Button{Content="返回主图"};content.Children.Add(back);
        void Close()
        {
            ownerModel.PropertyChanged-=update;R53InspectDock.Child=null;R53InspectDock.Visibility=Visibility.Collapsed;R53InspectColumn.Width=new GridLength(0);
            var window=r53Inspect;r53Inspect=null;closeR53Inspection=null;window?.Close();
        }
        closeR53Inspection=Close;back.Click+=(_,_)=>Close();
        void Float(bool focused)
        {
            R53InspectDock.Child=null;R53InspectDock.Visibility=Visibility.Collapsed;R53InspectColumn.Width=new GridLength(0);
            r53Inspect=new Window{Title=focused?"光镜 · 专注色彩检查":"光镜 · 浮动色彩检查",Owner=Window.GetWindow(this),MinWidth=460,MinHeight=440,Width=620,Height=540,Content=content,Background=new SolidColorBrush(Color.FromRgb(29,29,32)),WindowStartupLocation=WindowStartupLocation.CenterOwner};
            r53Inspect.Closed+=(_,_)=>{r53Inspect=null;if(closeR53Inspection is not null)Close();};
            if(focused)r53Inspect.ShowDialog();else r53Inspect.Show();
        }
        undock.Click+=(_,_)=>{if(r53Inspect is null)Float(false);};
        // Client-DIP width permits 440px inspector + existing304 + resources264,
        // while leaving the main photo >=560. No overlay on wide default open.
        if(ActualWidth>=1800){R53InspectColumn.Width=new GridLength(440);R53InspectDock.Visibility=Visibility.Visible;R53InspectDock.Child=content;}
        else Float(true); // Explicit user entry into focused inspection; return is always present.
    }
}
''';s=s.replace('''SizeChanged+=(_,_)=>ApplyR53Layout();''','''SizeChanged+=(_,_)=>{if(ActualWidth<1800&&R53InspectDock.Visibility==Visibility.Visible)closeR53Inspection?.Invoke();ApplyR53Layout();};''');s=s.replace('''model?.Editor.HoldOriginal(false);r53Inspect?.Close();''','''model?.Editor.HoldOriginal(false);closeR53Inspection?.Invoke();''');p.write_text(s,encoding='utf8')
# main-variant output applies to selected-photo batch and publishing handoff too, not only dialog open.
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.R53.cs';s=p.read_text();s=s.replace('''    public async Task PrepareR53MainExportAsync()''','''    private StudioEditVersion MainOutputVersion(ReferenceTargetItem target)
    {CaptureEditVersion(target);EnsureR53Variants(target);return target.EditVersions.Single(v=>v.IsMain&&!v.Archived);}
    public async Task PrepareR53MainExportAsync()''');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.cs';s=p.read_text();old='''var frozen = items.Select(item => (Item: item, VersionId: item.ActiveEditVersionId!.Value, Look: item.AppliedLookSnapshot, Stack: item.ColorAdjustmentStackSnapshot?.DeepClone(), Film: item.FilmSettingsSnapshot, Engine: item.EngineSnapshot, Mode: item.ExecutionModeSnapshot, RawDefinition:item.RawDefinition, RawInput:item.RawInput)).ToArray();''';new='''var frozen = items.Select(item => {var main=MainOutputVersion(item);return (Item:item,VersionId:main.Id,Look:main.Look,Stack:main.Stack?.DeepClone(),Film:main.Film,Engine:main.Engine,Mode:main.Mode,RawDefinition:main.RawDefinition,RawInput:main.RawInput);}).ToArray();''';assert old in s;s=s.replace(old,new)
a=s.index('''var frozen = items.Select(item => (Item: item, VersionId: item.ActiveEditVersionId!.Value, LibraryId:''');b=s.index('\n',a);s=s[:a]+'''var frozen = items.Select(item => {var main=MainOutputVersion(item);return (Item:item,VersionId:main.Id,LibraryId:item.LibraryId,AssetId:item.AssetId,SourceHash:item.SourceHash,Look:main.Look is {} look?look with{ReferenceSources=look.ReferenceSources.Select(source=>source with{}).ToArray()}:null,Film:main.Film is {} film?film with{}:null,Stack:main.Stack?.Normalize(),Engine:main.Engine,Mode:main.Mode,RawDefinition:main.RawDefinition,RawInput:main.RawInput);}).ToArray();'''+s[b:];p.write_text(s,encoding='utf8')
# rating and color metadata belong to each stable variant; not the Photo row.
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.R53.cs';s=p.read_text().replace('''    public string R53VariantStatus''','''    public int R53VariantRating
    {get=>ActiveTarget?.EditVersions.FirstOrDefault(v=>v.Id==ActiveTarget.ActiveEditVersionId)?.Rating??0;set{if(ActiveTarget is not {} target)return;CaptureEditVersion(target);var i=target.EditVersions.ToList().FindIndex(v=>v.Id==target.ActiveEditVersionId);if(i>=0)target.EditVersions[i]=target.EditVersions[i] with{Rating=Math.Clamp(value,0,5)};NotifyR53Variants();}}
    public string R53VariantColorLabel
    {get=>ActiveTarget?.EditVersions.FirstOrDefault(v=>v.Id==ActiveTarget.ActiveEditVersionId)?.ColorLabel??"无";set{if(ActiveTarget is not {} target)return;CaptureEditVersion(target);var i=target.EditVersions.ToList().FindIndex(v=>v.Id==target.ActiveEditVersionId);if(i>=0)target.EditVersions[i]=target.EditVersions[i] with{ColorLabel=value is "红" or "橙" or "黄" or "绿" or "蓝" or "紫"?value:null};NotifyR53Variants();}}
    public string R53VariantStatus''');s=s.replace('''OnPropertyChanged(nameof(R53MainVariantId));}''','''OnPropertyChanged(nameof(R53MainVariantId));OnPropertyChanged(nameof(R53VariantRating));OnPropertyChanged(nameof(R53VariantColorLabel));}''');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/Views/PhotoGradePageView.xaml';s=p.read_text().replace('''<TextBox Text="{Binding EditVersionName,UpdateSourceTrigger=PropertyChanged}"''','''<WrapPanel><TextBlock Text="评分"/><Slider Width="90" Minimum="0" Maximum="5" TickFrequency="1" IsSnapToTickEnabled="True" Value="{Binding R53VariantRating,Mode=TwoWay}"/><ComboBox Width="60" SelectedValuePath="Content" SelectedValue="{Binding R53VariantColorLabel,Mode=TwoWay}"><ComboBoxItem Content="无"/><ComboBoxItem Content="红"/><ComboBoxItem Content="橙"/><ComboBoxItem Content="黄"/><ComboBoxItem Content="绿"/><ComboBoxItem Content="蓝"/><ComboBoxItem Content="紫"/></ComboBox></WrapPanel><TextBox Text="{Binding EditVersionName,UpdateSourceTrigger=PropertyChanged}"''');p.write_text(s,encoding='utf8')
