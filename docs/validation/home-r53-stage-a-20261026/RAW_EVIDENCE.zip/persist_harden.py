from pathlib import Path
r=Path.cwd()/'guangjing-r53-stage-a-20261026'
# Read-only original never overwritten by current runtime controls.
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.Versions.cs';s=p.read_text().replace('''        var snapshot=new StudioEditVersion''','''        if(existing?.IsOriginal==true)return;
        var snapshot=new StudioEditVersion''');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/ViewModels/TetherReferenceModeViewModel.cs';s=p.read_text().replace('''    private void SetFilm(PixelTartFilmSettings value)
    {''','''    private void SetFilm(PixelTartFilmSettings value)
    {
        if(!_syncingStack&&(ReadOnlyTarget||AdjustmentStack.Nodes.Any(n=>n.Type==ColorStudioNodeType.Film&&n.IsLocked))){StatusText="当前原始变体或胶片节点已锁定。";return;}''');s=s.replace('''    private void ApplyColorScheme()
    {
        if (SelectedColorScheme''','''    private void ApplyColorScheme()
    {
        if(ReadOnlyTarget||AdjustmentStack.Nodes.Any(n=>n.IsLocked)){StatusText="当前变体或图层锁定，未替换方案。";return;}
        if (SelectedColorScheme''');p.write_text(s,encoding='utf8')
# Persist mode with existing layout snapshot, not a second editor/model.
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/ColorStudioSessionStore.cs';s=p.read_text().replace('''    public DarkroomPanelLayout? Darkroom { get; init; }''','''    public DarkroomPanelLayout? Darkroom { get; init; }
    public bool R53Professional {get;init;}''');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.R53.cs';s=p.read_text().replace('''    private bool _r53Professional;
    public bool R53Professional{get=>_r53Professional;set=>SetProperty(ref _r53Professional,value);}''','''    public bool R53Professional{get=>Layout.R53Professional;set{if(Layout.R53Professional==value)return;Layout=Layout with{R53Professional=value};OnPropertyChanged();}}''');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/Views/PhotoGradePageView.xaml.cs';s=p.read_text().replace('''  if(e.PropertyName==nameof(ReferenceColorWorkspaceViewModel.Layout)&&!savingPanelLayout)RestorePanelLayout();''','''  if(e.PropertyName==nameof(ReferenceColorWorkspaceViewModel.Layout)&&!savingPanelLayout){RestorePanelLayout();ApplyR53Layout();}
  if(e.PropertyName==nameof(ReferenceColorWorkspaceViewModel.R53Professional))ApplyR53Layout();''');p.write_text(s,encoding='utf8')
# Original/protected flags, main uniqueness and per-variant annotation validation in stored sessions.
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/ColorStudioSessionStore.cs';s=p.read_text();needle='''            target.Film?.Validate();target.RawDefinition?.Validate();''';s=s.replace(needle,'''            if(target.EditVersions is {} variants)
            {
                if(variants.Count(v=>v.IsOriginal)>1||variants.Count(v=>v.IsMain&&!v.Archived)>1||variants.Any(v=>v.Rating is <0 or >5 || v.IsOriginal&&v.Archived))
                    throw new InvalidDataException("原始/主变体或评分身份无效。");
            }
'''+needle);p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/StudioVersionRepository.cs';s=p.read_text().replace('''        foreach(var version in versions)
''','''        if(versions.Count(v=>v.IsOriginal)>1||versions.Count(v=>v.IsMain&&!v.Archived)>1||versions.Any(v=>v.Rating is <0 or >5||v.IsOriginal&&v.Archived))throw new InvalidDataException("原始/主变体或评分身份无效。");
        foreach(var version in versions)
''');p.write_text(s,encoding='utf8')
# Existing selected node tools remain the real params; R53 category nav only selects an approved serial node.
p=r/'src/RAWSelectionAssistant/Views/PhotoGradePageView.R53.cs';s=p.read_text().replace('''    private void R53Simple''','''    private void R53ParameterCategory(object sender,RoutedEventArgs e)
    {
        if(model is null||sender is not Button{Tag:string type})return;
        var parsed=Enum.Parse<ColorStudioNodeType>(type);var node=model.Editor.AdjustmentNodes.FirstOrDefault(n=>n.Type==parsed);
        if(node is null){model.Editor.AddAdjustmentNodeCommand.Execute(type);node=model.Editor.AdjustmentNodes.LastOrDefault(n=>n.Type==parsed);}
        if(node is not null)model.Editor.SelectedAdjustmentNode=node;EditModes.SelectedIndex=0;
        if(type=="Curve")PhotographerCurve.BringIntoView();else if(type=="ColorBalance")AdjustmentScroll.ScrollToVerticalOffset(380);else AdjustmentScroll.ScrollToTop();
    }
    private void R53Simple''');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/Views/PhotoGradePageView.xaml';s=p.read_text().replace('''<TextBlock DockPanel.Dock="Top" Text="节点 · 串行处理顺序" Height="22"/>''','''<WrapPanel DockPanel.Dock="Top"><TextBlock Text="节点 · 串行" Height="22"/><Button Content="基础" Tag="BasicTone" Click="R53ParameterCategory"/><Button Content="曲线" Tag="Curve" Click="R53ParameterCategory"/><Button Content="色轮" Tag="ColorBalance" Click="R53ParameterCategory"/><Button Content="HSL" Tag="Hsl" Click="R53ParameterCategory"/></WrapPanel>''');p.write_text(s,encoding='utf8')
# A built-in preset has real approved exposure values, not a fake look or unlicensed texture.
p=r/'src/RAWSelectionAssistant/Views/PhotoGradePageView.R53.cs';s=p.read_text().replace('''        foreach(var (name,type) in new[]{("基础调色","BasicTone")''','''        Add("提亮 +0.3 EV",()=>{if(model is null)return;model.Editor.AddAdjustmentNodeCommand.Execute("BasicTone");var parameter=ColorStudioToolCatalog.GetParameters(ColorStudioNodeType.BasicTone).Single(p=>p.Key=="exposure");model.Editor.SetToolParameter(parameter,.3);});
        foreach(var (name,type) in new[]{("基础调色","BasicTone")''');# this replacement may hit compact foreach in ToggleResources? only exact indentation resource section.
p.write_text(s,encoding='utf8')
# Tests annotations/export main actually rendering differs from current.
p=r/'tests/RAWSelectionAssistant.WpfTests/R53DarkroomStageATests.cs';s=p.read_text().replace('''vm.SetR53MainVariant();Assert.AreEqual(copy,vm.R53MainVariantId);''','''vm.SetR53MainVariant();vm.R53VariantRating=4;vm.R53VariantColorLabel="绿";Assert.AreEqual(copy,vm.R53MainVariantId);''');s=s.replace('''Assert.AreEqual(.8,next.Editor.ToolValue(Exposure));}''','''Assert.AreEqual(.8,next.Editor.ToolValue(Exposure));Assert.AreEqual(4,next.R53VariantRating);Assert.AreEqual("绿",next.R53VariantColorLabel);}''');p.write_text(s,encoding='utf8')
