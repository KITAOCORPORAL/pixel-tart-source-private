from pathlib import Path
r=Path.cwd()/'guangjing-r53-stage-a-20261026';p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.Session.cs';s=p.read_text().replace('''            var path = _dialogs.ChooseSaveFile''','''            var path = SessionPath ?? _dialogs.ChooseSaveFile''');p.write_text(s,encoding='utf8')
# Dedicated debounced existing-session autosave: no arbitrary default output, retries preserve draft state.
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.R53.cs';s=p.read_text().replace('''    private void NotifyR53Variants(){''','''    private readonly System.Windows.Threading.DispatcherTimer _r53Autosave=new(){Interval=TimeSpan.FromMilliseconds(900)};
    public string R53SaveStatus{get;private set;}="未保存项目";
    private bool _r53Autosaving;
    private void InitializeR53Autosave()
    {
        _r53Autosave.Tick+=async(_,_)=>
        {
            if(_r53Autosaving||IsLoading||IsExporting||IsInstantGenerating)return;_r53Autosave.Stop();
            if(SessionPath is null)return;_r53Autosaving=true;R53SaveStatus="正在保存…";OnPropertyChanged(nameof(R53SaveStatus));
            try{await SaveSessionAsync(SessionPath);R53SaveStatus="已保存";}
            catch(Exception e)when(e is IOException or UnauthorizedAccessException or InvalidDataException or InvalidOperationException){R53SaveStatus="保存失败 · 点击保存重试";}
            finally{_r53Autosaving=false;OnPropertyChanged(nameof(R53SaveStatus));}
        };
        Editor.PropertyChanged+=(_,e)=>{if(!_r53Autosaving&&!IsLoading&&e.PropertyName==nameof(Editor.AdjustmentStack))ScheduleR53Autosave();};
    }
    private void ScheduleR53Autosave()
    {
        if(_disposed)return;R53SaveStatus=SessionPath is null?"未保存 · 首次保存选择项目位置":"待保存";OnPropertyChanged(nameof(R53SaveStatus));
        if(SessionPath is not null){_r53Autosave.Stop();_r53Autosave.Start();}
    }
    private void NotifyR53Variants(){''');# can't schedule on Notify -> loops from autosave capture. schedule only explicit edits
s=s.replace('''NotifyR53Variants();StatusText="主变体已设置''','''NotifyR53Variants();ScheduleR53Autosave();StatusText="主变体已设置''');s=s.replace('''await SwitchEditVersionAsync(next.Id);NotifyR53Variants();''','''await SwitchEditVersionAsync(next.Id);NotifyR53Variants();ScheduleR53Autosave();''');s=s.replace('''NotifyR53Variants();StatusText="变体已删除''','''NotifyR53Variants();ScheduleR53Autosave();StatusText="变体已删除''');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.Session.cs';s=p.read_text().replace('''        InitializeVersionCommands();InitializeAnnotationUndo();''','''        InitializeVersionCommands();InitializeAnnotationUndo();InitializeR53Autosave();''').replace('''        SessionPath = Path.GetFullPath(path); OnPropertyChanged(nameof(SessionPath)); StatusText = "SessionSaved";''','''        SessionPath = Path.GetFullPath(path); OnPropertyChanged(nameof(SessionPath));R53SaveStatus="已保存";OnPropertyChanged(nameof(R53SaveStatus)); StatusText = "SessionSaved";''');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.cs';s=p.read_text();a=s.find('    public void Dispose()');print(s[a:a+700]);s=s.replace('''    public void Dispose()
    {''','''    public void Dispose()
    {
        _r53Autosave.Stop();''');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/Views/PhotoGradePageView.xaml';s=p.read_text().replace('''Text="暗室 · 本地项目  ●"''','''Text="{Binding R53SaveStatus}"''');p.write_text(s,encoding='utf8')
