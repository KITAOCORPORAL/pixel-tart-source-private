from pathlib import Path
r=Path('N:/pixart/guangjing-r53-stage-a-20261026')
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.R53.cs'
s=p.read_text(encoding='utf-8');old='private void NotifyR53Variants(){OnPropertyChanged';new='private void NotifyR53Variants(){Editor.ReadOnlyTarget=ActiveTarget?.EditVersions.FirstOrDefault(v=>v.Id==ActiveTarget.ActiveEditVersionId)?.IsOriginal==true;OnPropertyChanged';assert old in s;s=s.replace(old,new);p.write_text(s,encoding='utf-8')
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.Session.cs';s=p.read_text(encoding='utf-8');old='RefreshFilmstrip(); SessionPath = Path.GetFullPath(path);';assert old in s;s=s.replace(old,'NotifyR53Variants(); RefreshFilmstrip(); SessionPath = Path.GetFullPath(path);');p.write_text(s,encoding='utf-8')
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.ProfessionalRaw.cs';s=p.read_text(encoding='utf-8');old='CaptureEditVersion(target);await RefreshPreviewAnalysisAsync(token,image);';assert old in s;s=s.replace(old,'CaptureEditVersion(target);EnsureR53Variants(target);await RefreshPreviewAnalysisAsync(token,image);');p.write_text(s,encoding='utf-8')
p=r/'tests/RAWSelectionAssistant.WpfTests/R53DarkroomStageATests.cs';s=p.read_text(encoding='utf-8');i=s.index('    sealed class Dialogs(');s=s[:i]+'''    [TestMethod]
    public Task ReopenedOriginalRemainsReadOnlyAndF2ChildBecomesEditable() => RunSta(async () =>
    {
        EnsureTestApplication();
        var root = Path.Combine(Path.GetTempPath(), "r53-original-reopen-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(root);
        try
        {
            var dialogs = new Dialogs(root);
            using var vm = new ReferenceColorWorkspaceViewModel(dialogs);
            await vm.LoadTargetAsync(Image(root));
            var original = vm.R53Variants.Single(v => v.IsOriginal).Id;
            await vm.SwitchEditVersionAsync(original);
            var session = Path.Combine(root, "original.ptstudio.json");
            await vm.SaveSessionAsync(session);
            using var reopened = new ReferenceColorWorkspaceViewModel(dialogs);
            await reopened.LoadSessionAsync(session);
            Assert.AreEqual(original, reopened.ActiveTarget!.ActiveEditVersionId);
            Assert.IsTrue(reopened.Editor.ReadOnlyTarget);
            reopened.Editor.SetToolParameter(Exposure, 1);
            Assert.AreEqual(0d, reopened.Editor.ToolValue(Exposure));
            await reopened.CreateR53VariantAsync(true);
            Assert.IsFalse(reopened.Editor.ReadOnlyTarget);
            reopened.Editor.SetToolParameter(Exposure, .5);
            Assert.AreEqual(.5, reopened.Editor.ToolValue(Exposure));
        }
        finally { Directory.Delete(root, true); }
    });
''' +s[i:];p.write_text(s,encoding='utf-8')
p=r/'tests/RAWSelectionAssistant.WpfTests/ProfessionalRawWorkspaceTests.cs';s=p.read_text(encoding='utf-8-sig');i=s.index('    private static byte[] Pixels');s=s[:i]+'''    [TestMethod]
    public async Task R53OriginalToExistingProfessionalVariantRefreshesReadOnlyState()
    {
        var root = Path.Combine(Path.GetTempPath(), "R53-raw-identity-" + Guid.NewGuid());
        Directory.CreateDirectory(root);
        try
        {
            var input = Path.Combine(root, "synthetic.arw"); await File.WriteAllBytesAsync(input, [1,2,3]);
            using var vm = new ReferenceColorWorkspaceViewModel(new Dialogs(root), rawDecoder: new FakeLegacy(), professionalRawDecoder: new FakeLinear());
            await vm.LoadTargetAsync(input);
            await vm.CreateProfessionalRawCommand.ExecuteAsync(null);
            var professional = vm.ActiveTarget!.ActiveEditVersionId!.Value;
            await vm.SwitchEditVersionAsync(vm.R53Variants.Single(v => v.IsOriginal).Id);
            Assert.IsTrue(vm.Editor.ReadOnlyTarget);
            await vm.SwitchEditVersionAsync(professional);
            Assert.IsFalse(vm.Editor.ReadOnlyTarget);
            Assert.IsTrue(vm.IsProfessionalRaw);
            Assert.AreEqual(professional, vm.ActiveTarget.ActiveEditVersionId);
        }
        finally { Directory.Delete(root, true); }
    }
''' +s[i:];p.write_text(s,encoding='utf-8')