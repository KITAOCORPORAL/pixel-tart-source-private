from pathlib import Path
import subprocess,os,json,time
root=Path.cwd();r=root/'guangjing-r53-stage-a-20261026';out=root/'Guangjing-R53-Home-20261026';folder=out/'new-tests-r5';folder.mkdir();temp=folder/'temp';temp.mkdir();env=os.environ.copy();env.update(TEMP=str(temp),TMP=str(temp),KITAO_TEST_RESOURCE_ROOT=str(r),KITAO_R53_EVIDENCE=str(out/'synthetic-r5'),PIXEL_TART_ISOLATED_RUNTIME='1',PIXEL_TART_ISOLATED_RUNTIME_ROOT=str(folder/'runtime'));cmd=[r'C:\Program Files\dotnet\dotnet.exe','vstest',str(r/'tests/RAWSelectionAssistant.WpfTests/bin/x64/Release/net10.0-windows10.0.19041.0/RAWSelectionAssistant.WpfTests.dll'),'/TestCaseFilter:FullyQualifiedName~R53DarkroomStageATests','/Logger:trx;LogFileName=results.trx','/ResultsDirectory:'+str(folder)];start=time.time()
with (folder/'stdout.log').open('wb') as f:
 p=subprocess.Popen(cmd,cwd=r,env=env,stdout=f,stderr=f,creationflags=subprocess.CREATE_NO_WINDOW)
 try:code=p.wait(timeout=180)
 except subprocess.TimeoutExpired:subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],stdout=f,stderr=f);code=-999
(folder/'process.json').write_text(json.dumps(dict(command=cmd,pid=p.pid,startEpoch=start,endEpoch=time.time(),exitCode=code),indent=2));print(code)
