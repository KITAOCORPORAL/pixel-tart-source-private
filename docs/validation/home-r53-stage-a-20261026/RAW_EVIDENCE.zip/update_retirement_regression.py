from pathlib import Path
import re,subprocess
r=Path('N:/pixart/guangjing-r53-stage-a-20261026')
# Keep historical comments and internal diagnostic thread names; brand cleanup is user-facing.
for rel in ['src/RAWSelectionAssistant/Services/AppearanceService.cs','src/RAWSelectionAssistant/Services/CollageExportService.cs','src/RAWSelectionAssistant.Core/Services/AssetLibrary/SqliteAssetLibraryRepository.cs','src/RAWSelectionAssistant.Core/Services/Projects/PixelTartFilm.cs']:
 old=subprocess.check_output(['git','-C',str(r),'show','HEAD:'+rel]);(r/rel).write_bytes(old)
for p in (r/'src/RAWSelectionAssistant/Resources/DesignSystem').glob('*.xaml'):
 old=subprocess.check_output(['git','-C',str(r),'show','HEAD:'+str(p.relative_to(r)).replace('\\','/')]);p.write_bytes(old)
p=r/'src/RAWSelectionAssistant/MainWindow.xaml';s=p.read_text(encoding='utf-8');s=s.replace('                <MenuItem Header="新手教程" Command="{Binding HelpCommand}" />\n','')
old='<Border Style="{StaticResource PixelTart.SectionSurface}" Margin="0,10,0,0"><StackPanel><TextBlock Text="需要完整引导？" Style="{StaticResource SectionTitleText}" /><TextBlock Text="教程使用独立演示文件，不读取你的照片。" TextWrapping="Wrap" Margin="0,7,0,10" /><Button x:Name="HelpButton" Content="打开帮助与教程" Style="{StaticResource SecondaryButton}" HorizontalAlignment="Left" Command="{Binding HelpCommand}" /></StackPanel></Border>';assert old in s;s=s.replace(old,'');p.write_text(s,encoding='utf-8')
# Existing service tests keep unrelated migration, branding and safety checks. Replace only retired behavior.
p=r/'tests/RAWSelectionAssistant.Tests/OnboardingServiceTests.cs';s=p.read_text(encoding='utf-8-sig');a=s.index('    [TestMethod]');b=s.index('    [TestMethod]\n    public void ExistingUserDetection_',a);s=s[:a]+s[b:];a=s.index('    [TestMethod]\n    public async Task TutorialSandbox_');b=s.index('    [TestMethod]\n    public async Task TutorialFlow_',a);s=s[:a]+s[b:];s=s.replace('public async Task TutorialFlow_UsesRealIndexMatchCopyAndReportServices()','public async Task OrdinarySplit_UsesRealIndexMatchCopyAndReportServicesWithoutTutorial()').replace('        var data = new TutorialDataService(temp.Combine("AppData"));\n        var paths = await data.EnsureCreatedAsync();','        var paths = await SyntheticSplitFixture.CreateAsync(temp.Combine("AppData"));').replace('教程流程验收','正常分片验收');a=s.index('    private static async Task AdvanceToFinalStep');b=s.index('    private static string FindRepositoryRoot()',a);s=s[:a]+s[b:];a=s.index('    private sealed record OnboardingFixture(');s=s[:a]+'}\n';p.write_text(s,encoding='utf-8')
# A test-only synthetic source fixture replaces the deleted product tutorial generator.
original=subprocess.check_output(['git','-C',str(r),'show','HEAD:src/RAWSelectionAssistant.Core/Services/TutorialDataService.cs'],text=True,encoding='utf-8');base64=re.search(r'DemoJpegBase64 = "([^"]+)"',original)[1]
p=r/'tests/RAWSelectionAssistant.Tests/SyntheticSplitFixture.cs';p.write_text('''using RAWSelectionAssistant.Core.Models;
namespace RAWSelectionAssistant.Tests;
internal static class SyntheticSplitFixture
{
    public static async Task<TutorialSandboxPaths> CreateAsync(string root)
    {
        var paths = new TutorialSandboxPaths(root, Path.Combine(root,"Source"), Path.Combine(root,"Source/JPG"),
            Path.Combine(root,"Source/RAW"), Path.Combine(root,"CustomerSelection"), Path.Combine(root,"Output"),
            Path.Combine(root,"CustomerSelection/DSC01234.JPG"), Path.Combine(root,"CustomerSelection/选片编号.txt"));
        Directory.CreateDirectory(paths.JpegSource); Directory.CreateDirectory(paths.RawSource);
        Directory.CreateDirectory(paths.CustomerSelection); Directory.CreateDirectory(paths.Output);
        var jpeg = Convert.FromBase64String("'''+base64+'''");
        foreach (var number in new[]{"01234","01235","01236"})
        {
            await File.WriteAllBytesAsync(Path.Combine(paths.JpegSource,$"DSC{number}.JPG"),jpeg);
            await File.WriteAllTextAsync(Path.Combine(paths.RawSource,$"DSC{number}.ARW"),"synthetic match-only placeholder, not decoded RAW");
        }
        File.Copy(Path.Combine(paths.JpegSource,"DSC01234.JPG"),paths.CustomerJpeg);
        await File.WriteAllTextAsync(paths.SelectionText,"1235、DSC01236.JPG");
        return paths;
    }
}
''',encoding='utf-8')
p=r/'tests/RAWSelectionAssistant.Tests/CommercialEditionTests.cs';s=p.read_text(encoding='utf-8-sig');s=s.replace('new TutorialDataService(temp.Combine("tutorial")).EnsureCreatedAsync()','SyntheticSplitFixture.CreateAsync(temp.Combine("synthetic-split"))');p.write_text(s,encoding='utf-8')
p=r/'tests/RAWSelectionAssistant.Tests/OnboardingRequirementTests.cs';p.write_text('''using System.Text.Json;
using RAWSelectionAssistant.Core.Models;
using RAWSelectionAssistant.Core.Services;
namespace RAWSelectionAssistant.Tests;
[TestClass]
public sealed class OnboardingRequirementTests
{
    [TestMethod]
    [DataRow(false, 1, false)]
    [DataRow(false, 18, false)]
    [DataRow(true, 1, false)]
    [DataRow(true, 22, true)]
    public async Task FirstInstallUpgradeInterruptedAndCompletedNeverActivateAndPreserveSettings(bool existing, int step, bool completed)
    {
        using var temp = new TempDirectory();
        var settings = new AppSettings { OnboardingCurrentStep=step, OnboardingCompleted=completed,
            OnboardingVersion="1.2.0", OnboardingCompletionProof="historical-proof", OnboardingLegacyUser=existing,
            RecentProjectName="真实项目保持", RecentOutputDirectory=temp.Combine("photos"), OnboardingUpgradeOfferShown=false };
        var settingsService = new SettingsService(new TestLogService(),temp.Combine("settings.json"));
        await settingsService.SaveAsync(settings);
        var bytes = await File.ReadAllBytesAsync(temp.Combine("settings.json"));
        var data = new TutorialDataService(temp.Combine("profile"));
        var service = new OnboardingService(settingsService,data);
        await service.InitializeAsync(settings,existing);
        await service.AcceptUpgradeOfferAsync(true);
        await service.StartReplayAsync();
        await service.PerformAsync(TutorialAction.BeginTutorial,new());
        Assert.IsFalse(service.State.IsActive); Assert.IsFalse(service.State.IsRequired);
        Assert.IsFalse(service.NeedsUpgradeOffer); Assert.HasCount(0,service.Steps);
        Assert.IsTrue(Enum.GetValues<TutorialAction>().All(service.CanPerform));
        Assert.IsFalse(await service.BackAsync());
        Assert.IsFalse(Directory.Exists(data.Paths.Root));
        Assert.AreEqual("真实项目保持",settings.RecentProjectName);
        Assert.AreEqual(step,settings.OnboardingCurrentStep);
        CollectionAssert.AreEqual(bytes,await File.ReadAllBytesAsync(temp.Combine("settings.json")));
        var reopened = await settingsService.LoadAsync();
        var restarted = new OnboardingService(settingsService,new TutorialDataService(temp.Combine("profile")));
        await restarted.InitializeAsync(reopened,existing);
        Assert.IsFalse(restarted.State.IsActive); Assert.IsFalse(restarted.NeedsUpgradeOffer);
        CollectionAssert.AreEqual(bytes,await File.ReadAllBytesAsync(temp.Combine("settings.json")));
    }
    [TestMethod]
    public async Task RetiredExampleMethodsNeitherCreateNorDeleteOrOverwriteExistingData()
    {
        using var temp = new TempDirectory();
        var data = new TutorialDataService(temp.Combine("profile"));
        await data.EnsureCreatedAsync(); await data.ResetAsync();
        Assert.IsFalse(Directory.Exists(data.Paths.Root));
        Directory.CreateDirectory(data.Paths.Root);
        var file=Path.Combine(data.Paths.Root,"user-kept.jpg");await File.WriteAllBytesAsync(file,[1,4,7]);
        var outside=temp.CreateFile("real-photo.jpg",[2,3,5]);
        var settingsService=new SettingsService(new TestLogService(),temp.Combine("settings.json"));
        var service=new OnboardingService(settingsService,data);
        await service.InitializeAsync(new(),false);
        await service.EnsureTutorialDataAsync();await service.ResetTutorialDataAsync();service.DeleteTutorialData(data.Paths.Root);
        await data.EnsureCreatedAsync();await data.ResetAsync();data.Delete(data.Paths.Root);data.Delete(outside);
        CollectionAssert.AreEqual(new byte[]{1,4,7},await File.ReadAllBytesAsync(file));
        CollectionAssert.AreEqual(new byte[]{2,3,5},await File.ReadAllBytesAsync(outside));
        Assert.HasCount(1,Directory.GetFiles(data.Paths.Root));
    }
    [TestMethod]
    public async Task RetirementDoesNotNeedWritableSettingsAndDoesNotForgeCompletion()
    {
        using var temp=new TempDirectory();var blocked=temp.Combine("settings-directory");Directory.CreateDirectory(blocked);
        var service=new OnboardingService(new SettingsService(new TestLogService(),blocked),new TutorialDataService(temp.Combine("profile")));
        var settings=new AppSettings();await service.InitializeAsync(settings,false);await service.ExitAsync();
        Assert.IsFalse(service.State.IsActive);Assert.IsFalse(settings.OnboardingCompleted);
        Assert.IsFalse(OnboardingService.IsCompletionProofValid(settings));Assert.IsTrue(Directory.Exists(blocked));
    }
}
''',encoding='utf-8')
# Original tutorial tests are replaced, not ignored: the asserted product contract has intentionally retired.