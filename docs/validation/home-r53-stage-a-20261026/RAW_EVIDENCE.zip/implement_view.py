from pathlib import Path
r=Path.cwd()/'guangjing-r53-stage-a-20261026';p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.PhotoGradePage.cs';s=p.read_text().replace(' private bool _usePhotoGradePage;',' private bool _usePhotoGradePage=true;');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/Views/PhotoGradePageView.xaml';s=p.read_text();import re
s=re.sub(r'FontSize="(?:9|10)"','FontSize="11"',s);s=s.replace('''<ColumnDefinition Width="40"/><ColumnDefinition/><ColumnDefinition x:Name="SplitterColumn"''','''<ColumnDefinition Width="40"/><ColumnDefinition x:Name="ResourceColumn" Width="264"/><ColumnDefinition/><ColumnDefinition x:Name="SplitterColumn"''');s=s.replace('<Grid Grid.Column="1"><Grid.RowDefinitions><RowDefinition Height="28"/><RowDefinition/><RowDefinition Height="143"/></Grid.RowDefinitions>','''<Border x:Name="R53Resources" Grid.Column="1" Background="#1D1D20" BorderBrush="#303034" BorderThickness="0,0,1,0"><DockPanel><WrapPanel DockPanel.Dock="Top"><Button Content="预设" Click="R53PresetTab"/><Button Content="滤镜" Click="R53FilterTab"/><Button Content="即时胶片" Click="R53InstantTab"/></WrapPanel><ScrollViewer VerticalScrollBarVisibility="Auto"><StackPanel x:Name="R53ResourceContent" Margin="6"/></ScrollViewer></DockPanel></Border>
   <Grid Grid.Column="2"><Grid.RowDefinitions><RowDefinition Height="28"/><RowDefinition/><RowDefinition x:Name="R53NodeRow" Height="0"/><RowDefinition Height="143"/></Grid.RowDefinitions>''');s=s.replace('Grid.Column="2" HorizontalAlignment="Stretch"','Grid.Column="3" HorizontalAlignment="Stretch"').replace('Grid.Column="3" x:Name="RightPanel"','Grid.Column="4" x:Name="RightPanel"');s=s.replace('<Border Grid.Row="2" x:Name="FilmstripArea"','<Border Grid.Row="3" x:Name="FilmstripArea"');needle='''    <Border Grid.Row="3" x:Name="FilmstripArea"''';s=s.replace(needle,'''    <Border Grid.Row="2" x:Name="R53SerialNodes" Background="#18181B" Visibility="Collapsed"><DockPanel><TextBlock DockPanel.Dock="Top" Text="节点 · 串行处理顺序" Height="22"/><ListBox ItemsSource="{Binding Editor.AdjustmentNodes}" SelectedItem="{Binding Editor.SelectedAdjustmentNode,Mode=TwoWay}" Background="Transparent" BorderThickness="0" ScrollViewer.HorizontalScrollBarVisibility="Auto"><ListBox.ItemsPanel><ItemsPanelTemplate><StackPanel Orientation="Horizontal"/></ItemsPanelTemplate></ListBox.ItemsPanel><ListBox.ItemTemplate><DataTemplate><Border Width="132" Height="90" Margin="4" Padding="8" BorderBrush="#6E9B91" BorderThickness="1"><StackPanel><TextBlock Text="{Binding Type}"/><TextBlock Text="{Binding Name}" TextWrapping="Wrap"/><TextBlock Text="{Binding Enabled,StringFormat=可见 {0}}"/><TextBlock Text="{Binding IsLocked,StringFormat=锁定 {0}}"/></StackPanel></Border></DataTemplate></ListBox.ItemTemplate></ListBox></DockPanel></Border>
'''+needle)
s=s.replace('''<TextBlock Grid.Column="1" Text="{Binding TargetName}" HorizontalAlignment="Center"''','''<StackPanel Grid.Column="1" Orientation="Horizontal" HorizontalAlignment="Center"><Button Content="简单" Click="R53Simple"/><Button Content="专业" Click="R53Professional"/><Button Content="资源" Click="R53ToggleResources"/><Button Content="保存" Command="{Binding SaveSessionCommand}"/></StackPanel><TextBlock Grid.Column="1" Visibility="Collapsed" Text="{Binding TargetName}" HorizontalAlignment="Center"''')
s=s.replace('''<Button Content="{x:Null}" Tag="zoom" Click="ZoomTool" ToolTip="缩放"/>''','''<Button Content="{x:Null}" Tag="zoom" Click="ZoomTool" ToolTip="缩放"/><Button Content="画笔 B" Click="R53Brush" ToolTip="画笔；当前未批准局部蒙版管线时明确不可用"/><Button x:Name="R53HoldCompare" Content="调整前后 \\" ToolTip="按住查看调整前，松开恢复；反斜杠切换" PreviewMouseLeftButtonDown="R53CompareDown" PreviewMouseLeftButtonUp="R53CompareUp" LostMouseCapture="R53CompareLost"/>''')
s=s.replace('''<Button Content="适合" Click="FitPhoto"/>''','''<Button Content="适合" Click="FitPhoto"/><TextBlock Text="{Binding R53VariantStatus}" Margin="8,0"/>''')
s=s.replace('''<DockPanel><TextBlock x:Name="PanelTitle"''','''<DockPanel><Button DockPanel.Dock="Right" Content="◎ 3D 色彩" Click="R53Inspect3D"/><TextBlock x:Name="PanelTitle"''')
s=s.replace('''<WrapPanel><Button Content="从原图新建" Command="{Binding NewNormalLightPrintVariantCommand}"/><Button Content="克隆当前变体" Command="{Binding CreateEditVersionCommand}"/></WrapPanel>''','''<WrapPanel><Button Content="原始新建 F2" Click="R53NewOriginal"/><Button Content="复制当前 F3" Click="R53Duplicate"/><Button Content="设主变体" Click="R53SetMain"/><Button Content="删除变体" Command="{Binding ArchiveEditVersionCommand}"/><Button Content="撤销删除" Click="R53UndoDelete"/></WrapPanel>''');s=s.replace('ItemsSource="{Binding ActiveTarget.EditVersions}"','ItemsSource="{Binding R53Variants}"');# layer actions
s=s.replace('''<Button Content="删除" Command="{Binding Editor.DeleteAdjustmentNodeCommand}"/>''','''<Button Content="新建" Command="{Binding Editor.AddAdjustmentNodeCommand}" CommandParameter="BasicTone"/><Button Content="复制" Command="{Binding Editor.DuplicateAdjustmentNodeCommand}"/><Button Content="显隐" Command="{Binding Editor.ToggleAdjustmentNodeCommand}"/><Button Content="删除" Command="{Binding Editor.DeleteAdjustmentNodeCommand}"/><CheckBox Content="锁定" IsChecked="{Binding Editor.SelectedNodeLocked,Mode=TwoWay}"/>''')
s=s.replace('''<ListBox x:Name="OrderedSteps"''','''<TextBox Text="{Binding Editor.SelectedNodeName,UpdateSourceTrigger=LostFocus}" ToolTip="图层名称"/><ListBox x:Name="OrderedSteps"''')
p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/Views/PhotoGradePageView.xaml.cs';s=p.read_text().replace('''  InitializePanelLayout();''','''  InitializePanelLayout();InitializeR53();''');s=s.replace(''' private void OpenExport(object sender,RoutedEventArgs e){if(model is null)return;var window=new DarkroomExportDialog(model){Owner=Window.GetWindow(this)};window.ShowDialog();}''',''' private async void OpenExport(object sender,RoutedEventArgs e){if(model is null)return;await model.PrepareR53MainExportAsync();var window=new DarkroomExportDialog(model){Owner=Window.GetWindow(this)};window.ShowDialog();}''');s=s.replace('''  RestorePanelLayout();Refresh();UpdateZones();''','''  RestorePanelLayout();Refresh();UpdateZones();ApplyR53Layout();RenderR53Resources();''');p.write_text(s,encoding='utf8')
(r/'src/RAWSelectionAssistant/Views/PhotoGradePageView.R53.cs').write_text('''using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using RAWSelectionAssistant.ViewModels;
using RAWSelectionAssistant.Core.Services.Projects;
namespace RAWSelectionAssistant.Views;
public partial class PhotoGradePageView
{
    private bool r53ResourcesRequested=true,r53CompareHeld;
    private string r53ResourceTab="预设";
    private Window? r53Inspect;
    private void InitializeR53()
    {
        SizeChanged+=(_,_)=>ApplyR53Layout();
        PreviewKeyDown+=async(_,e)=>
        {
            if(Keyboard.FocusedElement is TextBox or ComboBox || model is null)return;
            if(Keyboard.Modifiers==ModifierKeys.Control&&e.Key is Key.D1 or Key.D2){model.R53Professional=e.Key==Key.D2;ApplyR53Layout();e.Handled=true;return;}
            if(Keyboard.Modifiers!=ModifierKeys.None)return;
            if(e.Key==Key.B){R53Brush(this,new());e.Handled=true;}
            else if(e.Key==Key.Oem5){model.Editor.ViewMode=model.Editor.ViewMode=="原片"?"仿色结果":"原片";e.Handled=true;}
            else if(e.Key==Key.F2){await model.CreateR53VariantAsync(true);e.Handled=true;}
            else if(e.Key==Key.F3){await model.CreateR53VariantAsync(false);e.Handled=true;}
            else if(e.Key==Key.Escape){r53Inspect?.Close();}
        };
        Unloaded+=(_,_)=>{model?.Editor.HoldOriginal(false);r53Inspect?.Close();};
    }
    internal void ApplyR53Layout()
    {
        if(R53Resources is null)return;
        // ActualWidth is the WPF client DIP width; no resolution or DPI heuristic.
        var width=ActualWidth>0?ActualWidth:Width;var professional=model?.R53Professional==true;
        var resources=r53ResourcesRequested&&width>=1200;
        ResourceColumn.Width=new GridLength(resources?264:0);R53Resources.Visibility=resources?Visibility.Visible:Visibility.Collapsed;
        if(width<1440){SetPanelOpen(false);}else if(RightPanel.Visibility!=Visibility.Visible)SetPanelOpen(true);
        R53SerialNodes.Visibility=professional?Visibility.Visible:Visibility.Collapsed;R53NodeRow.Height=new GridLength(professional?132:0);
        if(professional)EditModes.SelectedIndex=2;
    }
    private void R53Simple(object s,RoutedEventArgs e){if(model is not null)model.R53Professional=false;ApplyR53Layout();EditModes.SelectedIndex=0;}
    private void R53Professional(object s,RoutedEventArgs e){if(model is not null)model.R53Professional=true;ApplyR53Layout();}
    private void R53ToggleResources(object s,RoutedEventArgs e){r53ResourcesRequested=!r53ResourcesRequested;ApplyR53Layout();if(ActualWidth<1200){var menu=new ContextMenu{PlacementTarget=(UIElement)s};foreach(var (name,type) in new[]{("基础调色","BasicTone"),("白平衡","WhiteBalance"),("曲线","Curve"),("色轮","ColorBalance"),("HSL","Hsl")})menu.Items.Add(new MenuItem{Header=name,Command=model?.Editor.AddAdjustmentNodeCommand,CommandParameter=type});menu.IsOpen=true;}}
    private void R53Brush(object s,RoutedEventArgs e){activeTool="画笔";ToolLabel.Text="画笔 · 当前局部蒙版尚未批准接入";ToolHint.Text="不可用：未连接真实蒙版渲染，不生成假蒙版";}
    private void R53CompareDown(object s,MouseButtonEventArgs e){if(model is null)return;r53CompareHeld=true;model.Editor.HoldOriginal(true);R53HoldCompare.CaptureMouse();e.Handled=true;}
    private void R53CompareUp(object s,MouseButtonEventArgs e){R53CompareLost(s,e);R53HoldCompare.ReleaseMouseCapture();e.Handled=true;}
    private void R53CompareLost(object s,MouseEventArgs e){if(r53CompareHeld)model?.Editor.HoldOriginal(false);r53CompareHeld=false;}
    private async void R53NewOriginal(object s,RoutedEventArgs e){if(model is not null)await model.CreateR53VariantAsync(true);}
    private async void R53Duplicate(object s,RoutedEventArgs e){if(model is not null)await model.CreateR53VariantAsync(false);}
    private void R53SetMain(object s,RoutedEventArgs e)=>model?.SetR53MainVariant();
    private async void R53UndoDelete(object s,RoutedEventArgs e){if(model is not null)await model.UndoR53VariantDeleteAsync();}
    private void R53PresetTab(object s,RoutedEventArgs e){r53ResourceTab="预设";RenderR53Resources();}
    private void R53FilterTab(object s,RoutedEventArgs e){r53ResourceTab="滤镜";RenderR53Resources();}
    private void R53InstantTab(object s,RoutedEventArgs e){r53ResourceTab="即时胶片";RenderR53Resources();EditModes.SelectedIndex=1;}
    private void RenderR53Resources()
    {
        if(R53ResourceContent is null)return;R53ResourceContent.Children.Clear();
        void Add(string name,Action action){var b=new Button{Content=name,Height=30,HorizontalContentAlignment=HorizontalAlignment.Left,Margin=new Thickness(0,3,0,3)};b.Click+=(_,_)=>action();R53ResourceContent.Children.Add(b);}
        if(r53ResourceTab=="即时胶片"){foreach(var paper in model?.PhotographerPapers??[])Add(paper.Name,()=>{if(model is not null){model.SelectedPhotographerPaperId=paper.ProfileId;EditModes.SelectedIndex=1;}});return;}
        if(r53ResourceTab=="滤镜"){Add("胶片风格（现有处理链）",()=>EditModes.SelectedIndex=3);return;}
        foreach(var (name,type) in new[]{("基础调色","BasicTone"),("白平衡","WhiteBalance"),("曲线","Curve"),("色轮","ColorBalance"),("HSL","Hsl")})Add(name,()=>model?.Editor.AddAdjustmentNodeCommand.Execute(type));
        foreach(var scheme in model?.Editor.ColorSchemes??[])Add(scheme.Name,()=>{if(model is not null){model.Editor.SelectedColorScheme=scheme;model.Editor.RequestApplySchemeCommand.Execute(null);}});
    }
    private void R53Inspect3D(object s,RoutedEventArgs e)
    {
        if(model is null)return;if(r53Inspect is {IsVisible:true}){r53Inspect.Activate();return;}
        // A 420x300 inspector cannot fit the 264 DIP resource rail. Explicit focused
        // inspection window; owner is disabled only while the user requests this view.
        var content=new StackPanel();content.Children.Add(new TextBlock{Text="3D 色彩 · 当前图像数据检查",FontSize=14,Margin=new Thickness(8)});
        var cloud=new ColorSpace3DViewport{MinWidth=420,MinHeight=300,Height=340};content.Children.Add(cloud);
        var build=new Button{Content="从当前图像生成",Command=model.BuildColorSpaceModelCommand};content.Children.Add(build);
        var back=new Button{Content="返回主图"};content.Children.Add(back);
        r53Inspect=new Window{Title="光镜 · 专注色彩检查",Owner=Window.GetWindow(this),MinWidth=452,MinHeight=400,Width=620,Height=520,Content=content,Background=new SolidColorBrush(Color.FromRgb(29,29,32)),WindowStartupLocation=WindowStartupLocation.CenterOwner};
        back.Click+=(_,_)=>r53Inspect.Close();r53Inspect.Closed+=(_,_)=>r53Inspect=null;r53Inspect.Show();
    }
}
''',encoding='utf8')
