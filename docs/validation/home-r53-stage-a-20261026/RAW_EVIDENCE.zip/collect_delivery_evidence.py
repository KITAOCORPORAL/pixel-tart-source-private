from pathlib import Path
import subprocess,json,hashlib,zipfile,xml.etree.ElementTree as ET,shutil,datetime
root=Path('N:/pixart');out=root/'Guangjing-R53-Home-20261026';r=root/'guangjing-r53-stage-a-20261026';v=r/'docs/validation/home-r53-stage-a-20261026';final=out/'final-r6';pkg=out/'Guangjing-R53-StageA-Diagnostic-win-x64';base='48527fa0b7d3d063d5af5f6b62fa1a18cb36ef66';sha='592ecccb5e71d2a798a52196110717c936d0566f'
def h(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def js(p,o):p.write_text(json.dumps(o,ensure_ascii=False,indent=2),encoding='utf-8')
def git(*a,cwd=r):return subprocess.check_output(['git','-C',str(cwd),*a],text=True,encoding='utf-8').strip()
# Narrow recheck of the exact previously inventoried worktrees. No source files modified.
before=json.loads((out/'worktrees-before.json').read_text(encoding='utf-8-sig'));after=[]
for x in before:
 p=Path(x['path']);now=dict(path=x['path'],head=git('rev-parse','HEAD',cwd=p),branch=git('branch','--show-current',cwd=p),status=git('status','--porcelain','--untracked-files=all',cwd=p).splitlines(),unpushed=git('log','--oneline','HEAD','--not','--remotes=origin',cwd=p).splitlines());after.append(now)
js(out/'worktrees-after.json',after)
js(v/'PRESERVATION.json',dict(beforeWorktrees=len(before),afterRechecked=len(after),unchanged=[dict(path=a['path'],sameHead=a['head']==b['head'],sameBranch=a['branch']==b['branch'],sameStatus=a['status']==b['status'],unpushed=b['unpushed']) for a,b in zip(before,after)],originalDirtyEntries=sum(len(x['status']) for x in before),newWorktree=str(r),newBranch=git('branch','--show-current'),forbiddenOperationsUsed=False,scope='Exact old worktree status/HEAD recheck only; no repeated full disk/ZIP scan'))
assert all(a['head']==b['head'] and a['branch']==b['branch'] and a['status']==b['status'] for a,b in zip(before,after))
shutil.copy2(out/'design-manifest.json',v/'DESIGN_MANIFEST.json')
shutil.copy2(out/'registered-before.txt',v/'WORKTREES_REGISTERED_BEFORE.txt')
js(v/'DESIGN_SOURCE.json',dict(zip='C:/Users/Admin/Downloads/Compressed/光镜-UI-R5.3-定稿.zip',sha256=h(Path('C:/Users/Admin/Downloads/Compressed/光镜-UI-R5.3-定稿.zip')),referenceRoot=str(out/'design-reference'),read=['UI设计规划文档-R5.3.md','dev-spec-r5.md','layout-directions.md','01-暗室/darkroom-r5.html','01-暗室/instant-r3.html','01-暗室/frames-collab-pack.js','01-暗室/instant-port-check.md','02-自由画布拼贴/collage-r5.html','03-策划中心/planning-r5.html'],viewed=['01-暗室/screenshots/01-暗室简易.png','01-暗室/screenshots/02-暗室专业.png','01-暗室/sketches/sketch-B.png'],webPrototypeExecuted=False,thirdPartyResourcesCopiedIntoProduct=False,prototype175NotProductAcceptance=True))
assert json.loads((v/'DESIGN_SOURCE.json').read_text(encoding='utf-8'))['sha256']=='16f75c0f40b506e4db57f140f389967264040cd8c5930ad24946b11c171e2ca9'
# Final authoritative totals and nonpass, preserve every old run separately.
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};summary={};nonpass=[];runs=[]
for label in ['core','wpf']:
 doc=ET.parse(final/f'tests-{label}/results.trx');c=doc.find('t:ResultSummary/t:Counters',ns).attrib
 summary[label]=dict(total=int(c['total']),passed=int(c['passed']),failed=int(c['failed']),notRun=sum(x.attrib['outcome']=='NotExecuted' for x in doc.findall('t:Results/t:UnitTestResult',ns)),sourceSha=sha)
 for x in doc.findall('t:Results/t:UnitTestResult',ns):
  if x.attrib['outcome']!='Passed':nonpass.append(dict(host=label,name=x.attrib['testName'],outcome=x.attrib['outcome'],message=' '.join(t.strip() for t in x.itertext() if t.strip())))
for path in sorted(out.rglob('*.trx')):
 if pkg in path.parents:continue
 try:
  doc=ET.parse(path);c=doc.find('t:ResultSummary/t:Counters',ns).attrib;errors=[]
  for x in doc.findall('t:Results/t:UnitTestResult',ns):
   if x.attrib['outcome']=='Failed':errors.append(dict(name=x.attrib['testName'],message=' '.join(t.strip() for t in x.itertext() if t.strip())[:2400]))
  runs.append(dict(path=str(path.relative_to(out)),sha256=h(path),counts=c,failures=errors,authoritative=path.parent in [final/'tests-core',final/'tests-wpf']))
 except ET.ParseError:pass
js(v/'TEST_SUMMARY.json',summary);js(v/'NONPASS.json',nonpass);js(v/'DEVELOPMENT_RUNS.json',runs)
shutil.copy2(final/'bindings.json',v/'COMPONENT_BINDINGS.json')
js(v/'BUILDS.json',{x:json.loads((final/f'{x}-build.json').read_text(encoding='utf-8')) for x in ['publish','core','wpf']})
js(v/'CHANGED_FILES.json',dict(baseSha=base,sourceSha=sha,files=git('diff','--name-status',base,sha).splitlines(),commits=git('log','--format=%H %s',base+'..'+sha).splitlines()))
# Runtime dependencies: all runtime/native/resources declared in the shipped deps manifest.
app=pkg/'app';deps=json.loads((app/'KitaoPhotoSelector.deps.json').read_text(encoding='utf-8'));dep=[]
for target,libraries in deps['targets'].items():
 for library,entry in libraries.items():
  for kind in ['runtime','native','resources']:
   for path in entry.get(kind,{}):
    p=app/path
    if not p.exists() and kind!='resources':p=app/Path(path).name
    dep.append(dict(target=target,library=library,kind=kind,path=path,present=p.is_file()))
js(v/'DEPENDENCIES.json',dep);assert all(x['present'] for x in dep),[x for x in dep if not x['present']]
files=[dict(path=str(p.relative_to(app)).replace('\\','/'),bytes=p.stat().st_size,sha256=h(p)) for p in sorted(app.rglob('*')) if p.is_file()];js(v/'APP_FILES.json',dict(sourceSha=sha,count=len(files),totalBytes=sum(x['bytes'] for x in files),files=files))
# Raw evidence compact archive: generated logs/TRX/scripts only; no source/user DB/private images/runtime.
raw=[]
for p in sorted(out.rglob('*')):
 if not p.is_file() or pkg in p.parents or (out/'design-reference') in p.parents or p.suffix.lower() not in ['.trx','.log','.py','.json']:continue
 rel=p.relative_to(out);parts=rel.parts
 if any(x in ['app','test-runtime','runtime','temp','UserData','.kitao-export-tasks'] for x in parts):continue
 if 'native-final-runtime' in parts or any(x.endswith('runtime') for x in parts):continue
 if p.stat().st_size>8*1024*1024:continue
 raw.append((p,str(rel).replace('\\','/')))
archive=v/'RAW_EVIDENCE.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,6) as z:
 for p,name in raw:z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for p,name in raw:assert hashlib.sha256(z.read(name)).hexdigest()==h(p)
js(v/'RAW_MANIFEST.json',dict(archive='RAW_EVIDENCE.zip',sha256=h(archive),bytes=archive.stat().st_size,readback=True,files=[dict(path=n,bytes=p.stat().st_size,sha256=h(p)) for p,n in raw]))
# WPF output is OFFSCREEN, never desktop.
(v/'images').mkdir()
for p in sorted((final/'samples').glob('offscreen-*.png')):shutil.copy2(p,v/'images'/p.name)
js(v/'IMAGE_PROVENANCE.json',dict(sourceSha=sha,kind='RenderTargetBitmap offscreen WPF rendering',nativeScreenshot=False,physicalDpiVerified=False,files=[dict(path='images/'+p.name,sha256=h(p)) for p in (v/'images').glob('*.png')]))
# Include only approved synthetic planning inputs, no workspace cross-machine claim.
samples=pkg/'samples/planning';samples.mkdir()
src=r/'docs/validation/home-planning-owned-canvas-20261025/samples'
for name in ['native-project-a-v1.ptplan','native-project-b-v1.ptplan','jpeg-shot-missing-v1.ptplan','jpeg-owned-v1.ptplan','replacement-shot.jpg','project-b.png','README.md']:shutil.copy2(src/name,samples/name)
# Historical performance is an existing raw household pass, never current source performance.
shutil.copy2(r/'docs/validation/home-planning-owned-canvas-20261025/HISTORICAL_HOME_SCENARIO11.json',v/'HISTORICAL_HOME_SCENARIO11.json')
print(json.dumps(dict(tests=summary,oldTreesUnchanged=True,dependencies=len(dep),appFiles=len(files),rawArchiveBytes=archive.stat().st_size),ensure_ascii=False,indent=2))