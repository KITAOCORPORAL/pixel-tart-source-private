from pathlib import Path
import re
r=Path('N:/pixart/guangjing-r53-stage-a-20261026')
p=r/'src/RAWSelectionAssistant/ViewModels/MainViewModel.cs';s=p.read_text(encoding='utf-8').replace('public string ThemeSummary => "PixelTart Dark Theme";','public string ThemeSummary => "光镜深色主题";');p.write_text(s,encoding='utf-8')
p=r/'installer/RAWSelectionAssistant.iss';s=p.read_text(encoding='utf-8');s=''.join(line.replace('像素蛋挞','光镜') if line.startswith('OutputBaseFilename=') else line for line in s.splitlines(keepends=True));p.write_text(s,encoding='utf-8')
p=r/'README.md';s=p.read_text(encoding='utf-8-sig');s=s.replace('# 像素蛋挞\n\n','').replace('像素蛋挞是一款','光镜是一款');a=s.index('## 首次新手教程');b=s.index('“帮助 → 建议与问题反馈”',a);s=s[:a]+'''## 产品引导状态

旧“新手分片”教程已取消。新安装、旧用户升级及未完成教程的旧设置均不会再自动打开教程；帮助中不再提供重看、重置或删除教程入口。正常分片/归片功能、必要安全说明和操作反馈继续保留。旧 Tutorial 目录及用户文件不自动删除、不生成新教程示例。

本批为完整应用诊断版，无安装包、不能发行；运行入口与验证边界见 `docs/validation/home-r53-stage-a-20261026/FINAL_REPORT.md`。历史安装位置与内部兼容目录保持，下面旧安装文件名仅是历史记录，不是本批交付。

'''+s[b:];s=s.replace('基础 CSV 报告和完整教程','基础 CSV 报告').replace('打开“像素蛋挞”','打开“光镜”');p.write_text(s,encoding='utf-8')
p=r/'docs/PRODUCT_BACKLOG.md';p.write_text('''# 光镜产品待办

## 统一产品引导（未开发，后置）

全部功能完成且交互稳定后，集中制作覆盖光镜所有功能的产品引导与说明教程。

以届时实际交付功能为准，覆盖完整摄影师工作流、各模块操作及跨模块衔接。不沿用旧“新手分片”22步教程，不在当前批次开发替代教程。

## R5.3 当前入口

先完成阶段 A 剩余的真实局部蒙版、通用混合/强度与2–4变体同步对比及原生验收，再按用户指定顺序推进 B/C/D/E。像素结果改变须满足开源实现研究、版本和数值门禁；旧模块存在不代表 R5.3 全量完成。
''',encoding='utf-8')
# Update obsolete UI-only tests to assert removal; unrelated close/safety contracts remain.
def replace_method(path,name,body):
 p=r/path;s=p.read_text(encoding='utf-8-sig');a=s.index('    [TestMethod]',s.index('public sealed class'))
 m=re.search(r'    \[TestMethod\]\s+public (?:async )?(?:void|Task) '+re.escape(name)+r'\([^)]*\)',s)
 assert m,(path,name)
 start=m.start();open=s.index('{',m.end());depth=1;i=open+1
 # These selected static-test methods have braces in strings; find next attribute/private boundary instead.
 nxt=s.find('\n    [TestMethod]',open)
 if nxt<0:nxt=s.find('\n    private ',open)
 assert nxt>=0
 s=s[:start]+'    [TestMethod]\n    public void '+name+'()\n    {\n'+body+'\n    }\n'+s[nxt:];p.write_text(s,encoding='utf-8')
replace_method('tests/RAWSelectionAssistant.WpfTests/GlobalSurfaceCloseSmokeTests.cs','TutorialButtonTutorialXAndEscape_ConvergeOnSingleForceExitTutorial','''        var mainView = Read("src/RAWSelectionAssistant/MainWindow.xaml");
        Assert.IsFalse(mainView.Contains("TutorialOverlay", StringComparison.Ordinal));
        Assert.IsFalse(mainView.Contains("TutorialExitButton", StringComparison.Ordinal));
        Assert.IsFalse(mainView.Contains("新手教程", StringComparison.Ordinal));
        ContainsAll(Read("src/RAWSelectionAssistant/MainWindow.xaml.cs"), "await RequestEscapeCloseAsync()", "ForceCloseCurrentSurface()");''')
p=r/'tests/RAWSelectionAssistant.WpfTests/GlobalSurfaceCloseSmokeTests.cs';s=p.read_text(encoding='utf-8');s=s.replace('"if (_viewModel?.IsOnboardingActive == true && e.Key == Key.Tab)"','"if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.B)"');p.write_text(s,encoding='utf-8')
p=r/'tests/RAWSelectionAssistant.WpfTests/SingleCloseAuthorityTests.cs';s=p.read_text(encoding='utf-8-sig');a=s.index('        var tutorial = Named(document, "TutorialOverlay").Single();');b=s.index('\n    }',a);s=s[:a]+'''        Assert.HasCount(0, Named(document, "TutorialOverlay"));
        Assert.IsFalse(main.Contains("TutorialCalloutCloseButton", StringComparison.Ordinal));
'''+s[b:];s=s.replace('            ("教程", 0, SurfaceCloseButtons(Named(main, "TutorialOverlay").Single()).Count()),\n','');p.write_text(s,encoding='utf-8')
replace_method('tests/RAWSelectionAssistant.WpfTests/ModalCloseSmokeTests.cs','TutorialOverlay_LeavesCardInteractiveAndExitAccessible','''        var xaml = Read("src/RAWSelectionAssistant/MainWindow.xaml");
        Assert.IsFalse(xaml.Contains("TutorialOverlay", StringComparison.Ordinal));
        Assert.IsFalse(xaml.Contains("TutorialMask", StringComparison.Ordinal));
        StringAssert.Contains(Read("src/RAWSelectionAssistant/MainWindow.xaml.cs"), "CloseCurrentSurfaceAsync");''')
replace_method('tests/RAWSelectionAssistant.WpfTests/ModalCloseSmokeTests.cs','TutorialStep18Failure_OffersRetryRecreateBackAndExitWithoutBusyDeadlock','''        var xaml = Read("src/RAWSelectionAssistant/MainWindow.xaml");
        foreach (var token in new[] { "TutorialRetryCommand", "TutorialRecreateDataCommand", "TutorialBackCommand", "TutorialExitButton_Click" })
            Assert.IsFalse(xaml.Contains(token, StringComparison.Ordinal));
        StringAssert.Contains(xaml, "ExportReportCommand");''')
replace_method('tests/RAWSelectionAssistant.WpfTests/Version230Rc3RuntimeUiTests.cs','UpgradeTutorialButtons_CloseSafelyInModalAndRuntimeReviewWindows','''        Assert.IsFalse(File.Exists(Path.Combine(Root(), "src/RAWSelectionAssistant/Views/UpgradeTutorialWindow.xaml")));
        var shell = File.ReadAllText(Path.Combine(Root(), "src/RAWSelectionAssistant/MainWindow.xaml.cs"));
        Assert.IsFalse(shell.Contains("offer.ShowDialog()", StringComparison.Ordinal));
        Contains("src/RAWSelectionAssistant/Views/HelpWindow.xaml", "DynamicResource WindowBackgroundBrush");''')
p=r/'tests/RAWSelectionAssistant.Tests/UiDesignSystem140Tests.cs';s=p.read_text(encoding='utf-8-sig');s=s.replace(', "TutorialPrimaryButton"','');s=s.replace('public void TutorialOfferDialog_UsesDynamicTheme() => Contains("src/RAWSelectionAssistant/Views/UpgradeTutorialWindow.xaml",','public void ProductHelpDialog_UsesDynamicTheme() => Contains("src/RAWSelectionAssistant/Views/HelpWindow.xaml",');# help now only one dynamic text resource yes
s=s.replace('"像素蛋挞_Setup_2.3.0_RC1_x64", "像素蛋挞_Setup_2.3.0_x64"','"光镜_Setup_2.3.0_RC1_x64", "光镜_Setup_2.3.0_x64"');p.write_text(s,encoding='utf-8')