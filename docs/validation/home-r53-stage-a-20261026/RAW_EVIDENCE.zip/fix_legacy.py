from pathlib import Path
r=Path.cwd()/'guangjing-r53-stage-a-20261026'
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/StudioEditVersion.cs';s=p.read_text().replace('    public bool IsMain {get;init;}','    public bool IsMain {get;init;}\n    public bool MainExplicit {get;init;}');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.Versions.cs';s=p.read_text().replace('IsMain=existing?.IsMain??false,Rating','IsMain=existing?.IsMain??false,MainExplicit=existing?.MainExplicit??false,Rating');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.R53.cs';s=p.read_text().replace('IsOriginal=false,IsMain=false,Archived=false','IsOriginal=false,IsMain=false,MainExplicit=false,Archived=false');s=s.replace('target.EditVersions[i] with{IsMain=target.EditVersions[i].Id==target.ActiveEditVersionId}','target.EditVersions[i] with{IsMain=target.EditVersions[i].Id==target.ActiveEditVersionId,MainExplicit=target.EditVersions[i].Id==target.ActiveEditVersionId}');s=s.replace('''    {CaptureEditVersion(target);EnsureR53Variants(target);return target.EditVersions.Single(v=>v.IsMain&&!v.Archived);}''','''    {
        CaptureEditVersion(target);EnsureR53Variants(target);
        // Old projects have no explicit main choice. Their historical output remains the
        // selected valid edit, rather than silently exporting a newly migrated empty original.
        if(!target.EditVersions.Any(v=>v.MainExplicit&&!v.Archived))
            for(int i=0;i<target.EditVersions.Count;i++)target.EditVersions[i]=target.EditVersions[i] with{IsMain=target.EditVersions[i].Id==target.ActiveEditVersionId};
        return target.EditVersions.Single(v=>v.IsMain&&!v.Archived);
    }''');s=s.replace('''        var main=target.EditVersions.Single(v=>v.IsMain&&!v.Archived);await SwitchEditVersionAsync(main.Id);''','''        var main=MainOutputVersion(target);await SwitchEditVersionAsync(main.Id);''');# explicit deleted original main should remain explicit until undo
s=s.replace('''active with{Archived=true,IsMain=false}''','''active with{Archived=true,IsMain=false,MainExplicit=false}''').replace('''target.EditVersions[n] with{IsMain=true}''','''target.EditVersions[n] with{IsMain=true,MainExplicit=active.MainExplicit}''');p.write_text(s,encoding='utf8')
p=r/'tests/RAWSelectionAssistant.WpfTests/R53DarkroomStageATests.cs';s=p.read_text().replace('''var main=vm.ActiveTarget!.ActiveEditVersionId;await vm.CreateR53VariantAsync(false);''','''var main=vm.ActiveTarget!.ActiveEditVersionId;vm.SetR53MainVariant();await vm.CreateR53VariantAsync(false);''');p.write_text(s,encoding='utf8')
# serialize project autosave/manual-save using same source snapshot guard
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.Session.cs';s=p.read_text();needle='''    public async Task SaveSessionAsync(string path, CancellationToken token = default)
    {''';assert needle in s;s=s.replace(needle,'''    private readonly SemaphoreSlim _projectSaveGate=new(1,1);
    public async Task SaveSessionAsync(string path,CancellationToken token=default)
    {
        await _projectSaveGate.WaitAsync(token);
        try{await SaveSessionCoreAsync(path,token);}finally{_projectSaveGate.Release();}
    }
    private async Task SaveSessionCoreAsync(string path, CancellationToken token = default)
    {''');p.write_text(s,encoding='utf8')
# Simple mode now has the live stack and lock/name/visibility where the adjustment controls are.
p=r/'src/RAWSelectionAssistant/Views/PhotoGradePageView.xaml';s=p.read_text();needle='''<ScrollViewer Grid.Row="2" x:Name="AdjustmentScroll"''';a=s.index(needle);b=s.index('<StackPanel>',a)+len('<StackPanel>');s=s[:b]+'''<Expander Header="图层 · 共享串行栈" IsExpanded="True"><StackPanel><ListBox MaxHeight="150" ItemsSource="{Binding Editor.AdjustmentNodes}" SelectedItem="{Binding Editor.SelectedAdjustmentNode,Mode=TwoWay}" DisplayMemberPath="Name" Background="Transparent" BorderThickness="0"/><TextBox Text="{Binding Editor.SelectedNodeName,UpdateSourceTrigger=LostFocus}" ToolTip="选中图层名称"/><WrapPanel><Button Content="显隐" Command="{Binding Editor.ToggleAdjustmentNodeCommand}"/><Button Content="复制" Command="{Binding Editor.DuplicateAdjustmentNodeCommand}"/><Button Content="删除" Command="{Binding Editor.DeleteAdjustmentNodeCommand}"/><CheckBox Content="锁定" IsChecked="{Binding Editor.SelectedNodeLocked,Mode=TwoWay}"/></WrapPanel></StackPanel></Expander>'''+s[b:];p.write_text(s,encoding='utf8')
# Relevant existing tests change only identity/layout assumptions replaced by R53 contract.
p=r/'tests/RAWSelectionAssistant.WpfTests/ColorStudioFilmstripStateTests.cs';s=p.read_text().replace('var first=target.EditVersions[0].Id;','var first=target.EditVersions.First(v=>!v.IsOriginal).Id;').replace('Assert.HasCount(2,reopened.ActiveTarget!.EditVersions);','Assert.HasCount(2,reopened.ActiveTarget!.EditVersions.Where(v=>!v.IsOriginal));Assert.HasCount(1,reopened.ActiveTarget.EditVersions.Where(v=>v.IsOriginal));');p.write_text(s,encoding='utf8')
for p in (r/'tests/RAWSelectionAssistant.WpfTests').glob('*.cs'):
 s=p.read_text(encoding='utf-8-sig')
 if 'ProductRepositorySharesVersionsAcrossWorkspacesWithoutPathIdentity' in s:
  print('repo test',p.name);s=s.replace('Assert.HasCount(2,second.ActiveTarget.EditVersions)','Assert.HasCount(2,second.ActiveTarget.EditVersions.Where(v=>!v.IsOriginal))');p.write_text(s,encoding='utf8')
p=r/'tests/RAWSelectionAssistant.WpfTests/LightPrintR3Tests.cs';s=p.read_text();s=s.replace('Assert.AreEqual(304d,panel.ActualWidth);Assert.IsTrue(viewer.ActualWidth>size.Width*.65);','Assert.AreEqual(size.Width<1440?0d:304d,panel.ActualWidth);Assert.IsTrue(viewer.ActualWidth>560);');p.write_text(s,encoding='utf8')
