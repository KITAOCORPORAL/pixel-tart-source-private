from pathlib import Path
r=Path('N:/pixart/guangjing-r53-stage-a-20261026')
p=r/'tests/RAWSelectionAssistant.WpfTests/GlobalSurfaceCloseSmokeTests.cs';s=p.read_text(encoding='utf-8').replace('ContainsAll(main, "HasTutorialError", "SurfaceCloseButton");','ContainsAll(main, "SurfaceCloseButton");\n        Assert.IsFalse(main.Contains("HasTutorialError", StringComparison.Ordinal));');p.write_text(s,encoding='utf-8')
p=r/'tests/RAWSelectionAssistant.WpfTests/ModalCloseSmokeTests.cs';s=p.read_text(encoding='utf-8').replace('StringAssert.Contains(Read("src/RAWSelectionAssistant/MainWindow.xaml.cs"), "CloseCurrentSurfaceAsync");','StringAssert.Contains(Read("src/RAWSelectionAssistant/MainWindow.xaml.cs"), "await RequestEscapeCloseAsync()");');p.write_text(s,encoding='utf-8')
p=r/'tests/RAWSelectionAssistant.WpfTests/InputRoutingHitTestSmokeTests.cs';s=p.read_text(encoding='utf-8-sig').replace('"WorkbenchRoot", "SidebarRoot", "TutorialCalloutCloseButton", "TutorialExitButton",','"WorkbenchRoot", "SidebarRoot",');s=s.replace('''        ContainsAll(mainXaml,
            "services:ShellEscapePointer.Action=\\"ExitTutorial\\"",
            "AutomationProperties.AutomationId=\\"TutorialExitButton\\"");''','''        Assert.IsFalse(mainXaml.Contains("TutorialExitButton", StringComparison.Ordinal));''')
a=s.index('        var tutorial = NamedElement(document, "TutorialOverlay");');b=s.index('        Assert.IsTrue(string.Equals(Attribute(emergency',a);s=s[:a]+'''        var emergency = NamedElement(document, "ShellSurfaceCloseButton");
        Assert.IsFalse(mainXaml.Contains("TutorialOverlay", StringComparison.Ordinal));
'''+s[b:];a=s.index('        var tutorialClose = ElementWithAutomationId');b=s.index('        var escapeHandler = ',a);s=s[:a]+s[b:];s=s.replace('"if (_viewModel?.IsOnboardingActive"','"if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.B)"');p.write_text(s,encoding='utf-8')
# Strengthen the full app case to execute copy/export, not only assert command enablement.
p=r/'tests/RAWSelectionAssistant.WpfTests/TutorialRetirementProductTests.cs';s=p.read_text(encoding='utf-8');a='''                        if(!vm.CopyCommand.CanExecute(null))throw new InvalidOperationException("Normal copy command locked by retired tutorial");''';b=a+'''
                        vm.OutputBaseDirectory=Path.Combine(output,"split-output");vm.ProjectName="合成正常分片";
                        var sourceHashes=Directory.GetFiles(source).ToDictionary(p=>p,p=>Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(p))));
                        await vm.CopyCommand.ExecuteAsync(null);
                        if(vm.Selections.Any(x=>x.OverallStatus!=MediaOverallStatus.Copied))throw new InvalidOperationException("Normal copy failed: "+vm.StatusMessage);
                        if(Directory.GetFiles(vm.OutputDirectory,"*.JPG",SearchOption.AllDirectories).Length!=3)throw new InvalidOperationException("Copied file count differs");
                        foreach(var pair in sourceHashes)if(Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(pair.Key)))!=pair.Value)throw new InvalidOperationException("Source bytes changed");
                        await vm.ExportReportCommand.ExecuteAsync(null);
                        if(!File.Exists(Path.Combine(vm.OutputDirectory,"匹配报告.csv")))throw new InvalidOperationException("Normal report missing");''';assert a in s;s=s.replace(a,b).replace('copyEnabled=vm.CopyCommand.CanExecute(null),','copied=vm.Selections.Count(x=>x.OverallStatus==MediaOverallStatus.Copied),sourceBytesUnchanged=true,report=true,');p.write_text(s,encoding='utf-8')