from pathlib import Path
import os,subprocess,json,time
r=Path('N:/pixart/guangjing-r53-stage-a-20261026');o=Path('N:/pixart/Guangjing-R53-Home-20261026/retirement-fullapp-final-r7');o.mkdir();a=r/'tests/RAWSelectionAssistant.WpfTests/bin/x64/Release/net10.0-windows10.0.19041.0/RAWSelectionAssistant.WpfTests.dll'
for scenario,root in [('first',o/'new-profile'),('upgrade',o/'upgrade-profile'),('restart',o/'upgrade-profile')]:
 f=o/scenario;f.mkdir();(f/'temp').mkdir();env=os.environ.copy();env.update(PIXEL_TART_ISOLATED_RUNTIME='1',PIXEL_TART_ISOLATED_RUNTIME_ROOT=str(root),KITAO_TEST_RESOURCE_ROOT=str(r),KITAO_RETIREMENT_APP_EVIDENCE=str(f),KITAO_RETIREMENT_SCENARIO=scenario,TEMP=str(f/'temp'),TMP=str(f/'temp'))
 cmd=['dotnet','vstest',str(a),'/TestCaseFilter:FullyQualifiedName~FullAppFirstUpgradeAndRestartDoNotActivateTutorialAndNormalSplitWorks','/Logger:trx;LogFileName=results.trx','/ResultsDirectory:'+str(f)];t=time.time()
 with (f/'stdout.log').open('wb') as log:
  p=subprocess.Popen(cmd,cwd=r,env=env,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
  try:code=p.wait(timeout=110)
  except subprocess.TimeoutExpired:p.kill();code=-999
 (f/'process.json').write_text(json.dumps(dict(command=cmd,pid=p.pid,exitCode=code,startEpoch=t,endEpoch=time.time(),scenario=scenario,root=str(root),sourceSha='d6590c99b7ed5f85953f898f9037b6b6ec31267b'),indent=2));print(scenario,code,flush=True);print((f/'stdout.log').read_text(encoding='utf-8')[-1600:],flush=True)