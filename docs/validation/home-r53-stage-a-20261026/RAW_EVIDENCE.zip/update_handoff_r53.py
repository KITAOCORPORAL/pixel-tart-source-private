from pathlib import Path
r=Path('N:/pixart/guangjing-r53-stage-a-20261026');p=r/'HANDOFF.MD';s=p.read_text(encoding='utf-8-sig');section='''
## 家用 R5.3 阶段 A 与旧教程退役（2026-10-26 Asia/Shanghai）
- 实际仓库 N:/pixart/pixel-tart-source-private；独立工作树 N:/pixart/guangjing-r53-stage-a-20261026；分支 home/r53-stage-a-20261026。20旧树与211项未提交文件保全，不reset/clean/stash/rebase、不合main、不强推。
- 再fetch/ls-remote公司 company/whole-app-ui-copy-cleanup-20261026 = 48527fa0b7d3d063d5af5f6b62fa1a18cb36ef66，无后续提交；家庭旧产品均已继承。
- 设计包 C:/Users/Admin/Downloads/Compressed/光镜-UI-R5.3-定稿.zip，SHA256 16f75c0f40b506e4db57f140f389967264040cd8c5930ad24946b11c171e2ca9；实读解压目录 N:/pixart/Guangjing-R53-Home-20261026/design-reference。原型只作设计资料，不执行网页/不复制未授权相框。
- 暗室源码节点592ecccb：同一Editor/ColorAdjustmentStack双模式、串行节点/胶片条、稳定original/main变体、用户/系统锁、确认后归档/本会话撤销删除、已有工作文件900ms防抖保存及正常关窗等待、ActualWidth DIP断点、B画笔/\\对比、宽窗440检查区/窄窗主动专注视图。阶段A PARTIAL：真实局部蒙版、通用混合/强度、2–4同步变体对比未完成；B–E本轮未开始。
- 追加产品：旧22步新手分片教程永久退役，新装/升级/中断旧进度不激活；删除自动/手动入口、遮罩/步骤提示、升级提示窗口和产品示例生成器。OnboardingService/TutorialDataService仅留不写盘兼容壳，旧字段/证明盐/路径/原数据不删除、不伪造“完成”。正常分片继续实际扫描/匹配/复制/导报。
- 旧品牌根因是教程/帮助/菜单/弹窗和文件元数据硬编码；用户可见文字、翻译值、安装器名称/发布者统一光镜。内部程序集、namespace、资源key、旧翻译key、迁移/数据库/安装兼容路径不改，已有用户水印/项目名称不批量替换。
- 全部功能完成且交互稳定后，集中制作覆盖光镜所有功能的产品引导与说明教程。
- 上述后置引导以届时实际交付功能为准，覆盖完整摄影师工作流、各模块操作及跨模块衔接。当前不开发替代教程。产品待办 docs/PRODUCT_BACKLOG.md。
- 当前用户全局规则禁止Computer Use/Browser/WebView/CDP；不重新启用。真实EXE仅做OS进程/模块身份启动与空工作区关闭核对；自动完整App夹具不等于鼠标保存重开/DPI。离屏WPF图不作实机截图。
- 完整发布/最终产品SHA、家用实测计数、ZIP/远端读回只以 docs/validation/home-r53-stage-a-20261026/FINAL_REPORT.md、TEST_SUMMARY.json、PUSH_READBACK.json 为准（生成后）；公司216/197仅历史。首版592ecccb已跑Core65PASS/2NOT_RUN、WPF62PASS/4NOT_RUN，后续教程退役须重新绑定最终发布DLL，不能沿用这些成绩。
- 统一交付根 N:/pixart/Guangjing-R53-Home-20261026；最新完整诊断包名称见最终报告。WholeAppDiagnosticBuild=true / PhotographerTrialBuild=false / win-x64自包含；不发行、不生成安装包。默认CMD不依赖脚本执行策略，不修改系统策略。
- 下一步先补阶段A批准渲染蒙版/混合与变体对比；像素行为改变遵守docs/color-science/open-source-first/POLICY.md，保留PV4/5/6及默认关闭研究。不得把R3原型175项算WPF完成、把.ptplan v1写成包含自由画布。

''';s=s.replace('# 光镜开发交接入口\n','# 光镜开发交接入口\n'+section);p.write_text(s,encoding='utf-8')