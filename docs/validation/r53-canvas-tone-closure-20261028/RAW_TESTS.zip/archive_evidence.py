import pathlib,zipfile,json,hashlib
r=pathlib.Path('E:/Kitao-Deliveries/r53-canvas-tone-closure-20261028');doc=pathlib.Path('E:/Kitao-Worktrees/r53-color-tools-film-20261028/docs/validation/r53-canvas-tone-closure-20261028');files=set();folders=["CANVAS_A3_CORE","CANVAS_A3_WPF","CANVAS_A4_CORE","CANVAS_A4_WPF","CANVAS_A5_CORE","CANVAS_A5_WPF","CANVAS_A6_CORE","CANVAS_A6_WPF","CANVAS_A7_CORE","CANVAS_A7_WPF","CANVAS_A8_CORE","CANVAS_A8_WPF","CANVAS_A9_CORE","CANVAS_A9_WPF","CANVAS_A10_CORE","CANVAS_A10_WPF","CANVAS_A11_CORE","CANVAS_A11_WPF","CANVAS_A12_CORE","CANVAS_A12_WPF","CANVAS_A13_CORE","CANVAS_A13_WPF","CANVAS_A14_CORE","CANVAS_A14_WPF","CANVAS_A15_CORE","CANVAS_A15_WPF","CANVAS_A16_CORE","CANVAS_A16_WPF","CANVAS_A17_CORE","CANVAS_A17_WPF","INDEPENDENT_A6","INDEPENDENT_A11","INDEPENDENT_A13","INDEPENDENT_A16","FINAL_CORE","FINAL_WPF","FINAL_INDEPENDENT","SEALED_CORE","SEALED_WPF","SEALED_INDEPENDENT"]
for name in folders:
 p=r/name
 if p.exists():
  for f in p.rglob('*'):
   if f.is_file() and f.suffix.lower() in ['.json','.trx','.xml','.log','.txt'] and 'runtime' not in f.parts and 'temp' not in f.parts:files.add(f)
for f in r.glob('*'):
 if f.is_file() and f.suffix.lower() in ['.py','.json','.log','.md','.txt']:files.add(f)
for name in ['canvas-sealed','tone-sealed','native-sealed-startup']:
 p=r/name
 if p.exists():files.update(p.glob('*.json'));files.update(p.glob('*.txt'))
z=doc/'RAW_TESTS.zip';manifest=[]
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,6) as out:
 for f in sorted(files):
  b=f.read_bytes();name=f.relative_to(r).as_posix();out.writestr(name,b);manifest.append(dict(path=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
with zipfile.ZipFile(z) as f:
 assert len(f.infolist())==len(manifest)
 for row in manifest:assert hashlib.sha256(f.read(row['path'])).hexdigest()==row['sha256']
(doc/'RAW_MANIFEST.json').write_text(json.dumps(dict(path=z.name,sha256=hashlib.sha256(z.read_bytes()).hexdigest(),bytes=z.stat().st_size,readback=True,files=manifest),indent=2));print(len(manifest),z.stat().st_size)
