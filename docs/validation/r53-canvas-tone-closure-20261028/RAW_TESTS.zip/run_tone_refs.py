import pathlib,subprocess,json,hashlib,math
r=pathlib.Path('E:/Kitao-Deliveries/r53-canvas-tone-closure-20261028');o=r/'tone-reference';o.mkdir(exist_ok=True);dt=pathlib.Path('E:/Kitao-Deliveries/r53-stage-a-completion-20261027/references/darktable-local/src/iop/basicadj.c');rt=pathlib.Path('E:/Kitao-Deliveries/r53-interaction-stage-b-20261027/rawtherapee-reference/rtengine/curves.h');tcc=pathlib.Path('E:/Kitao-Deliveries/r53-stage-a-completion-20261027/references/tcc-isolated/tcc/tcc.exe')
def function(text,name):
 start=text.index('static inline ',text.index(name)-40);brace=text.index('{',text.index(name,start));depth=0
 for end in range(brace,len(text)):
  if text[end]=='{':depth+=1
  elif text[end]=='}':
   depth-=1
   if depth==0:return text[start:end+1]
 raise ValueError(name)
dtext=dt.read_text();rtext=rt.read_text();head='#include <stdio.h>\n#include <math.h>\n#define xlog log\n#define xexp exp\n#define SQR(x) ((x)*(x))\nstatic float powf(float x,float y){return (float)pow(x,y);}\n'
(o/'dt.c').write_text(head+function(dtext,'get_contrast(')+'\nint main(){float x,c;while(scanf("%f %f",&x,&c)==2)printf("%.9g\\n",get_contrast(x,c,.18f,1.f/.18f));return 0;}')
funcs='\n'.join(function(rtext,n+'(') for n in ['basel','baseu','cupper','clower','cupper2','clower2','basecurve'])
(o/'rt.c').write_text(head+funcs+'\nint main(){double x,a,b,D,hr,sr;while(scanf("%lf %lf %lf %lf %lf %lf",&x,&a,&b,&D,&hr,&sr)==6)printf("%.17g\\n",basecurve(x,a,b,D,hr,sr));return 0;}')
for n in ['dt','rt']:subprocess.run([str(tcc),str(o/(n+'.c')),'-o',str(o/(n+'.exe'))],check=True)
xs=[0,1e-8,1e-5,.001,.01,.05,.1,.179,.18,.181,.3,.5,.75,1,2,4,16];dinputs=[(x,c) for c in [.5,1,1.5] for x in xs if x>=0];dr=list(map(float,subprocess.check_output([str(o/'dt.exe')],input=''.join(f'{x} {c}\n' for x,c in dinputs),text=True).splitlines()));rinputs=[(x,a,b,1,.2,.4) for a,b in [(1,0),(1.5,.02),(.7,-.05)] for x in xs if 0<=x<=1];rr=[float(v) if not any(x in v for x in ["#","nan","inf"]) else None for v in subprocess.check_output([str(o/'rt.exe')],input=''.join(' '.join(map(str,v))+'\n' for v in rinputs),text=True).splitlines()];result=dict(darktable=dict(commit='be9171cf8bb2feab8bd115efd9b96a4ce7103039',path='src/iop/basicadj.c get_contrast',hash=hashlib.sha256(dt.read_bytes()).hexdigest(),domain='linear luminance or RGB normalized, pivot.18, exponent.5/1/1.5; no ICC/tone output stage',cases=[dict(x=x,exponent=c,y=y) for (x,c),y in zip(dinputs,dr)]),rawtherapee=dict(commit='a8a3d1bc7b419ed1c974c39276c97e618a4f9a1b',path='rtengine/curves.h CurveFactory basecurve/cupper/clower and dependencies',hash=hashlib.sha256(rt.read_bytes()).hexdigest(),domain='base curve stage normalized0..1; a,b,D,hr,sr explicit. Not claim equal slider or full camera engine',cases=[dict(x=v[0],a=v[1],b=v[2],D=v[3],hr=v[4],sr=v[5],y=y) for v,y in zip(rinputs,rr)]),execution='Unmodified extracted native source functions with only standard-math aliases; actual C executable, no product formula stand-in',license='Both GPL3 local-only references not copied into product/package',outputConversion='LCMS2.12 working linearD50 -> targetICC is tested separately; operator-domain references are not camera calibration')
(r/'TONE_NATIVE_REFERENCES.json').write_text(json.dumps(result,indent=2));print(len(dr),len(rr))


