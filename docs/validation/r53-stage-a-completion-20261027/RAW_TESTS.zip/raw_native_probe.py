import pathlib,ctypes,json,hashlib
p=pathlib.Path('E:/Kitao-Worktrees/r53-stage-a-completion-20261027/tests/RAWSelectionAssistant.Tests/bin/Release/net10.0/runtimes/win-x64/native/raw_r.dll');lib=ctypes.CDLL(str(p));lib.libraw_init.argtypes=[ctypes.c_uint];lib.libraw_init.restype=ctypes.c_void_p;lib.libraw_open_buffer.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_size_t];lib.libraw_open_buffer.restype=ctypes.c_int;lib.libraw_close.argtypes=[ctypes.c_void_p];lib.libraw_strerror.argtypes=[ctypes.c_int];lib.libraw_strerror.restype=ctypes.c_char_p
source=pathlib.Path('D:/AI AGENT/PixelTart-TestAssets/CompanyRAW/DSC09916.ARW');b=source.read_bytes();buffer=ctypes.create_string_buffer(b);h=lib.libraw_init(0)
try:
 code=lib.libraw_open_buffer(h,buffer,len(b));r=dict(source=str(source),sha256=hashlib.sha256(b).hexdigest(),openBufferCode=code,error=lib.libraw_strerror(code).decode(),scope='Read-only isolated native probe, no product decoder change');print(r);pathlib.Path('E:/Kitao-Deliveries/r53-stage-a-completion-20261027/RAW_NATIVE_PROBE.json').write_text(json.dumps(r,indent=2))
finally:lib.libraw_close(h)
