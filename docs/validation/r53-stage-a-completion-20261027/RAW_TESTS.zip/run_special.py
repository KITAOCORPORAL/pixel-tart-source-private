import pathlib,os,subprocess,json,sys,time
r=pathlib.Path("E:/Kitao-Worktrees/r53-stage-a-completion-20261027");d=pathlib.Path("E:/Kitao-Deliveries/r53-stage-a-completion-20261027");dotnet='D:/AI AGENT/.dotnet/dotnet.exe';env=os.environ.copy();env['DOTNET_ROOT']=str(pathlib.Path(dotnet).parent);env['PATH']=str(pathlib.Path(dotnet).parent)+os.pathsep+env.get('PATH','');assembly=r/'tests/RAWSelectionAssistant.WpfTests/bin/x64/Release/net10.0-windows10.0.19041.0/RAWSelectionAssistant.WpfTests.dll';rows=[]
def run(label,cls,extra):
 e=env.copy();e.update(extra);args=[sys.executable,str(r/'tools/whole-app-validation/verified_full_runner.py'),'--assembly',str(assembly),'--output',str(d/label),'--dotnet',dotnet,'--resource-root',str(r),'--classes','RAWSelectionAssistant.WpfTests.'+cls]
 with (d/(label+'.log')).open('wb') as f:code=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,env=e,creationflags=subprocess.CREATE_NO_WINDOW).returncode
 rows.append(dict(label=label,exitCode=code));(d/'SPECIAL_RUNS.json').write_text(json.dumps(rows,indent=2));print(label,code,flush=True)
for mode in ['create','reopen']:run('PROCESS_'+mode,'R53ProcessPersistenceTests',{'KITAO_R53_PROCESS_ROOT':str(d/'process-chain-final'),'KITAO_R53_PROCESS_MODE':mode})
for scenario in ['first','upgrade','restart']:run('APP_'+scenario,'TutorialRetirementProductTests',{'KITAO_RETIREMENT_APP_EVIDENCE':str(d/('full-app-'+scenario)),'KITAO_RETIREMENT_SCENARIO':scenario})
