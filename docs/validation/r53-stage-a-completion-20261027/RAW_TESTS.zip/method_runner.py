import importlib.util,pathlib,collections
p=pathlib.Path('E:/Kitao-Worktrees/r53-stage-a-completion-20261027/tools/whole-app-validation/verified_full_runner.py')
s=importlib.util.spec_from_file_location('verified',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);original=m.execution_units
def isolated(selected,single_process=False,p1_unit='method'):
 units=original(selected,single_process,p1_unit);result={}
 for name,cases in units.items():
  if name=='RAWSelectionAssistant.WpfTests.TutorialRetirementProductTests':
   for case in cases:result.setdefault(case['fullyQualifiedName'],[]).append(case)
  else:result[name]=cases
 before=collections.Counter((c['id'],c['fullyQualifiedName'],c['displayName']) for v in units.values() for c in v);after=collections.Counter((c['id'],c['fullyQualifiedName'],c['displayName']) for v in result.values() for c in v);assert before==after
 return result
original_popen=m.subprocess.Popen
def retained_runtime_popen(cmd,*args,**kwargs):
 import os,shutil
 source=os.environ.get('KITAO_R53_RESTART_RUNTIME')
 env=kwargs.get('env')
 if source and env and 'vstest' in cmd:
  destination=pathlib.Path(env['PIXEL_TART_ISOLATED_RUNTIME_ROOT'])
  if destination.exists():raise RuntimeError('Restart destination must be fresh')
  shutil.copytree(source,destination)
 return original_popen(cmd,*args,**kwargs)
m.subprocess.Popen=retained_runtime_popen
m.execution_units=isolated
raise SystemExit(m.main())
