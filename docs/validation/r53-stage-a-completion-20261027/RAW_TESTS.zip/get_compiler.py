import urllib.request,pathlib,zipfile,hashlib
p=pathlib.Path('E:/Kitao-Deliveries/r53-stage-a-completion-20261027/references/tcc.zip')
try:
 p.write_bytes(urllib.request.urlopen('https://download.savannah.gnu.org/releases/tinycc/tcc-0.9.27-win64-bin.zip',timeout=25).read());print(len(p.read_bytes()),hashlib.sha256(p.read_bytes()).hexdigest());zipfile.ZipFile(p).extractall(p.parent/'tcc-isolated')
except Exception as e:print(type(e).__name__,str(e))
