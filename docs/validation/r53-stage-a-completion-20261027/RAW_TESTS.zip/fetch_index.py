import urllib.request,pathlib,json
out=pathlib.Path('E:/Kitao-Deliveries/r53-stage-a-completion-20261027/references');sha='be9171cf8bb2feab8bd115efd9b96a4ce7103039'
u='https://api.github.com/repos/darktable-org/darktable/git/trees/'+sha+'?recursive=1'
r=json.load(urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Kitao-Research'}),timeout=25))
paths=[x['path'] for x in r['tree'] if 'blendif' in x['path'] or 'blendop' in x['path']];print(paths)
for p in paths:
 if p.endswith(('.c','.h')) and 'rgb' in p:
  b=urllib.request.urlopen('https://raw.githubusercontent.com/darktable-org/darktable/'+sha+'/'+p,timeout=20).read();(out/('darktable-'+p.replace('/','_'))).write_bytes(b);print(p,len(b))
