import os,pathlib,subprocess,time,json,sys
root=pathlib.Path("E:/Kitao-Worktrees/r53-stage-a-completion-20261027");d=pathlib.Path("E:/Kitao-Deliveries/r53-stage-a-completion-20261027");os.chdir(root);dotnet="D:/AI AGENT/.dotnet/dotnet.exe";env=os.environ.copy();env['DOTNET_ROOT']=str(pathlib.Path(dotnet).parent);env['PATH']=str(pathlib.Path(dotnet).parent)+os.pathsep+env.get('PATH','')
for label,args in [('BUILD_CORE_A12',['build','tests/RAWSelectionAssistant.Tests/RAWSelectionAssistant.Tests.csproj','-c','Release','--no-restore']),('BUILD_WPF_A12',['build','tests/RAWSelectionAssistant.WpfTests/RAWSelectionAssistant.WpfTests.csproj','-c','Release','-p:Platform=x64','--no-restore','-p:WholeAppDiagnosticBuild=true','-p:PhotographerTrialBuild=false']),('RESTORE_RUNNER',['restore','tools/VerifiedTestRunner/VerifiedTestRunner.csproj','--configfile',str(d/'NuGet.Config')]),('BUILD_RUNNER',['build','tools/VerifiedTestRunner/VerifiedTestRunner.csproj','-c','Release','--no-restore'])]:
 with (d/(label+'.log')).open('wb') as log:
  p=subprocess.Popen([dotnet]+args+['--disable-build-servers','-m:1','-nr:false'],stdout=log,stderr=subprocess.STDOUT,env=env,creationflags=subprocess.CREATE_NO_WINDOW);code=p.wait()
 print(label,code,flush=True)
 if code:sys.exit(code)
