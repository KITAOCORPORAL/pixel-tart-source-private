import pathlib,re,subprocess,json,hashlib
p=pathlib.Path('E:/Kitao-Deliveries/r53-stage-a-completion-20261027/references');src=p/'darktable-local/src/develop/blends/blendif_rgb_hsl.c';text=src.read_text();funcs=[]
for name in ['_blend_normal_unbounded','_blend_multiply','_blend_screen']:
 start=text.index('_BLEND_FUNC '+name+'(');end=text.index('\n}',start)+2;funcs.append(text[start:end])
head='#include <stdio.h>\n#include <math.h>\n#define _BLEND_FUNC static void\n#define DT_BLENDIF_RGB_CH 4\n#define DT_BLENDIF_RGB_BCH 3\n#define restrict\nstatic float clamp_simd(float x){return fminf(1,fmaxf(0,x));}\n'
main='\nint main(){int mode;float a[4],b[4],o[4],w;while(scanf("%d %f %f %f",&mode,&a[0],&b[0],&w)==4){for(int i=1;i<4;i++){a[i]=a[0];b[i]=b[0];}switch(mode){case 0:_blend_normal_unbounded(a,b,o,&w,1);break;case 1:_blend_multiply(a,b,o,&w,1);break;default:_blend_screen(a,b,o,&w,1);}printf("%.9g\\n",o[0]);}return 0;}'
(p/'darktable-kernel.c').write_text(head+'\n'.join(funcs)+main.replace('\\n','\n'))
im=(p/'ImageMagick-MagickCore_composite.c').read_text();selected=[]
# Exact scalar switch arms from CompositeImage; all channels synchronized, opaque destination.
for mode,name in enumerate(['OverCompositeOp','MultiplyCompositeOp','ScreenCompositeOp']):
 start=im.index('          case '+name+':',im.index('          case MultiplyCompositeOp:',im.index('          case MultiplyCompositeOp:')+1) if False else 0)
 # Select last occurrence: final color-channel loop, not alpha loop.
 start=im.rindex('          case '+name+':');brace=im.index('{',start);depth=0
 for end in range(brace,len(im)):
  if im[end]=='{':depth+=1
  if im[end]=='}':
   depth-=1
   if depth==0:break
 selected.append('case '+str(mode)+':'+im[brace:end+1])
head='#include <stdio.h>\n#include <math.h>\n#define MagickFalse 0\n#define QuantumRange 1.0\n#define MagickEpsilon 1e-12\n#define RoundToUnity(x) fmin(1.0,fmax(0.0,(x)))\n'
main='int main(){int mode;double a,b,w;while(scanf("%d %lf %lf %lf",&mode,&a,&b,&w)==4){int compose_sync=1;double Sa=w,Da=1,Sc=b,Dc=a,Sca=b*w,Dca=a,gamma=1,S,D,blend,pixel=0;switch(mode){'+''.join(selected)+'}printf("%.17g\\n",pixel);}return 0;}'
(p/'imagemagick-kernel.c').write_text(head+main.replace('\\n','\n'))
compiler=p/'tcc-isolated/tcc/tcc.exe'
for name in ['darktable','imagemagick']:
 cmd=[str(compiler),str(p/(name+'-kernel.c')),'-o',str(p/(name+'-kernel.exe'))];r=subprocess.run(cmd,capture_output=True,text=True);print(name,r.returncode,r.stdout,r.stderr)
manifest={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [src,p/'darktable-kernel.c',p/'imagemagick-kernel.c',compiler]};(p/'KERNEL_BUILD.json').write_text(json.dumps(manifest,indent=2))
