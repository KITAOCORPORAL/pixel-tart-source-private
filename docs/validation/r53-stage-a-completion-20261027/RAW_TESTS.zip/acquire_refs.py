import pathlib,urllib.request,subprocess,json,hashlib
out=pathlib.Path("E:/Kitao-Deliveries/r53-stage-a-completion-20261027/references");rows=[]
for repo,tag,paths in [('darktable-org/darktable','release-5.2.1',['src/develop/blend.c','src/develop/masks/brush.c','LICENSE']),('ImageMagick/ImageMagick','7.1.2-34',['MagickCore/composite.c','MagickCore/paint.c','LICENSE'])]:
 raw=subprocess.check_output(['git','ls-remote','https://github.com/'+repo+'.git','refs/tags/'+tag,'refs/tags/'+tag+'^{}'],text=True);lines=raw.strip().splitlines();sha=next((l.split()[0] for l in lines if l.endswith('^{}')),lines[0].split()[0]);files=[]
 for path in paths:
  try:b=urllib.request.urlopen('https://raw.githubusercontent.com/'+repo+'/'+sha+'/'+path,timeout=30).read();p=out/(repo.split('/')[1]+'-'+path.replace('/','_'));p.write_bytes(b);files.append(dict(path=path,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b)))
  except Exception as e:files.append(dict(path=path,error=str(e)))
 rows.append(dict(repo=repo,tag=tag,commit=sha,files=files))
(out/'PINNED.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows))
