import urllib.request,pathlib
out=pathlib.Path('E:/Kitao-Deliveries/r53-stage-a-completion-20261027/references');sha='be9171cf8bb2feab8bd115efd9b96a4ce7103039'
for p in ['src/develop/blend/blendif_rgb_hsl.c','src/develop/blend/blendif_rgb_jzczhz.c','src/develop/blend/blendif.h','src/develop/blend/blendop_rgb.c','src/develop/blend/blendop_rgb_hsl.c','src/develop/blend/blendif_rgb.c']:
 try:
  b=urllib.request.urlopen('https://raw.githubusercontent.com/darktable-org/darktable/'+sha+'/'+p,timeout=12).read();(out/('darktable-'+p.replace('/','_'))).write_bytes(b);print(p,len(b))
 except Exception as e:print(p,str(e))
