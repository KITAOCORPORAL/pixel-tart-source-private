import pathlib,json,subprocess,struct,time,hashlib
p=pathlib.Path('E:/Kitao-Deliveries/r53-stage-a-completion-20261027/references')
f=lambda x:struct.unpack('f',struct.pack('f',x))[0]
values=[0,.003,.02,.18,.5,.75,1,-.125,1.25,2];cases=[dict(A=f(a),B=f(b),Opacity=w,Mode=m) for a in values for b in values for w in [0,.25,.5,1] for m in range(3)]
data=''.join(f"{c['Mode']} {c['A']:.9g} {c['B']:.9g} {c['Opacity']:.9g}\n" for c in cases)
timings={}
for name,key in [('darktable','Darktable'),('imagemagick','ImageMagick')]:
 start=time.perf_counter();r=subprocess.run([str(p/(name+'-kernel.exe'))],input=data,text=True,capture_output=True,check=True);timings[name]=(time.perf_counter()-start)*1000
 result=[float(s) for s in r.stdout.splitlines()];assert len(result)==len(cases),(name,len(result),len(cases))
 for c,x in zip(cases,result):c[key]=x
(p/'REFERENCE_MATRIX.json').write_text(json.dumps(cases,indent=2));(p/'REFERENCE_EXECUTION.json').write_text(json.dumps(dict(count=len(cases),timingsMs=timings,inputSha256=hashlib.sha256(data.encode()).hexdigest(),scope='Unmodified extracted scalar reference kernels, not whole darktable/ImageMagick image pipeline.'),indent=2));print(timings,len(cases))
