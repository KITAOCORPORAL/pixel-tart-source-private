import pathlib,zipfile,json,hashlib
r=pathlib.Path('E:/Kitao-Deliveries/r53-stage-a-completion-20261027');doc=pathlib.Path('E:/Kitao-Worktrees/r53-stage-a-completion-20261027/docs/validation/r53-stage-a-completion-20261027');z=doc/'RAW_TESTS.zip'
folders=['A5_CORE','A5_WPF','A6_CORE','A6_WPF','A7_CORE','A7_WPF','A8_CORE','A8_WPF','A9_CORE','A9_WPF','A10_CORE','A10_WPF','A11_CORE','A11_WPF','A12_CORE','A12_WPF','BROAD_CORE','BROAD_WPF','FINAL_CORE','FINAL_WPF','SEALED_CORE','SEALED_WPF','SEALED_NUMERIC_CORE','PROCESS_create','PROCESS_reopen','APP_first','APP_upgrade','APP_restart','SEALED_PROCESS_create','SEALED_PROCESS_reopen','SEALED_COMPARE','SEALED_APP_first','SEALED_APP_upgrade','SEALED_APP_restart','SEALED_APP_restart_retained']
files=set()
for folder in ['process-chain-sealed','sealed-full-app-first','sealed-full-app-upgrade','sealed-full-app-restart-retained','native-startup','20261027-resume']:
 p=r/folder
 if p.exists():
  for f in p.rglob('*.json'):files.add(f)
for folder in folders:
 p=r/folder
 if p.exists():
  for f in p.rglob('*'):
   if f.is_file() and f.suffix.lower() in ['.json','.trx','.xml','.log','.txt'] and 'runtime' not in f.parts and 'temp' not in f.parts:files.add(f)
for f in r.glob('*'):
 if f.is_file() and f.suffix.lower() in ['.py','.json','.log']:files.add(f)
for f in (r/'references').glob('*'):
 if f.is_file() and f.name not in ['darktable-kernel.c','imagemagick-kernel.c'] and f.suffix.lower() not in ['.exe','.zip']:files.add(f)
# GPL/image implementation source remains local isolation, never copied into evidence or product archive.
files={f for f in files if not f.name.startswith(('darktable-src','ImageMagick-MagickCore')) and f.name not in ['darktable-LICENSE','ImageMagick-LICENSE']}
manifest=[]
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,6) as out:
 for f in sorted(files):
  b=f.read_bytes();name=f.relative_to(r).as_posix();out.writestr(name,b);manifest.append(dict(path=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
with zipfile.ZipFile(z) as read:
 assert len(read.infolist())==len(manifest)
 for f in manifest:assert hashlib.sha256(read.read(f['path'])).hexdigest()==f['sha256']
(doc/'RAW_MANIFEST.json').write_text(json.dumps(dict(archive=z.name,sha256=hashlib.sha256(z.read_bytes()).hexdigest(),bytes=z.stat().st_size,readback=True,files=manifest),indent=2));print(len(manifest),z.stat().st_size)
