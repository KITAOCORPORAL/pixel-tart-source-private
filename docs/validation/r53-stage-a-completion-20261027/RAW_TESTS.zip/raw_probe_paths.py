import pathlib,xml.etree.ElementTree as E,json,subprocess,time
r=pathlib.Path('E:/Kitao-Worktrees/r53-stage-a-completion-20261027');out=pathlib.Path('E:/Kitao-Deliveries/r53-stage-a-completion-20261027/references');image=r/'tests/RAWSelectionAssistant.Tests/bin/Release/net10.0/runtimes/win-x64/native';print([str(x) for x in image.glob('*raw*')])
