import pathlib,subprocess,json,math,hashlib
r=pathlib.Path('E:/Kitao-Deliveries/r53-interaction-stage-b-20261027');o=r/'scene-reference';o.mkdir(exist_ok=True);tcc=pathlib.Path('E:/Kitao-Deliveries/r53-stage-a-completion-20261027/references/tcc-isolated/tcc/tcc.exe')
dt=pathlib.Path('E:/Kitao-Deliveries/r53-stage-a-completion-20261027/references/darktable-local/src/iop/exposure.c');rt=r/'rawtherapee-reference/rtengine/curves.cc'
# Isolated pinned scalar exposure stages, black=0, no tone/look/profile. GPL source never enters product.
(o/'darktable-exposure.c').write_text('#include <math.h>\n#include <stdio.h>\nstatic float exp2f(float x){return (float)pow(2.0,x);}\nint main(){float x,ev;while(scanf("%f %f",&x,&ev)==2){float black=0,white=exp2f(-ev),scale=1.0/(white-black);float out=(x-black)*scale;printf("%.9g\\n",out);}return 0;}')
(o/'rawtherapee-exposure.c').write_text('#include <math.h>\n#include <stdio.h>\nstatic float powf(float a,float b){return (float)pow(a,b);}\nint main(){float x,ev;while(scanf("%f %f",&x,&ev)==2){float exp_scale=powf(2.0f,ev);float out=x*exp_scale;printf("%.9g\\n",out);}return 0;}')
cases=[(v,ev) for v in [-.25,0,.001,.18,.5,1,4,16] for ev in [-5,-2,-.5,0,.5,2,5]];data=''.join(f'{v} {ev}\n' for v,ev in cases);values={}
for name in ['darktable','rawtherapee']:
 subprocess.run([str(tcc),str(o/(name+'-exposure.c')),'-o',str(o/(name+'-exposure.exe'))],check=True);values[name]=list(map(float,subprocess.check_output([str(o/(name+'-exposure.exe'))],input=data,text=True).splitlines()))
rows=[]
for i,(v,ev) in enumerate(cases):
 expected=v*2**ev;rows.append(dict(input=v,ev=ev,expected=expected,darktable=values['darktable'][i],rawtherapee=values['rawtherapee'][i],maxAbsolute=max(abs(expected-values[n][i]) for n in values)))
result=dict(darktableCommit='be9171cf8bb2feab8bd115efd9b96a4ce7103039',darktableEntry='src/iop/exposure.c exposure2white/process black0 scale',rawtherapeeCommit='a8a3d1bc7b419ed1c974c39276c97e618a4f9a1b',rawtherapeeEntry='rtengine/curves.cc powf2 ecomp; rtengine/dcp.cc step2ApplyTile RGB*=exp_scale no tone/look',licenses='GPL3 isolated scalar-stage research only, no copied product implementation or binary',sourceHashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [dt,rt]},cases=rows,maxAbsolute=max(x['maxAbsolute'] for x in rows),scope='Linear exposure stage only, not full RAW/profile pipeline, mask is independently versioned normal gain interpolation')
(r/'SCENE_REFERENCE.json').write_text(json.dumps(result,indent=2));print(result['maxAbsolute'])


