import pathlib,zipfile,hashlib,json
r=pathlib.Path('E:/Kitao-Deliveries/r53-interaction-stage-b-20261027');doc=pathlib.Path('E:/Kitao-Worktrees/r53-stage-a-completion-20261027/docs/validation/r53-interaction-stage-b-20261027');folders=['INTERACT_A2_CORE','INTERACT_A2_WPF','INTERACT_A3_CORE','INTERACT_A3_WPF','INTERACT_A4_CORE','INTERACT_A4_WPF','INTERACT_A5_CORE','INTERACT_A5_WPF','INTERACT_A6_CORE','INTERACT_A6_WPF','INTERACT_A7_CORE','INTERACT_A7_WPF','INTERACT_A9_CORE','INTERACT_A9_WPF','INTERACT_A10_CORE','INTERACT_A10_WPF','INTERACT_A11_CORE','INTERACT_A11_WPF','INTERACT_A12_CORE','INTERACT_A12_WPF','INTERACT_A13_CORE','INTERACT_A13_WPF','INTERACT_A14_CORE','INTERACT_A14_WPF','INTERACT_A15_CORE','INTERACT_A15_WPF','FINAL_CORE','FINAL_WPF','SEALED_CORE','SEALED_WPF','FINAL_LARGE_BRUSH_short','FINAL_LARGE_BRUSH_long','FINAL_LARGE_BRUSH_multi'];files=set()
for name in folders:
 p=r/name
 if p.exists():
  for f in p.rglob('*'):
   if f.is_file() and f.suffix.lower() in ['.json','.trx','.xml','.log','.txt'] and 'runtime' not in f.parts and 'temp' not in f.parts:files.add(f)
for f in r.glob('*'):
 if f.is_file() and f.suffix.lower() in ['.py','.json','.log']:files.add(f)
for name in ['interaction-final','interaction-sealed','real-interaction-final','real-interaction-sealed','native-final-startup','final-large-brush-short','final-large-brush-long','final-large-brush-multi']:
 p=r/name
 if p.exists():files.update(p.rglob('*.json'))
z=doc/'RAW_TESTS.zip';manifest=[]
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,6) as out:
 for f in sorted(files):
  b=f.read_bytes();name=f.relative_to(r).as_posix();out.writestr(name,b);manifest.append(dict(path=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
with zipfile.ZipFile(z) as f:
 assert len(f.infolist())==len(manifest)
 for row in manifest:assert hashlib.sha256(f.read(row['path'])).hexdigest()==row['sha256']
(doc/'RAW_MANIFEST.json').write_text(json.dumps(dict(path=z.name,sha256=hashlib.sha256(z.read_bytes()).hexdigest(),bytes=z.stat().st_size,files=manifest,readback=True),indent=2));print(len(manifest),z.stat().st_size)
