from pathlib import Path
r=Path.cwd()/'guangjing-home-owned-canvas-20261025'
(r/'src/RAWSelectionAssistant.Core/Services/FreeCanvas/CanvasPlanningSource.cs').write_text('''using RAWSelectionAssistant.Core.Services.Projects;
namespace RAWSelectionAssistant.Core.Services.FreeCanvas;

/// <summary>Local durable identity, not a thumbnail or external-original fallback.
/// Free-canvas workspaces are deliberately outside .ptplan v1 portability.</summary>
public sealed record CanvasPlanningSource(string PlanningRoot, PlanningProjectCopy Copy)
{
    public static CanvasPlanningSource From(PlanningProjectCopy copy)
    {
        var source=new CanvasPlanningSource(copy.StorageRoot??throw new InvalidDataException("自有参考未绑定策划根。"),copy);
        source.Validate();using var verified=source.OpenVerified();return source;
    }
    public void Validate()
    {
        if(string.IsNullOrWhiteSpace(PlanningRoot)||!Path.IsPathFullyQualified(PlanningRoot)||Copy is null||Copy.Kind!="reference")
            throw new InvalidDataException("画布自有参考来源身份无效。");
        Copy.Validate();
        if(PlanningRoot.StartsWith(@"\\\\?\\",StringComparison.Ordinal)||PlanningRoot.StartsWith(@"\\\\.\\",StringComparison.Ordinal)||PlanningRoot.AsSpan(Path.GetPathRoot(PlanningRoot)!.Length).Contains(':'))
            throw new InvalidDataException("画布自有参考不支持设备或备用数据流。");
    }
    public PlanningProjectCopy Bind()
    {
        Validate();return Copy with{StorageRoot=Path.GetFullPath(PlanningRoot)};
    }
    public FileStream OpenVerified(CancellationToken token=default)=>PlanningProjectCopyStorage.OpenVerifiedRead(Bind(),token);
}
''',encoding='utf8')
p=r/'src/RAWSelectionAssistant.Core/Services/FreeCanvas/CanvasDocument.cs';s=p.read_text().replace('    public string SourcePath { get; init; } = "";','    public string SourcePath { get; init; } = "";\n    public CanvasPlanningSource? PlanningSource { get; init; }');needle='''        foreach (var item in document.Objects)
''';s=s.replace(needle,'''        foreach(var item in document.Objects.Where(x=>x.PlanningSource is not null))
        {
            item.PlanningSource!.Validate();
            if(!item.IsImage||item.SourcePath!=""||item.ContentHash!=item.PlanningSource.Copy.Sha256)
                throw new InvalidDataException("画布自有参考不得混用外链或缩略缓存来源。");
        }
'''+needle);p.write_text(s,encoding='utf8')
# Keep exactly the company decoder implementation; expose it in the lower WPF module so
# both planning and standalone/saved canvas loads use identical bounded/hash-verified pixels.
p=r/'src/RAWSelectionAssistant/Services/PlanningOwnedReferenceImage.cs';s=p.read_text();m=s.replace('namespace RAWSelectionAssistant.Services;','namespace PixelTart.Modules.AssetLibrary.FreeCanvas;').replace('public static class PlanningOwnedReferenceImage','public static class OwnedPlanningReferenceImage');(r/'src/PixelTart.Modules.AssetLibrary/FreeCanvas/OwnedPlanningReferenceImage.cs').write_text(m,encoding='utf8')
p.write_text('''using System.Windows.Media.Imaging;
using RAWSelectionAssistant.Core.Services.Projects;
using PixelTart.Modules.AssetLibrary.FreeCanvas;
namespace RAWSelectionAssistant.Services;
/// <summary>Compatibility facade. Planning and canvas share the unchanged company bounded decoder.</summary>
public static class PlanningOwnedReferenceImage
{
    public const int MaximumSide=OwnedPlanningReferenceImage.MaximumSide;
    public const long MaximumPixels=OwnedPlanningReferenceImage.MaximumPixels;
    public const int ThumbnailEdge=OwnedPlanningReferenceImage.ThumbnailEdge,SummaryEdge=OwnedPlanningReferenceImage.SummaryEdge,LargeViewEdge=OwnedPlanningReferenceImage.LargeViewEdge;
    public static BitmapSource Read(PlanningProjectCopy copy,Guid project,Guid document,Guid reference)=>OwnedPlanningReferenceImage.Read(copy,project,document,reference);
    public static BitmapSource ReadBounded(PlanningProjectCopy copy,Guid project,Guid document,Guid reference,int maximumEdge,CancellationToken token=default)=>OwnedPlanningReferenceImage.ReadBounded(copy,project,document,reference,maximumEdge,token);
    public sealed record Thumbnail(string Path,BitmapSource Image,bool CacheHit);
    public static Thumbnail ReadThumbnail(PlanningProjectCopy copy,Guid project,Guid document,Guid reference,string cacheRoot,CancellationToken token=default)
    {var value=OwnedPlanningReferenceImage.ReadThumbnail(copy,project,document,reference,cacheRoot,token);return new(value.Path,value.Image,value.CacheHit);}
    public static BitmapSource Decode(byte[] data,string extension)=>OwnedPlanningReferenceImage.Decode(data,extension);
}
''',encoding='utf8')
p=r/'src/RAWSelectionAssistant/ViewModels/PlanningCenterViewModel.References.cs';s=p.read_text();start=s.index('    public async Task SendToCanvasAsync(');s=s[:start]+'''    public async Task SendToCanvasAsync(PlanningReferenceItem? item = null)
    {
        if (ProjectId is not Guid id || !await FlushAsync()) return;
        var canvas = new CanvasDocument { Name = DocumentTitle + " · 视觉方向", ProjectId = id };
        var references = item is null ? AllProjectReferences.Where(reference => reference.IsMoodboard).ToArray() : [item];
        var objects=new List<CanvasObject>();
        foreach(var reference in references)
        {
            // Re-resolve current identity after editor flush. A stale card from a different
            // project/refresh must never transfer its bytes into this canvas.
            var current=AllProjectReferences.SingleOrDefault(r=>r.Id==reference.Id);
            if(current is null)throw new InvalidDataException("参考已不属于当前项目，请重新选择。");
            CanvasPlanningSource? owned=null;string path;
            if(current.Link.ProjectCopy is {} copy)
            {
                if(copy.ProjectId!=id||copy.DocumentId!=PlanningDocumentId||copy.ReferenceId!=current.Id)
                    throw new InvalidDataException("自有参考与当前项目身份不符，未发送画布。");
                owned=CanvasPlanningSource.From(copy);path="";
            }
            else path=await ResolveOriginalAsync(current)??throw new IOException("参考来源不可用，未使用缩略缓存发送画布。");
            objects.Add(new(){CanvasId=canvas.CanvasId,LibraryId=current.Link.Source.LibraryId??Guid.Empty,AssetId=current.Link.Source.AssetId,
                SourcePath=path,PlanningSource=owned,ContentHash=owned?.Copy.Sha256??"",Name=current.Title,
                X=objects.Count%3*350,Y=objects.Count/3*280});
        }
        if(ProjectId!=id)throw new InvalidOperationException("项目已切换，未发送画布。");
        canvas=canvas with{Objects=objects};await _canvases.SaveAsync(canvas);
        await _planning.AddVisualLinkAsync(id,new(Guid.NewGuid(),PlanningVisualLinkKind.FreeCanvas,canvas.CanvasId,canvas.Name));
        ProjectCanvases.Add(canvas);CanvasRequested?.Invoke(this,canvas);
    }
}
''';p.write_text(s,encoding='utf8')
p=r/'src/PixelTart.Modules.AssetLibrary/FreeCanvas/FreeCanvasSurface.cs';s=p.read_text().replace('    private readonly HashSet<Guid> _loading = [];','    private readonly HashSet<Guid> _loading = [];\n    private readonly Dictionary<Guid,string> _sourceErrors=[];\n    public IReadOnlyDictionary<Guid,string> SourceErrors=>_sourceErrors;');needle='''            var requested = (int)Math.Clamp''';s=s.replace(needle,'''            if(item.PlanningSource is {} owned)
            {
                // Never use IAssetPreviewProvider/offline caches for a planning-owned source.
                // Revalidate even if an in-memory preview already exists; errors erase it.
                var snapshot=Editor.Document;
                try
                {
                    var copy=owned.Bind();
                    var bitmap=await Task.Run(()=>OwnedPlanningReferenceImage.ReadBounded(copy,copy.ProjectId,copy.DocumentId,copy.ReferenceId,1024));
                    if(!ReferenceEquals(snapshot,Editor.Document))continue;
                    _images[item.ObjectId]=bitmap;_sourceErrors.Remove(item.ObjectId);
                }
                catch(Exception e)when(e is IOException or UnauthorizedAccessException or ArgumentException or NotSupportedException or InvalidOperationException or System.Runtime.InteropServices.COMException)
                {if(ReferenceEquals(snapshot,Editor.Document)){_images.Remove(item.ObjectId);_widths.Remove(item.ObjectId);_sourceErrors[item.ObjectId]="项目自有副本不可用："+e.Message+"（未回退原外链/缓存）";}}
                continue;
            }
'''+needle);s=s.replace('            if (item.IsImage && !File.Exists(item.SourcePath)) DrawLabel','            if(_sourceErrors.TryGetValue(item.ObjectId,out var error))DrawLabel(dc,error,new(item.X+6,item.Y+item.Height-24/_zoom));\n            if (item.IsImage && item.PlanningSource is null && !File.Exists(item.SourcePath)) DrawLabel');s=s.replace('        var currentIds=Editor.Document.Objects.Select', '        foreach(var id in _sourceErrors.Keys.Where(id=>!Editor.Document.Objects.Any(x=>x.ObjectId==id)).ToArray())_sourceErrors.Remove(id);\n        var currentIds=Editor.Document.Objects.Select');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/Services/PlanningCanvasSnapshot.cs';s=p.read_text().replace('x.IsImage && !File.Exists(x.SourcePath)','x.IsImage && x.PlanningSource is null && !File.Exists(x.SourcePath)');s=s.replace('else if (item.IsImage && File.Exists(item.SourcePath))','else if (item.IsImage && (item.PlanningSource is not null || File.Exists(item.SourcePath)))');old='''                    var bitmap = new BitmapImage(); bitmap.BeginInit(); bitmap.CacheOption=BitmapCacheOption.OnLoad;
                    bitmap.DecodePixelWidth=1400; bitmap.UriSource=new Uri(Path.GetFullPath(item.SourcePath)); bitmap.EndInit(); bitmap.Freeze();
                    BitmapSource source = item.Monochrome ? new FormatConvertedBitmap(bitmap,PixelFormats.Gray8,null,0) : bitmap;''';new='''                    BitmapSource bitmap;
                    if(item.PlanningSource is {} owned)
                    {var copy=owned.Bind();bitmap=PlanningOwnedReferenceImage.ReadBounded(copy,copy.ProjectId,copy.DocumentId,copy.ReferenceId,1400);}
                    else{var external=new BitmapImage();external.BeginInit();external.CacheOption=BitmapCacheOption.OnLoad;external.DecodePixelWidth=1400;external.UriSource=new Uri(Path.GetFullPath(item.SourcePath));external.EndInit();external.Freeze();bitmap=external;}
                    BitmapSource source = item.Monochrome ? new FormatConvertedBitmap(bitmap,PixelFormats.Gray8,null,0) : bitmap;''';assert old in s;s=s.replace(old,new);p.write_text(s,encoding='utf8')
