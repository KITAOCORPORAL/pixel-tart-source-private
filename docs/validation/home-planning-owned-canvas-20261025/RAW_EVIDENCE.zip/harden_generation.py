from pathlib import Path
r=Path.cwd()/'guangjing-home-owned-canvas-20261025';p=r/'src/PixelTart.Modules.AssetLibrary/FreeCanvas/FreeCanvasSurface.cs';s=p.read_text().replace('private readonly HashSet<Guid> _loading = [];','private readonly HashSet<(Guid Id,long Generation)> _loading = [];');s=s.replace('''        var generation=++_previewGeneration;
''','''        var generation=++_previewGeneration;
        var document=Editor.Document;
''');s=s.replace('''        var viewport=new Rect''','''        foreach(var id in _ownedKeys.Keys.Where(id=>!currentIds.Contains(id)).ToArray())_ownedKeys.Remove(id);
        var viewport=new Rect''');s=s.replace('''        {
            if(item.PlanningSource is {} owned)''','''        {
            if(generation!=_previewGeneration||!ReferenceEquals(document,Editor.Document))break;
            var sourceKey=item.PlanningSource is {} identity?$"owned|{identity.PlanningRoot}|{identity.Copy.RelativePath}|{identity.Copy.Sha256}":$"external|{item.SourcePath}|{item.LibraryId}|{item.AssetId}|{item.ContentHash}";
            if(_ownedKeys.GetValueOrDefault(item.ObjectId)!=sourceKey){_images.Remove(item.ObjectId);_widths.Remove(item.ObjectId);_sourceErrors.Remove(item.ObjectId);_ownedKeys[item.ObjectId]=sourceKey;}
            if(item.PlanningSource is {} owned)''');s=s.replace('''                var key=$"{owned.PlanningRoot}|{owned.Copy.RelativePath}|{owned.Copy.Sha256}";
                if(_ownedKeys.GetValueOrDefault(item.ObjectId)!=key){_images.Remove(item.ObjectId);_widths.Remove(item.ObjectId);_sourceErrors.Remove(item.ObjectId);_ownedKeys[item.ObjectId]=key;}
''','');s=s.replace('''                    _images[item.ObjectId]=bitmap;_sourceErrors.Remove(item.ObjectId);''','''                    _images[item.ObjectId]=bitmap;_sourceErrors.Remove(item.ObjectId);TrimPreviews(item.ObjectId);''');s=s.replace('_loading.Contains(item.ObjectId)','_loading.Contains((item.ObjectId,generation))').replace('_loading.Add(item.ObjectId)','_loading.Add((item.ObjectId,generation))').replace('_loading.Remove(item.ObjectId)','_loading.Remove((item.ObjectId,generation))');s=s.replace('''                if (resolvedPath is null)''','''                if(generation!=_previewGeneration||!ReferenceEquals(document,Editor.Document))continue;
                if (resolvedPath is null)''');s=s.replace('''                if (result.Bitmap is { } bitmap)''','''                if(generation!=_previewGeneration||!ReferenceEquals(document,Editor.Document))continue;
                if (result.Bitmap is { } bitmap)''');old='''                while(_images.Count>1&&(_images.Count>128||_images.Values.Sum(image=>(long)image.PixelWidth*image.PixelHeight*4)>192L*1024*1024)){var remove=_images.Keys.First(id=>id!=item.ObjectId);_images.Remove(remove);_widths.Remove(remove);}''';s=s.replace(old,'                TrimPreviews(item.ObjectId);');needle='''    private Brush Brush(string resource, Color fallback)''';s=s.replace(needle,'''    private void TrimPreviews(Guid keep)
    {
        while(_images.Count>1&&(_images.Count>128||_images.Values.Sum(image=>(long)image.PixelWidth*image.PixelHeight*4)>192L*1024*1024))
        {var remove=_images.Keys.First(id=>id!=keep);_images.Remove(remove);_widths.Remove(remove);}
    }
'''+needle);p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/ViewModels/PlanningCenterViewModel.References.cs';s=p.read_text().replace('''        if (SelectedSourceCandidate is not { } item) return;
        var source''','''        if (SelectedSourceCandidate is not { } item) return;
        if(item.PlanningSource is not null)
        {SaveStatus="项目自有画布参考保留原策划身份；本入口不将其转为外链，请回原策划使用。";return;}
        var source''');p.write_text(s,encoding='utf8')
# Explicitly prove that the offline thumbnail provider cannot supply an owned image, including errors.
p=r/'tests/RAWSelectionAssistant.WpfTests/PlanningOwnedCanvasTests.cs';s=p.read_text().replace('var surface=new FreeCanvasSurface(new(reopened),new WpfAssetThumbnailProvider());','var forbidden=new ForbiddenProvider();var surface=new FreeCanvasSurface(new(reopened),forbidden);');s=s.replace('Assert.HasCount(1,surface.SourceErrors);await store.SaveAsync(reopened);','Assert.HasCount(1,surface.SourceErrors);Assert.AreEqual(0,forbidden.Calls);await store.SaveAsync(reopened);');s=s.replace('''    static string Hash(string p)''','''    sealed class ForbiddenProvider:IAssetPreviewProvider
    {public int Calls;public Task<AssetPreviewResult> GetAsync(AssetPreviewRequest request,CancellationToken token=default){Calls++;throw new InvalidOperationException("Owned source must never consult offline cache provider");}}
    static string Hash(string p)''');p.write_text(s,encoding='utf8')
