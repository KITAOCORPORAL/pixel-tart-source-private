from pathlib import Path
import json,subprocess,hashlib,zipfile,xml.etree.ElementTree as ET,collections,shutil,datetime
root=Path.cwd();r=root/'guangjing-home-owned-canvas-20261025';out=root/'Guangjing-CanvasOwned-20261025';final=out/'final-r2';reports=out/'reports';reports.mkdir(exist_ok=False);h=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def dump(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2),encoding='utf8')
sha=subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD'],text=True).strip();remote=subprocess.check_output(['git','-C',str(r),'ls-remote','--heads','origin','company/planning-bounded-thumbnails-20261023'],text=True).strip();assert remote.split()[0]=='dad3dd4c76d99df8b93805843cbe6cd69d1abe36';assert not subprocess.check_output(['git','-C',str(r),'diff','e6ddb8d1018713fb48fbaa7e7cf3a3b23df0cc30','dad3dd4c76d99df8b93805843cbe6cd69d1abe36','--','src','tests'],text=True)
# Audit only already enumerated worktrees. No ignored directory or old-ZIP rescan.
old=json.loads((out/'worktrees-before.json').read_text(encoding='utf-8-sig'));after=[]
for row in old:
 p=Path(row['path']);head=subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip();branch=subprocess.check_output(['git','-C',str(p),'branch','--show-current'],text=True).strip();status=subprocess.check_output(['git','-C',str(p),'status','--porcelain=v1','--untracked-files=all'],text=True).splitlines();after.append(dict(path=str(p),headUnchanged=head==row['head'],branchUnchanged=branch==row['branch'],statusUnchanged=status==row['status']))
assert all(x['headUnchanged'] and x['branchUnchanged'] and x['statusUnchanged'] for x in after);dump(reports/'PRESERVATION.json',dict(before=old,readback=after,scope='19 pre-existing worktrees HEAD/branch/status only; untracked list retained, no repeated full-disk/ignored/old ZIP hashing'))
bind=json.loads((final/'bindings.json').read_text())
for b in bind['bindings']:assert h(Path(b['published']))==h(Path(b['test']))==b['sha256']
shutil.copy2(final/'bindings.json',reports/'BINDINGS.json');shutil.copy2(out/'decoder-equivalence.json',reports/'DECODER_EQUIVALENCE.json');dump(reports/'SOURCE_IDENTITY.json',dict(sourceSha=sha,baseSha='dad3dd4c76d99df8b93805843cbe6cd69d1abe36',companyProduct='e6ddb8d1018713fb48fbaa7e7cf3a3b23df0cc30',baseRemoteReadback=remote,baseProductSrcTestsEqual=True,branch='home/planning-owned-canvas-20261025',sdk=subprocess.check_output(['dotnet','--version'],cwd=r,text=True).strip(),utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),reportTimezone='Asia/Shanghai',hostTimezone='raw host/UTC timestamps retained',installerBuilt=False))
# All selected final results, plus raw failures separately.
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};results=[]
for label in ['core','wpf']:
 tree=ET.parse(final/('tests-'+label)/'results.trx').getroot()
 for row in tree.findall('.//t:UnitTestResult',ns):
  message=row.find('.//t:Message',ns);results.append(dict(suite=label,name=row.get('testName'),outcome=row.get('outcome'),duration=row.get('duration'),id=row.get('testId'),message=message.text if message is not None else None))
dump(reports/'RESULTS.json',results);dump(reports/'TEST_SUMMARY.json',{label:dict(collections.Counter(x['outcome'] for x in results if x['suite']==label)) for label in ['core','wpf']});dump(reports/'NONPASS.json',[x for x in results if x['outcome']!='Passed'])
# In-repo historical household performance authority, read original TRX, not company numbers.
oldEvidence=r/'docs/validation/home-external-reconnect-20261022';archive=oldEvidence/'RAW_EVIDENCE.zip'
with zipfile.ZipFile(archive) as z:
 names=['performance-final-r4/identity.json','performance-final-r4/measurements/performance.json','performance-final-r4/original-single/scenario11.trx']
 raw={n:z.read(n) for n in names};perf=json.loads(raw[names[1]]);trx=ET.fromstring(raw[names[2]]);runs=trx.findall('.//t:UnitTestResult',ns);assert len(runs)==1 and runs[0].get('outcome')=='Passed';assert perf['open_switch_iterations']==10000 and perf['cold_total_ms']<30000
 dump(reports/'HISTORICAL_HOME_SCENARIO11.json',dict(authority='Existing committed household raw TRX and output; no rerun this batch',archive=str(archive),archiveSha256=h(archive),paths=names,identity=json.loads(raw[names[0]]),measurement=perf,outcome=runs[0].get('outcome'),rawSha256={n:hashlib.sha256(b).hexdigest() for n,b in raw.items()},scope='Historical source4f57ca56, not performance of current canvas commit; historical physical-volume caveat remains'))
# Desktop error kept literal. Process launch is not UI acceptance.
for n in ['desktop-start.json','desktop-stop.json','final-desktop-start.json','final-desktop-stop.json','final-desktop-components.json']:
 if (out/n).exists():shutil.copy2(out/n,reports/n)
actual=json.loads((out/'final-desktop-components.json').read_text(encoding='utf-8-sig'))
for m in actual['modules']:assert h(Path(m['path'])).upper()==m['sha256'];assert sha in m['product']
dump(reports/'DESKTOP_STATUS.json',dict(status='BLOCKED_NATIVE_TOOL_UNAVAILABLE',sourceSha=sha,exactError='unsupported call: mcp__cua_repljs',errorRecoveryCalls=['unsupported custom tool call: exec','unsupported call: mcp__cua_repljs_reset'],completed=['Full final win-x64 diagnostic process launched PID29788','OS process identity/title/responding/modules readback','CloseMainWindow on own isolated process returned true, confirmed exited'],nativeUiCompleted=False,notExecuted=['current-root native import','ordinary-list open','JPEG references/shot thumbnails/large view','shot reconnect-to-owned','edit/save/normal UI exit/new-process ordinary reopen','15-section native export','package import into second isolated root and owned image view','rapid native A/B project switch','native send-owned-to-canvas/save/reopen'],manualSteps='MANUAL_RETEST.md',automatedTestsDoNotSubstituteNative=True))
# Full dependency/readback identities.
app=final/'app';files=[dict(path=p.relative_to(app).as_posix(),bytes=p.stat().st_size,sha256=h(p)) for p in sorted(app.rglob('*')) if p.is_file()];dump(reports/'APP_FILES.json',files);deps=json.loads((app/'KitaoPhotoSelector.deps.json').read_text());assets=[]
for target in deps['targets'].values():
 for lib,info in target.items():
  for kind in ['runtime','native','resources','runtimeTargets']:
   for name,value in info.get(kind,{}).items():
    if name.endswith('/_._') or (kind=='runtimeTargets' and value.get('rid') not in [None,'win-x64','win']):continue
    candidates=[app/name,app/Path(name).name]
    if kind=='resources':candidates.append(app/value.get('locale','')/Path(name).name)
    assets.append(dict(library=lib,kind=kind,path=name,present=any(p.is_file() for p in candidates)))
assert all(x['present'] for x in assets);dump(reports/'DEPENDENCIES.json',assets)
# Repro helpers and all run artifacts, but never temp databases/user-data/full app binaries.
rawZip=out/'CanvasOwned-Raw-Evidence.zip';manifest=[]
with zipfile.ZipFile(rawZip,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(out)
  if any(part in ['app','temp','reports','desktop-runtime','final-native-runtime','test-runtime','isolated-runtime','foreign-root'] for part in rel.parts):continue
  if p.suffix.lower() not in ['.json','.log','.trx','.py']:continue
  b=p.read_bytes();z.writestr(rel.as_posix(),b);manifest.append(dict(path=rel.as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
with zipfile.ZipFile(rawZip) as z:
 for x in manifest:assert hashlib.sha256(z.read(x['path'])).hexdigest()==x['sha256']
dump(reports/'RAW_MANIFEST.json',manifest);dump(reports/'RAW_IDENTITY.json',dict(path=str(rawZip),bytes=rawZip.stat().st_size,sha256=h(rawZip),files=len(manifest),readback=True));print(json.dumps(dict(sourceSha=sha,tests=len(results),oldTrees=len(old),appFiles=len(files),runtimeAssets=len(assets),rawFiles=len(manifest))))
