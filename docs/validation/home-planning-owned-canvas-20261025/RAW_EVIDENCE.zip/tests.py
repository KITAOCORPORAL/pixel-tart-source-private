from pathlib import Path
r=Path.cwd()/'guangjing-home-owned-canvas-20261025'
p=r/'src/PixelTart.Modules.AssetLibrary/AssetLibraryPage.Canvas.cs';s=p.read_text().replace('''        canvas.ViewAsset=item=>{var window=new AssetViewerWindow([item.SourcePath],0,_previewProvider){Owner=Window.GetWindow(this)};window.Show();return Task.CompletedTask;};''','''        canvas.ViewAsset=async item=>
        {
            if(item.PlanningSource is {} owned)
            {
                try{var copy=owned.Bind();var bitmap=await Task.Run(()=>OwnedPlanningReferenceImage.Read(copy,copy.ProjectId,copy.DocumentId,copy.ReferenceId));
                    new Window{Title=item.Name+" · 项目自有参考",Owner=Window.GetWindow(this),Width=1000,Height=760,Content=new Image{Source=bitmap,Stretch=System.Windows.Media.Stretch.Uniform}}.Show();}
                catch(Exception error)when(error is System.IO.IOException or UnauthorizedAccessException or ArgumentException or NotSupportedException or InvalidOperationException)
                {MessageBox.Show(Window.GetWindow(this),"项目自有副本不可用，未回退原外链或缓存："+error.Message,"画布参考");}
                return;
            }
            new AssetViewerWindow([item.SourcePath],0,_previewProvider){Owner=Window.GetWindow(this)}.Show();
        };''');p.write_text(s,encoding='utf8')
(r/'tests/RAWSelectionAssistant.Tests/CanvasPlanningSourceTests.cs').write_text('''using RAWSelectionAssistant.Core.Services.FreeCanvas;
using RAWSelectionAssistant.Core.Services.Projects;
namespace RAWSelectionAssistant.Tests;
[TestClass]public sealed class CanvasPlanningSourceTests
{
    [TestMethod]public async Task ReceiptPersistsAndRebindsWithoutSerializingTransientCopyRootOrUsingOriginal()
    {
        using var t=new TempDirectory();var store=new PlanningProjectStore(t.Combine("planning"));var project=Guid.NewGuid();var id=Guid.NewGuid();var original=t.CreateFile("source.png",new byte[]{137,80,78,71,13,10,26,10,1});
        await store.ImportProjectCopiesAsync(project,[new(new(id,ShotReferenceKind.General,ExternalReference:original))],[]);var copy=(await store.LoadAsync(project)).Document!.References.Single().ProjectCopy!;
        var canvas=new CanvasDocument{ProjectId=project};canvas=canvas with{Objects=[new(){CanvasId=canvas.CanvasId,Name="原名称",PlanningSource=CanvasPlanningSource.From(copy),ContentHash=copy.Sha256,X=35,Y=60}]};
        var canvases=new CanvasDocumentStore(t.Combine("canvas"));await canvases.SaveAsync(canvas);File.Delete(original);var loaded=(await canvases.LoadAsync(canvas.CanvasId))!;var obj=loaded.Objects.Single();Assert.AreEqual("",obj.SourcePath);Assert.AreEqual("原名称",obj.Name);Assert.AreEqual(35d,obj.X);Assert.AreEqual(id,obj.PlanningSource!.Copy.ReferenceId);Assert.IsNull(obj.PlanningSource.Copy.StorageRoot);
        using(var verified=obj.PlanningSource.OpenVerified())Assert.AreEqual(copy.Bytes,verified.Length);
        await File.WriteAllBytesAsync(PlanningProjectCopyStorage.Resolve(copy),new byte[]{1,2,3});Assert.ThrowsExactly<InvalidDataException>(()=>obj.PlanningSource.OpenVerified());
        File.Delete(PlanningProjectCopyStorage.Resolve(copy));Assert.ThrowsAsync<FileNotFoundException>(()=>Task.Run(()=>obj.PlanningSource.OpenVerified()));
    }
    [TestMethod]public void ConflictingFallbackAndNonReferenceReceiptAreRejectedBeforeSave()
    {
        var project=Guid.NewGuid();var document=Guid.NewGuid();var id=Guid.NewGuid();var original=Path.GetFullPath("synthetic.png");var copy=new PlanningProjectCopy(project,document,id,"reference",original,"",new string('A',64),10,DateTimeOffset.UtcNow);copy=copy with{RelativePath=PlanningProjectCopyStorage.Relative(copy)};var source=new CanvasPlanningSource(Path.GetTempPath(),copy);var canvas=new CanvasDocument();canvas=canvas with{Objects=[new(){CanvasId=canvas.CanvasId,PlanningSource=source,ContentHash=copy.Sha256,SourcePath=original}]};Assert.ThrowsExactly<InvalidDataException>(()=>CanvasDocumentStore.Validate(canvas));
        Assert.ThrowsExactly<InvalidDataException>(()=>(source with{Copy=copy with{Kind="attachment"}}).Validate());
        Assert.ThrowsExactly<InvalidDataException>(()=>(source with{PlanningRoot="relative"}).Validate());
    }
}
''',encoding='utf8')
p=r/'tests/RAWSelectionAssistant.Tests/CanvasPlanningSourceTests.cs';s=p.read_text().replace('Assert.ThrowsAsync<FileNotFoundException>(()=>Task.Run(()=>obj.PlanningSource.OpenVerified()));','await Assert.ThrowsAsync<FileNotFoundException>(()=>Task.Run(()=>obj.PlanningSource.OpenVerified()));');p.write_text(s,encoding='utf8')
(r/'tests/RAWSelectionAssistant.WpfTests/PlanningOwnedCanvasTests.cs').write_text('''using System.IO;
using System.Security.Cryptography;
using System.Text.Json;
using System.Windows.Media.Imaging;
using PixelTart.Modules.AssetLibrary;
using PixelTart.Modules.AssetLibrary.FreeCanvas;
using RAWSelectionAssistant.Core.Services.FreeCanvas;
using RAWSelectionAssistant.Core.Services.Projects;
using RAWSelectionAssistant.Services;
using static RAWSelectionAssistant.WpfTests.RuntimeCorrectionWpfTests;
namespace RAWSelectionAssistant.WpfTests;
[TestClass][DoNotParallelize]public sealed class PlanningOwnedCanvasTests
{
    static string Hash(string p)=>Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(p)));
    static byte[] Pixels(BitmapSource bitmap){var b=new byte[bitmap.PixelWidth*bitmap.PixelHeight*4];new System.Windows.Media.Imaging.FormatConvertedBitmap(bitmap,System.Windows.Media.PixelFormats.Bgra32,null,0).CopyPixels(b,bitmap.PixelWidth*4,0);return b;}
    [TestMethod]public Task OwnedReferenceSendSaveReopenCacheDeletionMissingChangedAndRepeatedSend()=>RunSta(async()=>
    {
        EnsureTestApplication();using var f=await PlanningFoundationWpfTests.Fixture.Create();await f.Vm.LoadAsync(f.Id);f.Vm.DocumentTitle="自有画布合成";var original=Path.Combine(f.Root,"original.jpg");File.Copy(Path.Combine(TestResources.Root,"tests/fixtures/planning-owned-jpeg/orientation-6.jpg"),original);
        await f.Vm.AddDocumentReferencesAsync([new(Guid.NewGuid(),ShotReferenceKind.General,ExternalReference:original,Title:"保持原参考标题")],true);await f.Vm.FlushAsync();var reference=f.Vm.AllProjectReferences.Single();var copy=reference.Link.ProjectCopy!;var expected=PlanningOwnedReferenceImage.Read(copy,f.Id,copy.DocumentId,copy.ReferenceId);var cached=reference.PreviewPath!;File.Delete(original);if(File.Exists(cached))File.Delete(cached);if(File.Exists(cached+".sha256"))File.Delete(cached+".sha256");
        await f.Vm.SendToCanvasAsync(reference);await f.Vm.SendToCanvasAsync(reference);Assert.HasCount(2,f.Vm.ProjectCanvases);var canvas=f.Vm.ProjectCanvases.Last();var item=canvas.Objects.Single();Assert.AreEqual("",item.SourcePath);Assert.IsNotNull(item.PlanningSource);Assert.AreEqual(reference.Id,item.PlanningSource.Copy.ReferenceId);Assert.AreEqual("保持原参考标题",item.Name);Assert.AreEqual(0d,item.X);Assert.AreEqual(0d,item.Y);
        var store=new CanvasDocumentStore(Path.Combine(f.Root,"canvas"));var reopened=(await store.LoadAsync(canvas.CanvasId))!;var surface=new FreeCanvasSurface(new(reopened),new WpfAssetThumbnailProvider());await surface.LoadPreviewsAsync();Assert.HasCount(1,surface.LoadedPreviews);CollectionAssert.AreEqual(Pixels(expected),Pixels(surface.LoadedPreviews.Single().Value));Assert.IsEmpty(surface.SourceErrors);Assert.IsNotNull(PlanningCanvasSnapshot.Render(reopened));
        // A provider with an old cached bitmap must never be consulted for owned sources.
        var actual=PlanningProjectCopyStorage.Resolve(copy);var bytes=File.ReadAllBytes(actual);File.WriteAllBytes(actual,bytes.Concat(new byte[]{3}).ToArray());await surface.LoadPreviewsAsync();Assert.IsEmpty(surface.LoadedPreviews);StringAssert.Contains(surface.SourceErrors[item.ObjectId],"未回退");Assert.ThrowsExactly<InvalidDataException>(()=>PlanningCanvasSnapshot.Render(reopened));
        File.WriteAllBytes(actual,bytes);await surface.LoadPreviewsAsync();Assert.HasCount(1,surface.LoadedPreviews);File.Delete(actual);await surface.LoadPreviewsAsync();Assert.IsEmpty(surface.LoadedPreviews);Assert.HasCount(1,surface.SourceErrors);await store.SaveAsync(reopened);Assert.IsNotNull(await store.LoadAsync(canvas.CanvasId));
        var output=Environment.GetEnvironmentVariable("KITAO_CANVAS_OWNED_EVIDENCE");if(!string.IsNullOrWhiteSpace(output)){Directory.CreateDirectory(output);await File.WriteAllTextAsync(Path.Combine(output,"OWNED_CANVAS_RESULT.json"),JsonSerializer.Serialize(new{canvas=canvas.CanvasId,reference=reference.Id,source=item.PlanningSource,originalDeleted=true,thumbnailDeleted=true,savedReopened=true,changedAndMissingCleared=true,scope="WPF real stores; not native desktop"},new JsonSerializerOptions{WriteIndented=true}));}
    });
    [TestMethod]public Task DifferentProjectsAndStaleOwnedCardDoNotCrossSourcesOrExpandPackageBoundary()=>RunSta(async()=>
    {
        EnsureTestApplication();using var a=await PlanningFoundationWpfTests.Fixture.Create();using var b=await PlanningFoundationWpfTests.Fixture.Create();
        foreach(var f in new[]{a,b}){await f.Vm.LoadAsync(f.Id);var source=Path.Combine(f.Root,"image.png");await File.WriteAllBytesAsync(source,PlanningRichFlowFixture.ReferencePng(f==a?0:1));await f.Vm.AddDocumentReferencesAsync([new(Guid.NewGuid(),ShotReferenceKind.General,ExternalReference:source,Title:f==a?"A蓝橙":"B不同图")],true);}
        var card=a.Vm.AllProjectReferences.Single();await a.Vm.SendToCanvasAsync(card);await b.Vm.SendToCanvasAsync(b.Vm.AllProjectReferences.Single());var ca=a.Vm.ProjectCanvases.Single();var cb=b.Vm.ProjectCanvases.Single();var editor=new CanvasEditor(ca);var surface=new FreeCanvasSurface(editor,new WpfAssetThumbnailProvider());await surface.LoadPreviewsAsync();var pa=Pixels(surface.LoadedPreviews.Single().Value);editor.Load(cb);await surface.LoadPreviewsAsync();var pb=Pixels(surface.LoadedPreviews.Single().Value);Assert.IsFalse(pa.SequenceEqual(pb));editor.Load(ca);await surface.LoadPreviewsAsync();CollectionAssert.AreEqual(pa,Pixels(surface.LoadedPreviews.Single().Value));
        await Assert.ThrowsExactlyAsync<InvalidDataException>(()=>b.Vm.SendToCanvasAsync(card));var package=Path.Combine(a.Root,"canvas-boundary.ptplan");await a.Vm.ExportProjectPackageAsync(package);var checkedPackage=PlanningProjectPackage.Validate(package);Assert.IsFalse(checkedPackage.Data.Keys.Any(k=>k.Contains("canvas",StringComparison.OrdinalIgnoreCase)));Assert.IsTrue(checkedPackage.Manifest.ExcludedDependencies.Any(x=>x.Contains("自由画布")));
    });
    [TestMethod]public Task DecoderMovePreservesAllEightCompanyOrientations()=>RunSta(async()=>
    {
        foreach(var i in Enumerable.Range(1,8)){var file=Path.Combine(TestResources.Root,$"tests/fixtures/planning-owned-jpeg/orientation-{i}.jpg");var bytes=File.ReadAllBytes(file);CollectionAssert.AreEqual(Pixels(PlanningOwnedReferenceImage.Decode(bytes,".jpg")),Pixels(OwnedPlanningReferenceImage.Decode(bytes,".jpg")));}await Task.CompletedTask;
    });
}
''',encoding='utf8')
