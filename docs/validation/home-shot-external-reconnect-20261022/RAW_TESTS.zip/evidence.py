from pathlib import Path
import json,subprocess,hashlib,xml.etree.ElementTree as ET,zipfile,shutil,collections
root=Path.cwd();r=root/'guangjing-home-shot-reconnect-20261022';out=root/'Guangjing-ShotReconnect-20261022';final=out/'final';e=r/'docs/validation/home-shot-external-reconnect-20261022';e.mkdir();sha=subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD'],text=True).strip();h=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def dump(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2),encoding='utf8')
old=json.loads((out/'worktrees-before.json').read_text(encoding='utf-8-sig'));after=[]
for row in old:
 p=Path(row['path']);head=subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip();branch=subprocess.check_output(['git','-C',str(p),'branch','--show-current'],text=True).strip();status=subprocess.check_output(['git','-C',str(p),'status','--porcelain=v1','--untracked-files=all'],text=True).splitlines();after.append(dict(path=str(p),headUnchanged=head==row['head'],branchUnchanged=branch==row['branch'],statusUnchanged=status==row['status']))
assert all(x['headUnchanged'] and x['branchUnchanged'] and x['statusUnchanged'] for x in after);dump(e/'PRESERVATION.json',dict(before=old,readback=after,scope='HEAD/branch/status only; no repeated ignored/ZIP audit or old tree/data edits'))
rows=[];ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
for label in ['core','wpf']:
 xml=ET.parse(final/('tests-'+label)/'results.trx').getroot()
 for result in xml.findall('.//t:UnitTestResult',ns):
  msg=result.find('.//t:Message',ns);rows.append(dict(suite=label,name=result.get('testName'),outcome=result.get('outcome'),duration=result.get('duration'),id=result.get('testId'),message=msg.text if msg is not None else None))
dump(e/'RESULTS.json',rows);dump(e/'TEST_SUMMARY.json',{suite:dict(collections.Counter(x['outcome'] for x in rows if x['suite']==suite)) for suite in ['core','wpf']})
app=final/'app';bindings=json.loads((final/'bindings.json').read_text())
for b in bindings['bindings']:assert h(Path(b['published']))==h(Path(b['test']))==b['sha256']
shutil.copy2(final/'bindings.json',e/'BINDINGS.json');dump(e/'BUILD_IDENTITY.json',dict(sourceSha=sha,baseSha='23b0d8916a7e831583a84e790b5d10755ed329d3',branch='home/planning-shot-external-reconnect-20261022',sdk=subprocess.check_output(['dotnet','--version'],cwd=r,text=True).strip(),app=str(app),diagnosticOnly=True,installerBuilt=False,files=[dict(name=n,sha256=h(app/n),bytes=(app/n).stat().st_size) for n in ['KitaoPhotoSelector.exe','KitaoPhotoSelector.dll','RAWSelectionAssistant.Core.dll']]))
for name in ['desktop-start.json','desktop-stop.json','desktop-components.json']:shutil.copy2(out/name,e/name)
dump(e/'DESKTOP_STATUS.json',dict(sourceSha=sha,status='BLOCKED',tool='native @oai/sky',pid=33292,performed=['Start compiled Windows EXE in new isolated root','Observed diagnostic title and tutorial','Click Exit tutorial','One activate-window recovery attempt'],blocking='Selected-target capture showed unrelated foreground app after tutorial exit, still wrong after activation; stopped input. No unrelated screenshot persisted.',notExecuted=['shot package native import','native locate/confirm','native save','normal UI exit','new process reopen','native preview'],shutdown='CloseMainWindow on own process returned true; confirmed exited. Not a completed UI loop.',viewModelIsNotDesktopAcceptance=True))
raw=e/'RAW_TESTS.zip';manifest=[]
with zipfile.ZipFile(raw,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(out.rglob('*')):
  if not f.is_file():continue
  rel=f.relative_to(out)
  if any(part in ['app','desktop-runtime','isolated-runtime','temp'] for part in rel.parts):continue
  if f.suffix not in ['.log','.trx','.json','.py']:continue
  data=f.read_bytes();name=rel.as_posix();z.writestr(name,data);manifest.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
with zipfile.ZipFile(raw) as z:
 for item in manifest:assert hashlib.sha256(z.read(item['path'])).hexdigest()==item['sha256']
dump(e/'RAW_MANIFEST.json',manifest);shutil.copytree(final/'samples',e/'samples');(e/'.gitattributes').write_text('*.json text eol=lf\n*.md text eol=lf\n',encoding='utf8');print(len(old),len(rows),len(manifest),raw.stat().st_size)
