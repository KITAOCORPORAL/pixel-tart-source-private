from pathlib import Path
r=Path.cwd()/'guangjing-home-shot-reconnect-20261022'
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/PlanningDocument.cs';s=p.read_text().replace('    public IReadOnlyList<PlanningAttachment> Attachments { get; init; } = [];','    public IReadOnlyList<PlanningAttachment> Attachments { get; init; } = [];\n    public IReadOnlyList<PlanningShotExternalLink> ShotExternalLinks { get; init; } = [];');s=s.replace('References is null || Attachments is null','References is null || Attachments is null || ShotExternalLinks is null');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/ProjectShotExecution.cs';s=p.read_text();needle='    public Task SaveAsync(ProjectShot shot, CancellationToken token = default)';s=s.replace(needle,'''    // Reconnect writes only the planning receipt, but freezes the source catalog until that
    // atomic write completes. No second file transaction or shot rewrite is necessary.
    internal async Task WithCatalogLockAsync(Guid projectId, Func<ProjectShotCatalog, Task> action, CancellationToken token)
    {
        var path=FilePath(projectId);var gate=Gates.GetOrAdd(path,_=>new(1,1));await gate.WaitAsync(token).ConfigureAwait(false);
        try{await action(await ReadAsync(projectId,path,token).ConfigureAwait(false)).ConfigureAwait(false);}
        finally{gate.Release();}
    }

'''+needle);p.write_text(s,encoding='utf8')
(r/'src/RAWSelectionAssistant.Core/Services/Projects/PlanningShotExternalLink.cs').write_text(r'''namespace RAWSelectionAssistant.Core.Services.Projects;

/// <summary>Approval/ownership belongs to this planning document, not to the execution source.
/// Shot IDs are explicit recipients. Source records in .shots.json are never rewritten.</summary>
public sealed record PlanningShotExternalLink(Guid ReferenceId, string OriginalPath, IReadOnlyList<Guid> ShotIds,
    PlanningExternalFile? ReconnectedFile = null, PlanningProjectCopy? ProjectCopy = null)
{
    public void Validate()
    {
        if(ReferenceId==Guid.Empty || !Path.IsPathFullyQualified(OriginalPath) || ShotIds is null || ShotIds.Count==0 ||
            ShotIds.Any(id=>id==Guid.Empty) || ShotIds.Distinct().Count()!=ShotIds.Count || (ReconnectedFile is null && ProjectCopy is null))
            throw new InvalidDataException("镜头外链收据身份无效。");
        ReconnectedFile?.Validate(ReferenceId,"reference",OriginalPath);
    }
}

public static class PlanningReferenceLinks
{
    public static IEnumerable<PlanningProjectCopy> Copies(PlanningDocument document) => document.References.Select(r=>r.ProjectCopy)
        .Concat(document.Attachments.Select(a=>a.ProjectCopy)).Concat(document.ShotExternalLinks.Select(s=>s.ProjectCopy)).OfType<PlanningProjectCopy>();

    public static bool SameSource(ProjectShotReference a,ProjectShotReference b) => a.ReferenceId==b.ReferenceId &&
        a.LibraryId==b.LibraryId && a.AssetId==b.AssetId && string.Equals(a.ExternalReference,b.ExternalReference,StringComparison.Ordinal);

    public static bool HasConflict(PlanningDocument document,IEnumerable<ProjectShot> shots,Guid referenceId)
    {
        var docs=document.References.Where(r=>r.Source.ReferenceId==referenceId).ToArray();
        var sources=docs.Select(r=>r.Source).Concat(shots.SelectMany(s=>s.References).Where(r=>r.ReferenceId==referenceId)).ToArray();
        return docs.Length>1 || document.Attachments.Any(a=>a.Id==referenceId) || sources.Length==0 || sources.Any(s=>!SameSource(sources[0],s));
    }

    public static PlanningDocumentReference ForShot(PlanningDocument document,ProjectShot shot,ProjectShotReference source,string category="其他")
    {
        var documentLink=document.References.SingleOrDefault(r=>r.Source.ReferenceId==source.ReferenceId);
        if(documentLink is not null && SameSource(documentLink.Source,source))return documentLink with{Source=source};
        var receipt=document.ShotExternalLinks.SingleOrDefault(r=>r.ReferenceId==source.ReferenceId);
        return new(source,category){ProjectCopy=receipt is not null && receipt.ShotIds.Contains(shot.ShotId) && receipt.OriginalPath==source.ExternalReference?receipt.ProjectCopy:null,
            ReconnectedFile=receipt is not null && receipt.ShotIds.Contains(shot.ShotId) && receipt.OriginalPath==source.ExternalReference?receipt.ReconnectedFile:null};
    }
}
''',encoding='utf8')
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/PlanningProjectCopy.cs';s=p.read_text();s=s.replace('        Attachments = document.Attachments.Select', '''        ShotExternalLinks = BindShotLinks(document,root),
        Attachments = document.Attachments.Select''');needle='    private static PlanningExternalFile? BindExternal';s=s.replace(needle,'''    private static IReadOnlyList<PlanningShotExternalLink> BindShotLinks(PlanningDocument document,string root)
    {
        if(document.ShotExternalLinks.Select(s=>s.ReferenceId).Distinct().Count()!=document.ShotExternalLinks.Count)
            throw new InvalidDataException("重复镜头外链收据ID。");
        return document.ShotExternalLinks.Select(link=>
        {
            link.Validate();
            if(document.References.Any(r=>r.Source.ReferenceId==link.ReferenceId) || document.Attachments.Any(a=>a.Id==link.ReferenceId))
                throw new InvalidDataException("镜头独有收据与文档引用ID冲突。");
            return link with{ProjectCopy=BindCopy(link.ProjectCopy,document,link.ReferenceId,"reference",link.OriginalPath,root)};
        }).ToArray();
    }
'''+needle);p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/PlanningExternalReconnect.cs';s=p.read_text();start=s.index('    public async Task ReconnectExternalAsync(Guid projectId');s=s[:start]+r'''    public Task ReconnectExternalAsync(Guid projectId, PlanningExternalFile selected, bool importCopy, CancellationToken token = default) =>
        ReconnectExternalCoreAsync(projectId,selected,importCopy,null,null,token);

    public Task ReconnectExternalAsync(Guid projectId,PlanningExternalFile selected,bool importCopy,ProjectShotStore shots,
        IReadOnlyList<Guid>? expectedShotIds=null,CancellationToken token=default) =>
        shots.WithCatalogLockAsync(projectId,catalog=>ReconnectExternalCoreAsync(projectId,selected,importCopy,catalog,expectedShotIds,token),token);

    private async Task ReconnectExternalCoreAsync(Guid projectId,PlanningExternalFile selected,bool importCopy,
        ProjectShotCatalog? catalog,IReadOnlyList<Guid>? expectedShotIds,CancellationToken token)
    {
        var created = new List<string>();
        await UpdateAsync(projectId, async state =>
        {
            var document = (state.Document ?? throw new InvalidDataException("无策划文档")).EnsureIdentity(projectId);
            var refs = document.References.Where(x => x.Source.ReferenceId == selected.ReferenceId).ToArray();
            var files = document.Attachments.Where(x => x.Id == selected.ReferenceId).ToArray();
            var occurrences=catalog?.Shots.Where(s=>s.References.Any(r=>r.ReferenceId==selected.ReferenceId)).ToArray()??[];
            if(expectedShotIds is not null && !expectedShotIds.Order().SequenceEqual(occurrences.Select(s=>s.ShotId).Order()))
                throw new InvalidDataException("确认期间镜头引用归属变化；请重新选择。");
            var shotOnly=selected.Kind=="reference" && refs.Length==0 && occurrences.Length>0;
            if(refs.Length+files.Length!=(shotOnly?0:1) || (selected.Kind=="reference" && files.Length>0) ||
                (selected.Kind=="attachment" && refs.Length>0) || (selected.Kind=="attachment" && occurrences.Length>0))
                throw new InvalidDataException("同ID冲突或引用已移除；未改写现有数据。");
            if(selected.Kind=="reference" && catalog is not null && PlanningReferenceLinks.HasConflict(document,catalog.Shots,selected.ReferenceId))
                throw new InvalidDataException("同ID文档/镜头来源冲突；未改写现有数据。");
            var shotSource=occurrences.FirstOrDefault()?.References.Single(r=>r.ReferenceId==selected.ReferenceId);
            var original=refs.Length==1?refs[0].Source.ExternalReference:files.Length==1?files[0].Path:shotSource?.ExternalReference;
            var previousShot=document.ShotExternalLinks.SingleOrDefault(r=>r.ReferenceId==selected.ReferenceId);
            if(original is null || refs.Any(r=>r.Source.LibraryId is not null || r.ProjectCopy is not null) ||
                files.Any(f=>f.ProjectCopy is not null) || occurrences.Any(s=>s.References.Any(r=>r.ReferenceId==selected.ReferenceId && r.LibraryId is not null)) ||
                previousShot?.ProjectCopy is not null || (previousShot is not null && previousShot.OriginalPath!=original))
                throw new InvalidDataException("素材库、冲突来源或已有自有副本不可被重连覆盖。");
            selected.Validate(selected.ReferenceId,selected.Kind,original);
            var verified=await PlanningExternalFile.InspectAsync(selected.ReferenceId,selected.Kind,original,selected.SelectedPath,token).ConfigureAwait(false);
            if(!selected.SameContent(verified))throw new InvalidDataException("确认后文件类型、大小或SHA-256变化；请重新选择。");
            // A repeated approval is idempotent and never demotes/overwrites an owned copy.
            PlanningProjectCopy? copy=null;
            if(importCopy)
            {
                copy=await PlanningProjectCopyStorage.CopyAsync(StorageRoot,projectId,document.Package!.DocumentId,
                    selected.ReferenceId,selected.Kind,selected.SelectedPath,created,token,recordedOriginal:original).ConfigureAwait(false);
                if(copy.Bytes!=selected.Bytes || !copy.Sha256.Equals(selected.Sha256,StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException("复制期间文件内容变化；策划未提交。");
            }
            token.ThrowIfCancellationRequested();
            var shotLinks=document.ShotExternalLinks.Where(r=>r.ReferenceId!=selected.ReferenceId).ToList();
            if(shotOnly)shotLinks.Add(new(selected.ReferenceId,original,occurrences.Select(s=>s.ShotId).ToArray(),verified,copy));
            return state with{Document=document with
            {
                References=document.References.Select(x=>x.Source.ReferenceId==selected.ReferenceId?x with{ReconnectedFile=verified,ProjectCopy=copy}:x).ToArray(),
                Attachments=document.Attachments.Select(x=>x.Id==selected.ReferenceId?x with{ReconnectedFile=verified,ProjectCopy=copy}:x).ToArray(),
                ShotExternalLinks=shotLinks
            }};
        },token,()=>{foreach(var path in created){PlanningImageStorage.RejectLinks(StorageRoot,path);if(File.Exists(path))File.Delete(path);}}).ConfigureAwait(false);
    }
}
''';p.write_text(s,encoding='utf8')
# Include receipt-owned copies in recovery/package so no hidden fallback or missing packaged file.
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/PlanningCopyRecovery.cs';s=p.read_text().replace('document.References.Select(r=>r.ProjectCopy).Concat(document.Attachments.Select(a=>a.ProjectCopy))','PlanningReferenceLinks.Copies(document)').replace('draft.Document.References.Select(r=>r.ProjectCopy).Concat(draft.Document.Attachments.Select(a=>a.ProjectCopy))','PlanningReferenceLinks.Copies(draft.Document)');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/PlanningProjectPackage.cs';s=p.read_text().replace('var owned=d.References.Where(r=>r.ProjectCopy is not null).Select(r=>r.Source.ReferenceId).ToHashSet();','var owned=PlanningReferenceLinks.Copies(d).Where(c=>c.Kind=="reference").Select(c=>c.ReferenceId).ToHashSet();');s=s.replace('Attachments=document.Attachments.Select(x=>x with{ReconnectedFile=null}).ToArray()','Attachments=document.Attachments.Select(x=>x with{ReconnectedFile=null}).ToArray(),\n        ShotExternalLinks=document.ShotExternalLinks.Where(x=>x.ProjectCopy is not null).Select(x=>x with{ReconnectedFile=null}).ToArray()');s=s.replace('d.References.Select(r=>r.ProjectCopy).Concat(d.Attachments.Select(a=>a.ProjectCopy)).OfType<PlanningProjectCopy>()','PlanningReferenceLinks.Copies(d)');s=s.replace('loaded.Document!.References.Select(r=>r.ProjectCopy).Concat(loaded.Document.Attachments.Select(a=>a.ProjectCopy)).OfType<PlanningProjectCopy>()','PlanningReferenceLinks.Copies(loaded.Document!)');p.write_text(s,encoding='utf8')
