from pathlib import Path
import os,subprocess,json,time
root=Path.cwd();r=root/'guangjing-home-shot-reconnect-20261022';out=root/'Guangjing-ShotReconnect-20261022';env=os.environ.copy();env.update(KITAO_TEST_RESOURCE_ROOT=str(r),KITAO_SHOT_RECONNECT_EVIDENCE=str(out/'synthetic-r3'),PIXEL_TART_ISOLATED_RUNTIME='1',PIXEL_TART_ISOLATED_RUNTIME_ROOT=str(out/'test-runtime'));dotnet=r'C:\Program Files\dotnet\dotnet.exe'
for label,assembly,filter in [('core-r3','tests/RAWSelectionAssistant.Tests/bin/Release/net10.0/RAWSelectionAssistant.Tests.dll','FullyQualifiedName~PlanningShotExternalReconnectTests|FullyQualifiedName~PlanningExternalReconnectTests'),('wpf-r3','tests/RAWSelectionAssistant.WpfTests/bin/x64/Release/net10.0-windows10.0.19041.0/RAWSelectionAssistant.WpfTests.dll','FullyQualifiedName~PlanningShotExternalReconnectWpfTests|FullyQualifiedName~PlanningExternalReconnectWpfTests')]:
 folder=out/label;folder.mkdir();temp=folder/'temp';temp.mkdir();local=env.copy();local.update(TEMP=str(temp),TMP=str(temp));cmd=[dotnet,'vstest',str(r/assembly),'/TestCaseFilter:'+filter,'/Logger:trx;LogFileName=results.trx','/ResultsDirectory:'+str(folder)];start=time.time()
 with (folder/'stdout.log').open('wb') as f:
  p=subprocess.Popen(cmd,cwd=r,env=local,stdout=f,stderr=f,creationflags=subprocess.CREATE_NO_WINDOW)
  try:code=p.wait(timeout=120)
  except subprocess.TimeoutExpired:subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],stdout=f,stderr=f);code=-999
 (folder/'process.json').write_text(json.dumps(dict(command=cmd,pid=p.pid,startEpoch=start,endEpoch=time.time(),exitCode=code,temp=str(temp)),indent=2));print(label,code,flush=True)
