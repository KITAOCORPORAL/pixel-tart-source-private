from pathlib import Path
r=Path.cwd()/'guangjing-home-shot-reconnect-20261022'
p=r/'src/RAWSelectionAssistant/ViewModels/PlanningCenterViewModel.References.cs';s=p.read_text().replace('!IsPackageImported && owned is null && path is null && ReferencePathResolver', '!IsPackageImported && owned is null && reference.ReconnectedFile is null && path is null && ReferencePathResolver');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/ViewModels/PlanningCenterViewModel.ExternalReconnect.cs';s=p.read_text().replace('''        if(!item.CanReconnect)return;
        var path''','''        if(!item.CanReconnect)return;
        var expectedProject=ProjectId;
        var path''').replace('''            await ReconnectExternalAsync(selected,importCopy,expectedShotIds:item.ShotIds);''','''            if(ProjectId!=expectedProject){SaveStatus="定位期间项目已切换；未提交重连，请重新选择。";return;}
            if(!await ReconnectExternalAsync(selected,importCopy,expectedShotIds:item.ShotIds))
                _dialogs.ShowInfo("当前策划尚未保存，未提交重连；请先完成保存后重试。");''');p.write_text(s,encoding='utf8')
# Additional failure-side coverage without bypassing normal FileStream guards.
p=r/'tests/RAWSelectionAssistant.WpfTests/PlanningShotExternalReconnectWpfTests.cs';s=p.read_text();needle='''        var externalPackage=Path.Combine(output,"shot-external-approved-v1.ptplan");''';s=s.replace(needle,'''        // A changed selected file must not fall back to a now-existing old path or resolver.
        await File.WriteAllBytesAsync(reference.ExternalReference!,PlanningRichFlowFixture.ReferencePng(1));
        restarted.ReferencePathResolver=_=>Task.FromResult<string?>(reference.ExternalReference);
        await File.WriteAllBytesAsync(image,PlanningRichFlowFixture.ReferencePng(1));await restarted.RefreshDocumentReferencesAsync();
        Assert.IsFalse(restarted.AllProjectReferences.Single().SourceAvailable);Assert.IsNull(restarted.AllProjectReferences.Single().PreviewPath);Assert.IsNull(await restarted.ResolveOriginalAsync(restarted.AllProjectReferences.Single()));
        await File.WriteAllBytesAsync(image,PlanningRichFlowFixture.ReferencePng(0));await restarted.RefreshDocumentReferencesAsync();
'''+needle);# deleted source.Root disposes does now exist yes
p.write_text(s,encoding='utf8')
p=r/'tests/RAWSelectionAssistant.Tests/PlanningShotExternalReconnectTests.cs';s=p.read_text();needle='''    [TestMethod]public async Task PackageRoundtripRetainsShotCopyButDropsMachineExternalApproval()''';s=s.replace(needle,'''    [TestMethod]public async Task ReparseSelectedFileIsNeverFollowed()
    {
        using var f=await Fixture.Create();var alias=f.Temp.Combine("alias.png");
        try{File.CreateSymbolicLink(alias,f.Selected.SelectedPath);}
        catch(UnauthorizedAccessException){Assert.Inconclusive("Host cannot create synthetic symlink; no policy change.");return;}
        // Windows may report missing privilege as IOException; retain that environment failure.
        await Assert.ThrowsExactlyAsync<InvalidDataException>(()=>PlanningExternalFile.InspectAsync(f.Selected.ReferenceId,"reference",f.Selected.OriginalPath,alias));
    }
'''+needle);p.write_text(s,encoding='utf8')
