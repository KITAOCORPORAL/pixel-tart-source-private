from pathlib import Path
r=Path.cwd()/'guangjing-home-shot-reconnect-20261022';p=r/'src/RAWSelectionAssistant/ViewModels/PlanningCenterViewModel.ExternalReconnect.cs';s=p.read_text();s=s.replace('bool CanReconnect);','bool CanReconnect)\n{\n    public IReadOnlyList<Guid>? ShotIds {get;init;}\n}');start=s.index('    public IReadOnlyList<PlanningExternalDependency> ExternalDependencies =>');end=s.index('    public IReadOnlyList<string> UnsupportedPackageDependencies',start);s=s[:start]+'''    public IReadOnlyList<PlanningExternalDependency> ExternalDependencies
    {
        get
        {
            var rows=new List<PlanningExternalDependency>();
            var sources=_document.References.Select(r=>r.Source).Concat(Shots.SelectMany(s=>s.References));
            foreach(var group in sources.GroupBy(r=>r.ReferenceId))
            {
                var source=group.First();var shots=Shots.Where(s=>s.References.Any(r=>r.ReferenceId==group.Key)).ToArray();
                var conflict=PlanningReferenceLinks.HasConflict(_document,Shots,group.Key);
                var documentLink=_document.References.FirstOrDefault(r=>r.Source.ReferenceId==group.Key);
                var link=conflict?new PlanningDocumentReference(source):documentLink??PlanningReferenceLinks.ForShot(_document,shots[0],source);
                if(link.ProjectCopy is not null)continue;
                var section=(documentLink is null?"镜头独有参考":documentLink.Category+" / "+documentLink.Group)+(shots.Length==0?"":" · "+string.Join("、",shots.Select(shot=>$"镜头 {shot.Order+1:00} {shot.Name} [{shot.ShotId}]")));
                rows.Add(new(group.Key,"reference",source.Title??"未命名参考",section,source.ExternalReference??$"素材库 {source.LibraryId}/{source.AssetId}",
                    conflict?"同ID来源冲突；不能安全重连":source.LibraryId is not null?"素材库原件未打包；本功能不定位或扫描素材库":ExternalReason(link.ReconnectedFile,group.Key,"reference",source.ExternalReference),
                    !conflict && source.LibraryId is null && source.ExternalReference is not null){ShotIds=shots.Select(shot=>shot.ShotId).ToArray()});
            }
            rows.AddRange(_document.Attachments.Where(x=>x.ProjectCopy is null).Select(x=>new PlanningExternalDependency(x.Id,"attachment",x.Name,"文件",x.Path,ExternalReason(x.ReconnectedFile,x.Id,"attachment",x.Path),true)));
            return rows;
        }
    }
'''+s[end:];s=s.replace('await ReconnectExternalAsync(selected,importCopy);','await ReconnectExternalAsync(selected,importCopy,expectedShotIds:item.ShotIds);');s=s.replace('bool importCopy,CancellationToken token=default)\n    {','bool importCopy,CancellationToken token=default,IReadOnlyList<Guid>? expectedShotIds=null)\n    {');s=s.replace('await _planning.ReconnectExternalAsync(project,selected,importCopy,token);','await _planning.ReconnectExternalAsync(project,selected,importCopy,_shots,expectedShotIds,token);');s=s.replace('                _document=_document with\n                {','                _document=_document with\n                {\n                    ShotExternalLinks=saved.ShotExternalLinks,');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/ViewModels/PlanningCenterViewModel.References.cs';s=p.read_text();old='''        var references = _document.References.Concat(Shots.SelectMany(shot => shot.References)
            .Select(source => new PlanningDocumentReference(source, ReferenceCategoryFor(source.Kind)))).DistinctBy(item => item.Source.ReferenceId).ToArray();''';new='''        var references = _document.References.Concat(Shots.SelectMany(shot => shot.References
            .Select(source => PlanningReferenceLinks.ForShot(_document,shot,source,ReferenceCategoryFor(source.Kind))))).DistinctBy(item => item.Source.ReferenceId).ToArray();''';assert old in s;s=s.replace(old,new);s=s.replace('            var path = (ImportedPackageRoot','''            var conflict=PlanningReferenceLinks.HasConflict(_document,Shots,reference.Source.ReferenceId);
            var path = (ImportedPackageRoot''');s=s.replace('            var available = !string.IsNullOrWhiteSpace(path) && File.Exists(path);','            if(conflict)path=null;\n            var available = !string.IsNullOrWhiteSpace(path) && File.Exists(path);');# materialization shared id uses helper before no conflict exception ForShot fix below
s=s.replace('        if (item.Link.ProjectCopy is {} copy)', '        if(PlanningReferenceLinks.HasConflict(_document,Shots,item.Id))return null;\n        if (item.Link.ProjectCopy is {} copy)');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/PlanningShotExternalLink.cs';s=p.read_text().replace('document.References.SingleOrDefault(r=>r.Source.ReferenceId==source.ReferenceId)','document.References.FirstOrDefault(r=>r.Source.ReferenceId==source.ReferenceId)');needle='    public static PlanningDocumentReference ForShot';s=s.replace(needle,'''    public static void ValidateCatalog(PlanningDocument document,ProjectShotCatalog catalog)
    {
        foreach(var link in document.ShotExternalLinks)
        {
            var occurrences=catalog.Shots.Where(s=>link.ShotIds.Contains(s.ShotId)).ToArray();
            if(occurrences.Length!=link.ShotIds.Count || occurrences.Any(s=>!s.References.Any(r=>r.ReferenceId==link.ReferenceId && r.LibraryId is null && r.ExternalReference==link.OriginalPath)) ||
                HasConflict(document,catalog.Shots,link.ReferenceId))throw new InvalidDataException("镜头外链收据与镜头来源不符。");
        }
    }

'''+needle);p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/PlanningProjectPackage.cs';s=p.read_text().replace('var data=new Dictionary<string,byte[]>(StringComparer.OrdinalIgnoreCase);','PlanningReferenceLinks.ValidateCatalog(d,shots);\n        var data=new Dictionary<string,byte[]>(StringComparer.OrdinalIgnoreCase);');s=s.replace('var d=PlanningProjectCopyStorage.Bind(state.Document!,Path.GetTempPath());var wanted=', 'var d=PlanningProjectCopyStorage.Bind(state.Document!,Path.GetTempPath());PlanningReferenceLinks.ValidateCatalog(d,shots);var wanted=');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/PlanningReadableSummary.cs';s=p.read_text();# summary lookup joins by exact source; don't misclaim conflicting ID receipt
s=s.replace('''        void AddReference(int section,ProjectShotReference r,string role,params (string Key,object? Value)[] extra)
        {
''','''        void AddReference(int section,ProjectShotReference r,string role,params (string Key,object? Value)[] extra)
        {
            var conflict=PlanningReferenceLinks.HasConflict(d,input.Shots,r.ReferenceId);
            var shot=input.Shots.FirstOrDefault(s=>s.References.Any(x=>x.ReferenceId==r.ReferenceId));
            var linked=conflict?null:d.References.FirstOrDefault(link=>PlanningReferenceLinks.SameSource(link.Source,r)) ?? (shot is null?null:PlanningReferenceLinks.ForShot(d,shot,r));
''');s=s.replace('d.References.FirstOrDefault(link=>link.Source.ReferenceId==r.ReferenceId)?.ProjectCopy','linked?.ProjectCopy').replace('d.References.FirstOrDefault(link=>link.Source.ReferenceId==r.ReferenceId)?.ReconnectedFile','linked?.ReconnectedFile');s=s.replace('("引用状态",linked?.ProjectCopy', '("引用状态",conflict?"同ID来源冲突；未解析":linked?.ProjectCopy');p.write_text(s,encoding='utf8')
