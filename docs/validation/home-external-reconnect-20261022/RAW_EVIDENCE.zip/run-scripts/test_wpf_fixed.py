import pathlib,subprocess,os,time,json
root=pathlib.Path.cwd();d=root/'Guangjing-Home-Reconnect-Delivery-20261022';out=d/'development-tests/wpf-fixed';out.mkdir();r=root/'guangjing-home-reconnect-20261022';env=os.environ.copy();env.update(KITAO_TEST_RESOURCE_ROOT=str(r),KITAO_RECONNECT_EVIDENCE=str(d/'reconnect-synthetic-fixed'),KITAO_CURRENT_IMPORT_EVIDENCE=str(d/'current-import-synthetic-fixed'),PIXEL_TART_ISOLATED_RUNTIME='1',PIXEL_TART_ISOLATED_RUNTIME_ROOT=str(out/'runtime'));cmd=[r'C:\Program Files\dotnet\dotnet.exe','vstest',str(r/'tests/RAWSelectionAssistant.WpfTests/bin/x64/Release/net10.0-windows10.0.19041.0/RAWSelectionAssistant.WpfTests.dll'),'/TestCaseFilter:FullyQualifiedName~PlanningExternalReconnectWpfTests|FullyQualifiedName~PlanningCurrentRootImportWpfTests','/Logger:trx;LogFileName=results.trx','/ResultsDirectory:'+str(out)]
with (out/'stdout.log').open('wb') as f:
 p=subprocess.Popen(cmd,stdout=f,stderr=f,env=env,cwd=r,creationflags=subprocess.CREATE_NO_WINDOW)
 try:code=p.wait(timeout=100)
 except subprocess.TimeoutExpired: subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],stdout=f,stderr=f);code=-999
print(code,flush=True)
