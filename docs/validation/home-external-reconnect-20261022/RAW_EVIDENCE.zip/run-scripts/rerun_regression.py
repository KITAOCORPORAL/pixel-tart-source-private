from pathlib import Path
p=Path.cwd()/'Guangjing-Home-Reconnect-Audit-20261022/regression_dev.py';s=p.read_text().replace(",'/BlameHangTimeout:120s'",'').replace("out.mkdir();cmd=", "out.mkdir(exist_ok=True);cmd=");s=s[s.index('import pathlib'):];p2=p.with_name('regression_actual.py');s=s.replace("'regression-'+label","'regression-actual-'+label");p2.write_text(s,encoding='utf8')
