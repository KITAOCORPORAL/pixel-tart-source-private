from pathlib import Path
r=Path.cwd()/'guangjing-home-reconnect-20261022';p=r/'src/RAWSelectionAssistant.Core/Services/Projects/PlanningReadableSummary.cs';s=p.read_text();s=s.replace('attachment.ProjectCopy is {} copy ? PlanningProjectCopyStorage.Status(copy) : ReferenceState(attachment.Path)','attachment.ProjectCopy is {} copy ? PlanningProjectCopyStorage.Status(copy) : ReconnectedState(attachment.ReconnectedFile,attachment.Id,"attachment",attachment.Path) ?? (d.Extensions?.ContainsKey("PackageImportExcludedDependencies")==true ? "项目包未包含；待手动重连" : ReferenceState(attachment.Path))');s=s.replace('r.LibraryId is not null?"库引用未解析；保留身份，未复制原文件":ReferenceState(r.ExternalReference)','r.LibraryId is not null?"库引用未解析；保留身份，未复制原文件":ReconnectedState(d.References.FirstOrDefault(link=>link.Source.ReferenceId==r.ReferenceId)?.ReconnectedFile,r.ReferenceId,"reference",r.ExternalReference) ?? (d.Extensions?.ContainsKey("PackageImportExcludedDependencies")==true ? "项目包未包含；待手动重连" : ReferenceState(r.ExternalReference))');needle='    public static int PlacementSection';s=s.replace(needle,'''    private static string? ReconnectedState(PlanningExternalFile? file,Guid id,string kind,string? original)
    {
        if(file is null || original is null)return null;
        try{PlanningExternalFile.ResolveVerified(file,id,kind,original);return "手动重连外链 · 类型/大小/SHA-256已核对；未嵌入";}
        catch(Exception e)when(e is IOException or InvalidDataException or UnauthorizedAccessException or ArgumentException or NotSupportedException){return "重连外链不可用："+e.Message;}
    }
'''+needle);p.write_text(s,encoding='utf8')
# Reject misleading content signatures for images independent of extension; Office ZIP checked for its expected main part.
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/PlanningExternalReconnect.cs';s=p.read_text();s=s.replace('        stream.Position = 0; var hash', '''        if (kind=="attachment" && ext is ".docx" or ".xlsx" or ".pptx")
        {
            stream.Position=0;
            using var zip=new System.IO.Compression.ZipArchive(stream,System.IO.Compression.ZipArchiveMode.Read,true);
            var expected=ext==".docx"?"word/document.xml":ext==".xlsx"?"xl/workbook.xml":"ppt/presentation.xml";
            if(zip.GetEntry("[Content_Types].xml") is null || zip.GetEntry(expected) is null)throw new InvalidDataException("Office附件包结构与扩展名不符。");
        }
        stream.Position = 0; var hash''');p.write_text(s,encoding='utf8')
