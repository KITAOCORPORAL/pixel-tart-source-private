import pathlib,json
root=pathlib.Path.cwd();d=root/'Guangjing-Home-Reconnect-Delivery-20261022';files=list((d/'final/desktop-runtime/Data/ProjectPlanning').glob('*.planning.json'))
for f in files:
 j=json.loads(f.read_text(encoding='utf-8-sig'));print(f.name);print(json.dumps(j.get('Document',{}).get('References'),ensure_ascii=False,indent=2)[:3500])
