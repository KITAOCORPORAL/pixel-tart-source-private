from pathlib import Path
r=Path.cwd()/'guangjing-home-reconnect-20261022'
p=r/'src/RAWSelectionAssistant/Views/PlanningCenterView.ExternalReconnect.cs';s=p.read_text();s=s.replace('        var window=new Window', '''        if(_externalReconnectWindow is {IsVisible:true} previous)
        {previous.Content=new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=panel};return;}
        var window=new Window''');a=s.index('        // One modeless');b=s.index('        _externalReconnectWindow=window;',a);s=s[:a]+s[b:];p.write_text(s,encoding='utf8')
# Reconnect is available directly alongside ordinary attachments as well as the dependency audit window.
p=r/'src/RAWSelectionAssistant/Views/PlanningCenterView.xaml.cs';s=p.read_text().replace('            actions.Children.Add(Action("打开所在位置", () => _vm.RevealAttachment(file)));','''            actions.Children.Add(Action("打开所在位置", () => _vm.RevealAttachment(file)));
            if(file.ProjectCopy is null)
            {
                var dependency=_vm.ExternalDependencies.SingleOrDefault(x=>x.Id==file.Id&&x.Kind=="attachment");
                if(dependency is not null){actions.Children.Add(AsyncAction("定位新文件（继续外链）",()=>_vm.LocateExternalAsync(dependency,false)));actions.Children.Add(AsyncAction("导入项目副本",()=>_vm.LocateExternalAsync(dependency,true)));}
            }''');p.write_text(s,encoding='utf8')
# The dependency dialog must be tested in a real WPF owner, not just read back command metadata.
p=r/'tests/RAWSelectionAssistant.WpfTests/PlanningExternalReconnectWpfTests.cs';s=p.read_text();needle='        // A fresh import';s=s.replace(needle,'''        var owner=new System.Windows.Window{Content=view,Width=1100,Height=800};view.DataContext=restarted;owner.Show();
        typeof(RAWSelectionAssistant.Views.PlanningCenterView).GetMethod("ShowExternalReconnect",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic)!.Invoke(view,null);
        var child=owner.OwnedWindows.Cast<System.Windows.Window>().Single();Assert.AreEqual("缺失外链与手动重连",child.Title);child.Close();owner.Close();view.DataContext=null;
'''+needle);p.write_text(s,encoding='utf8')
