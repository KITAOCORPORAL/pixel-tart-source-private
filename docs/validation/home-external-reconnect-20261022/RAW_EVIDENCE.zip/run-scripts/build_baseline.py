import pathlib,subprocess,os,json,time,hashlib,sys
root=pathlib.Path.cwd(); r=root/'guangjing-home-reconnect-20261022'; d=root/'Guangjing-Home-Reconnect-Delivery-20261022'; d.mkdir(exist_ok=False)
(d/'baseline').mkdir();os.chdir(r); dotnet=r'C:\Program Files\dotnet\dotnet.exe';sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
(d/'context.json').write_text(json.dumps(dict(source=str(r),delivery=str(d),baseSha=sha,branch='home/planning-external-reconnect-20261022',date='2026-10-22',timezone='Europe/Berlin',diagnosticOnly=True),indent=2),encoding='utf8')
props=['-p:WholeAppDiagnosticBuild=true','-p:PhotographerTrialBuild=false','-p:SourceRevisionId='+sha,'-p:IncludeSourceRevisionInInformationalVersion=true']
plans=[('publish',['publish','src/RAWSelectionAssistant/RAWSelectionAssistant.csproj','-c','Release','-r','win-x64','--self-contained','true','-o',str(d/'baseline/app')]),('core',['build','tests/RAWSelectionAssistant.Tests/RAWSelectionAssistant.Tests.csproj','-c','Release']),('wpf',['build','tests/RAWSelectionAssistant.WpfTests/RAWSelectionAssistant.WpfTests.csproj','-c','Release','-p:Platform=x64']),('modules',['build','tests/PixelTart.ModularHarness.Tests/PixelTart.ModularHarness.Tests.csproj','-c','Release']),('probe',['build','tools/CompanySwitchProbe/CompanySwitchProbe.csproj','-c','Release'])]
for name,args in plans:
 cmd=[dotnet]+args+props+['--disable-build-servers','-m:1','-nr:false']; start=time.time()
 with (d/'baseline'/f'build-{name}.log').open('wb') as log:
  p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW);code=p.wait()
 (d/'baseline'/f'build-{name}.json').write_text(json.dumps(dict(command=cmd,pid=p.pid,startEpoch=start,endEpoch=time.time(),exitCode=code,sourceSha=sha),indent=2),encoding='utf8');print(name,code,flush=True)
 if code:sys.exit(code)
for label,assembly in [('core',r/'tests/RAWSelectionAssistant.Tests/bin/Release/net10.0/RAWSelectionAssistant.Tests.dll'),('wpf',r/'tests/RAWSelectionAssistant.WpfTests/bin/x64/Release/net10.0-windows10.0.19041.0/RAWSelectionAssistant.WpfTests.dll'),('modules',r/'tests/PixelTart.ModularHarness.Tests/bin/Release/net10.0-windows10.0.19041.0/PixelTart.ModularHarness.Tests.dll'),('probe',r/'tools/CompanySwitchProbe/bin/Release/net10.0/CompanySwitchProbe.dll')]:
 import shutil
 bindings=[]
 if not assembly.exists(): print('MISSING',str(assembly),flush=True);continue
 for f in (d/'baseline/app').glob('*.dll'):
  target=assembly.parent/f.name
  if target.exists():
   shutil.copy2(f,target);h=hashlib.sha256(f.read_bytes()).hexdigest(); assert hashlib.sha256(target.read_bytes()).hexdigest()==h; bindings.append(dict(published=str(f),host=str(target),sha256=h))
 (d/'baseline'/f'bindings-{label}.json').write_text(json.dumps(dict(assembly=str(assembly),sha256=hashlib.sha256(assembly.read_bytes()).hexdigest(),bindings=bindings),indent=2),encoding='utf8')
print('BASELINE READY',flush=True)
