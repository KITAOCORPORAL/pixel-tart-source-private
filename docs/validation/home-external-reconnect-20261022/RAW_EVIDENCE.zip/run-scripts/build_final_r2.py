import pathlib,subprocess,os,json,time,hashlib,shutil,sys
root=pathlib.Path.cwd();r=root/'guangjing-home-reconnect-20261022';d=root/'Guangjing-Home-Reconnect-Delivery-20261022';out=d/'final-r2';out.mkdir();dotnet=r'C:\Program Files\dotnet\dotnet.exe';sha=subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD'],text=True).strip();props=['-p:WholeAppDiagnosticBuild=true','-p:PhotographerTrialBuild=false','-p:SourceRevisionId='+sha,'-p:IncludeSourceRevisionInInformationalVersion=true'];plans=[('publish',['publish','src/RAWSelectionAssistant/RAWSelectionAssistant.csproj','-c','Release','-r','win-x64','--self-contained','true','-o',str(out/'app')]),('core',['build','tests/RAWSelectionAssistant.Tests/RAWSelectionAssistant.Tests.csproj','-c','Release']),('wpf',['build','tests/RAWSelectionAssistant.WpfTests/RAWSelectionAssistant.WpfTests.csproj','-c','Release','-p:Platform=x64']),('modules',['build','tests/PixelTart.ModularHarness.Tests/PixelTart.ModularHarness.Tests.csproj','-c','Release'])]
for label,args in plans:
 cmd=[dotnet]+args+props+['--no-restore','--disable-build-servers','-m:1','-nr:false'];start=time.time()
 with (out/(label+'-build.log')).open('wb') as f:p=subprocess.Popen(cmd,stdout=f,stderr=f,cwd=r,creationflags=subprocess.CREATE_NO_WINDOW);code=p.wait()
 (out/(label+'-build.json')).write_text(json.dumps(dict(sourceSha=sha,command=cmd,pid=p.pid,startEpoch=start,endEpoch=time.time(),exitCode=code),indent=2));print(label,code,flush=True)
 if code:sys.exit(code)
assemblies={'core':r/'tests/RAWSelectionAssistant.Tests/bin/Release/net10.0/RAWSelectionAssistant.Tests.dll','wpf':r/'tests/RAWSelectionAssistant.WpfTests/bin/x64/Release/net10.0-windows10.0.19041.0/RAWSelectionAssistant.WpfTests.dll','modules':r/'tests/PixelTart.ModularHarness.Tests/bin/Release/net10.0-windows10.0.19041.0/PixelTart.ModularHarness.Tests.dll'}
h=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest();bindings=[]
for label,assembly in assemblies.items():
 if not assembly.exists():raise FileNotFoundError(assembly)
 for f in (out/'app').glob('*.dll'):
  target=assembly.parent/f.name
  if target.exists():shutil.copy2(f,target);assert h(target)==h(f);bindings.append(dict(host=label,published=str(f),loaded=str(target),sha256=h(f)))
(out/'bindings.json').write_text(json.dumps(dict(sourceSha=sha,bindings=bindings,tests=[dict(label=l,path=str(a),sha256=h(a)) for l,a in assemblies.items()]),indent=2))
env=os.environ.copy();env.update(KITAO_TEST_RESOURCE_ROOT=str(r),KITAO_RECONNECT_EVIDENCE=str(d/'final-r2-synthetic'),KITAO_CURRENT_IMPORT_EVIDENCE=str(d/'final-r2-current-synthetic'),PIXEL_TART_ISOLATED_RUNTIME='1',PIXEL_TART_ISOLATED_RUNTIME_ROOT=str(out/'test-runtime'))
for label,filter in [('core','FullyQualifiedName~Planning'),('wpf','FullyQualifiedName~Planning|FullyQualifiedName~Docx|FullyQualifiedName~RichFlow'),('modules',None)]:
 folder=out/('tests-'+label);folder.mkdir();cmd=[dotnet,'vstest',str(assemblies[label]),'/Logger:trx;LogFileName=results.trx','/ResultsDirectory:'+str(folder)]+(['/TestCaseFilter:'+filter] if filter else []);start=time.time()
 with (folder/'stdout.log').open('wb') as f:p=subprocess.Popen(cmd,stdout=f,stderr=f,cwd=r,env=env,creationflags=subprocess.CREATE_NO_WINDOW)
 try:code=p.wait(timeout=300)
 except subprocess.TimeoutExpired:subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],creationflags=subprocess.CREATE_NO_WINDOW);code=-999
 (folder/'process.json').write_text(json.dumps(dict(command=cmd,pid=p.pid,startEpoch=start,endEpoch=time.time(),exitCode=code,sourceSha=sha),indent=2));print('test-'+label,code,flush=True)
