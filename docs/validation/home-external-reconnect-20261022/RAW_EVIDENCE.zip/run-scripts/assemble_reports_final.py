import pathlib,json,hashlib,zipfile,subprocess,shutil,xml.etree.ElementTree as ET,collections,datetime
root=pathlib.Path.cwd();r=root/'guangjing-home-reconnect-20261022';d=root/'Guangjing-Home-Reconnect-Delivery-20261022';a=root/'Guangjing-Home-Reconnect-Audit-20261022';reports=d/'reports';reports.mkdir(exist_ok=True)
h=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf8')
sha=subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD'],text=True).strip()
# Independent source and branch identity, no working tree mutations.
source=dict(sourceSha=sha,baseSha='2d8db4d9931f58af43025004cb794dc35affb8b3',branch=subprocess.check_output(['git','-C',str(r),'branch','--show-current'],text=True).strip(),status=subprocess.check_output(['git','-C',str(r),'status','--porcelain'],text=True),companyRemote=subprocess.check_output(['git','-C',str(r),'ls-remote','--heads','origin','feature/planning-current-root-import-20261022'],text=True),homeOldHead=subprocess.check_output(['git','-C',str(root/'guangjing-whole-app-home-20261020'),'rev-parse','HEAD'],text=True).strip(),sdk='10.0.401',runtime='10.0.12',hostTimezone='China Standard Time',reportTimezone='Europe/Berlin',date='2026-10-22',diagnosticOnly=True)
dump(reports/'SOURCE_IDENTITY.json',source)
# Every published file, PE/product identities are supplemented by live loaded-component snapshots.
files=[dict(path=str(p.relative_to(d/'final-r4/app')),bytes=p.stat().st_size,sha256=h(p)) for p in sorted((d/'final-r4/app').rglob('*')) if p.is_file()];dump(reports/'APP_FILES.json',files)
hosts=[]
for label,folder in [('core',r/'tests/RAWSelectionAssistant.Tests/bin/Release/net10.0'),('wpf',r/'tests/RAWSelectionAssistant.WpfTests/bin/x64/Release/net10.0-windows10.0.19041.0'),('modules',r/'tests/PixelTart.ModularHarness.Tests/bin/Release/net10.0-windows10.0.19041.0'),('probe',r/'tools/CompanySwitchProbe/bin/Release/net10.0')]:
 for p in folder.glob('*'):
  if p.is_file() and p.suffix in ['.dll','.exe','.json']:hosts.append(dict(host=label,path=str(p),bytes=p.stat().st_size,sha256=h(p)))
dump(reports/'TEST_HOST_COMPONENTS.json',hosts)
# Report every actual TRX outcome including earlier failed attempts, never overwrite.
results=[]
for p in d.rglob('*.trx'):
 try:
  xml=ET.parse(p).getroot();ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};definitions={x.get('id'):x.find('t:TestMethod',ns) for x in xml.findall('.//t:TestDefinitions/t:UnitTest',ns)}
  for v in xml.findall('.//t:Results/t:UnitTestResult',ns):
   method=definitions.get(v.get('testId'));message=v.find('.//t:Message',ns);results.append(dict(trx=p.relative_to(d).as_posix(),test=v.get('testName'),outcome=v.get('outcome'),duration=v.get('duration'),testId=v.get('testId'),fqcn=(method.get('className','')+'.'+method.get('name','')) if method is not None else '',error=message.text if message is not None else None))
 except Exception as e:results.append(dict(trx=p.relative_to(d).as_posix(),parseError=str(e)))
dump(reports/'ALL_TEST_RESULTS.json',results);dump(reports/'FINAL_TEST_SUMMARY.json',{suite:dict(collections.Counter(x['outcome'] for x in results if x['trx'].startswith('final-r4/tests-'+suite+'/'))) for suite in ['core','wpf','modules']});dump(reports/'ALL_NONPASS.json',[x for x in results if x.get('outcome')!='Passed'])
# Audit before/after for every original working tree and every retained dirty file.
old=json.loads((a/'all-worktrees-before.json').read_text(encoding='utf-8-sig'));preservation=[]
for x in old:
 p=pathlib.Path(x['path']);head=subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip();branch=subprocess.check_output(['git','-C',str(p),'branch','--show-current'],text=True).strip();status=subprocess.check_output(['git','-C',str(p),'status','--porcelain=v1','--untracked-files=all'],text=True).splitlines();preservation.append(dict(path=str(p),head=head,branch=branch,headUnchanged=head==x['head'],branchUnchanged=branch==x['branch'],statusUnchanged=status==x['status'],status=status))
assert all(x['headUnchanged'] and x['branchUnchanged'] and x['statusUnchanged'] for x in preservation)
dump(reports/'WORKTREE_PRESERVATION.json',preservation)
dirty=json.loads((a/'dirty-files-content-baseline.json').read_text());
for x in dirty:
 f=pathlib.Path(x['tree'])/x['file'];x['afterSha256']=h(f) if f.is_file() else None;x['unchanged']=x['afterSha256']==x['sha256']
assert all(x['unchanged'] for x in dirty);dump(reports/'DIRTY_FILE_PRESERVATION.json',dirty)
zips=json.loads((a/'old-zips-before.json').read_text());
for x in zips:x['afterSha256']=h(pathlib.Path(x['path']));x['unchanged']=x['afterSha256']==x['sha256']
assert all(x['unchanged'] for x in zips);dump(reports/'OLD_PACKAGE_PRESERVATION.json',zips)
for p in a.glob('original-*'):shutil.copy2(p,reports/p.name)
for name in ['remote-head-independent.txt','home-head.txt','registered-worktrees-before.txt','branches-before.txt','all-worktrees-before.json','original-failure-locations.json']:shutil.copy2(a/name,reports/name)
for name in ['bindings.json','desktop-start.json','desktop-restart.json','desktop-file-readback-before-restart.json','desktop-loaded-components.json','desktop-docx-readback.json']:
 p=d/'final-r4'/name
 if p.exists():shutil.copy2(p,reports/('FINAL_'+name))
for name in ['desktop-start.json','desktop-restart.json','desktop-loaded-components.json','desktop-docx-readback.json']:
 p=d/'baseline'/name
 if p.exists():shutil.copy2(p,reports/('BASELINE_'+name))
shutil.copy2(d/'system-before.json',reports/'SYSTEM_BEFORE.json');shutil.copy2(d/'dotnet-info.txt',reports/'DOTNET_INFO.txt')
# Raw screenshots are local test app only; no screenshot of unrelated apps is packaged.
(reports/'desktop').mkdir(exist_ok=True)
for p in (d/'desktop-evidence').glob('*'):shutil.copy2(p,reports/'desktop'/p.name)
dump(reports/'SAMPLE_IDENTITY.json',[dict(path=str(p),bytes=p.stat().st_size,sha256=h(p),syntheticOnly=True) for p in sorted((d/'samples').glob('*')) if p.is_file()])
print('reports',str(reports),'old trees',len(preservation),'preserved dirty',len(dirty),'old zip',len(zips),'tests',len(results))
