import pathlib,json,hashlib,subprocess,zipfile,shutil,collections,datetime,xml.etree.ElementTree as ET
root=pathlib.Path.cwd();r=root/'guangjing-home-reconnect-20261022';d=root/'Guangjing-Home-Reconnect-Delivery-20261022';a=root/'Guangjing-Home-Reconnect-Audit-20261022';reports=d/'reports';h=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf8')
# Performance raw and summarized rows; initial baseline and final product are separate source identities.
rows=[]
for group in ['performance','performance-final-r3','performance-final-r4']:
 perf=d/group
 for mode,file in [('warm3',perf/'warm3/results.json'),('fixed-four-load',perf/'concurrent/measurement/results.json')]:
  for item in json.loads(file.read_text()):rows.append(dict(group=group,scenario=mode,**item))
 load=json.loads((perf/'concurrent/load.json').read_text());start,end=load['measurementStartEpoch'],load['measurementEndEpoch'];events=[dict(**e,overlapSeconds=max(0,min(end,e['endEpoch'])-max(start,e['startEpoch']))) for e in load['events']];dump(perf/'overlap-readback.json',dict(startEpoch=start,endEpoch=end,events=events,allFourWorkersOverlap=all(any(e['worker']==w and e['overlapSeconds']>0 for e in events) for w in range(4))))
 for f in perf.rglob('calls-*.csv'):
  assert sum(1 for _ in f.open())==10001
 dump(reports/(group+'-original.json'),json.loads((perf/'measurements/performance.json').read_text()))
dump(reports/'PERFORMANCE_ROUNDS.json',rows)
for name in ['identity.json','ACTUAL_HOST_PROCESSES.json']:
 p=d/'host-identity-only'/name
 if p.exists():shutil.copy2(p,reports/p.name)
# Runtime dependencies independent from successful build's return code.
app=d/'final-r4/app';deps=json.loads((app/'KitaoPhotoSelector.deps.json').read_text());assets=[]
for target in deps['targets'].values():
 for library,info in target.items():
  for kind in ['runtime','native','resources','runtimeTargets']:
   for name,value in info.get(kind,{}).items():
    if name.endswith('/_._') or (kind=='runtimeTargets' and value.get('rid') not in [None,'win-x64','win']):continue
    candidates=[app/name,app/pathlib.PurePosixPath(name).name]
    if kind=='resources':candidates.append(app/value.get('locale','')/pathlib.PurePosixPath(name).name)
    assets.append(dict(library=library,kind=kind,path=name,present=any(p.is_file() for p in candidates)))
assert all(x['present'] for x in assets);dump(reports/'DEPENDENCIES.json',assets)
# Both native desktop success paths and retained first failure.
desktop=dict(baselineSource='2d8db4d9931f58af43025004cb794dc35affb8b3',finalSource='b91858eea2d17ca5c9a72a04132757a8e010ff8e',automation='@oai/sky native Windows only; no browser/CDP/localhost used',accessibility='null; screenshot-backed mouse/key actions',baseline=dict(startPid=12644,restartPid=42548,oldExited=True,importCurrentRoot=True,ordinaryList=True,titleEdited='家用实机编辑保存 20261022',saved=True,restarted=True,summary='samples/baseline-desktop-15-summary.docx'),firstReconnectAttempt=dict(source='9d50bb483abadd7b86e611735e02155ff9ccd453',pid=14856,status='FAIL retained: native confirmation obscured by owned modeless window; no receipt persisted',termination='CloseMainWindow false; only this test process stopped after evidence retained'),final=dict(startPid=23740,restartPid=8160,oldExitedNormally=True,project='5da43bec-3666-4f2a-9920-ac9cdde5aca9',reference='5ee0a981-299a-4ba1-ab4d-33d720db18f5',attachment='b2a9e85f-5cfb-4406-a10d-59203f5c1fa6',imported=True,missingReasonsShown=True,explicitReferenceExternal=True,explicitAttachmentOwnedCopy=True,typeSizeShaConfirmation=True,save=True,normalExit=True,newProcessRestart=True,ordinaryListReopen=True,referencePreviewAfterRestart=True,summary='samples/r3-desktop-reconnected-15-summary.docx',summaryFifteenHeadings=True,bothHashesInSummary=True),notExecuted=['Native cancel/error/conflict matrix (Core guards tested instead)','Word/WPS document-open visual inspection','Full app acceptance/setup install/uninstall/real customer data'])
dump(reports/'DESKTOP_RESULTS.json',desktop)
(reports/'DESKTOP_STEPS.md').write_text('''# 实机交互逐步记录

工具：本机 @oai/sky；所有输入先观察窗口截图，再单步鼠标/键盘输入并重新观察。无 Browser、CDP、localhost 或自动资源管理器。Accessibility 返回 null，采用截图坐标。

## 公司基线
1. 从 2d8db4d9 源码完整 publish，PID 12644 实际启动，标题明确不能发行。退出教程、进入策划中心。
2. 初始普通窗侧列表被折叠；放大后出现“导入项目包到当前应用”。输入合成包路径，核对隔离 DB/策划/镜头目的地，确认后出现“已加入普通策划项目列表”。
3. 从普通列表点击项目，右侧标题输入“家用实机编辑保存 20261022”，点击保存。窗口顶端保存状态更新。
4. Alt+F4 正常退出，查询 PID 确认消失。同根新 PID 42548 启动，退出教程、进入策划、普通列表项目卡显示保存标题，再点击重开。
5. 更多→导出15区汇总DOCX，指定 samples/baseline-desktop-15-summary.docx。出现导出成功，文件独立读回含标题标记。

## 首轮失败与修复
9d50bb48 / PID 14856 原生定位及哈希确认框可见，但被 modeless 子窗遮挡/归属异常。确认后磁盘 ReconnectedFile 仍为空，不计成功。重复观察无有效结果即停止，保留该数据根及截图；CloseMainWindow 返回 false，仅终止本轮自有测试 PID。ca0c497e / b91858ee 修复：定位时隐藏拥有的子窗，主窗原生选择/确认后恢复子窗，预览缓存增加文件 hash。r2 编译缺 using 的失败日志也保留。

## 最终修复版 b91858ee
1. PID 23740，新隔离根 final-r3/desktop-runtime。真实导入同一个外链缺失合成包；窄窗新入口可见，不再依赖放大。
2. 更多→缺失外链与手动重连，逐项显示原 ID/分区/原路径、包未包含原因、两个操作及未支持业务依赖。
3. 参考图点击“定位新文件（继续外链）”，输入 samples/final-replacement.png。确认框显示 PNG、3821 bytes、SHA-256，并明确无法证明与未打包原内容相同。确认后状态“已手动重连”，磁盘收据真实存在，原引用/分区/原路径一致。
4. 普通附件点击“导入项目副本”，输入 samples/final-replacement.txt。确认框显示 .txt、42 bytes、SHA-256。确认后附件从待重连清单消失，文件区显示“项目自有副本·SHA-256已核对”、规范项目内路径和原来源。
5. 参考图区显示合成蓝底橙圆图。点击保存，Alt+F4 正常退出，确认 PID 23740 消失。
6. 同数据根新 PID 8160 启动，退出教程，进入策划、放大显示普通列表，点击“外链重连合成项目”；参考图仍显示，非 VM 重建冒称进程重启。
7. 更多→导出15区汇总DOCX→samples/r3-desktop-reconnected-15-summary.docx。窗口显示导出成功；独立解包验证恰好15个 Heading1、参考外链 hash 与自有附件 hash 均存在。正常退出最终程序。

## 简短手动复验
运行交付包 Launch-Diagnostic.ps1（不扫描私人根）→退出教程→策划→导入 samples/final-external-reconnect-v1.ptplan→更多/缺失外链与手动重连→逐项选 samples 中替代文件并明确外链/副本→保存→完全退出→同启动器重开→普通列表打开→更多/导出15区汇总。
新数据根首次不存在；同 ID 再导入须拒绝，勿手动删数据逃避冲突。Word/WPS 外观验收另行人工执行。
''',encoding='utf8')
# Explain scope limitations rather than manufacture exact company sample provenance.
limitations=[
 '诊断版不能发行；未执行全软件套件、Setup安装升级卸载、Word/WPS实机排版验收。',
 '公司原始合成ptplan二进制不在fetch的Git树/原始证据ZIP内。基线使用公司提交的生成测试在本机2d8db4d9源码重新生成的同格式v1合成包，非公司6757字节/f9747e16样例的逐字节副本。原测试先在无关路径字符串断言失败，包已经导出；该失败完整保留，之后断言改为确切DB路径。',
 '最终Core策划回归51通过/2失败；两项均在创建合成符号链接时Win32错误1314（客户端没有所需特权）。未更改系统策略，未把这两项记PASS。最终WPF87通过/2条件未执行；模块14通过。',
 '原家用32139.0909ms历史失败保留，本轮未超30秒，未触发WPR深挖；未唯一解释旧失败，不把wall-CPU/otherOps解释成磁盘等待。固定四负载与原完整四片+Core不是同一重演。',
 '性能原始进程记录是启动的vstest包装PID；psutil不可用，未采集性能testhost PID。独立identity-only有实际testhost PID/模块哈希，不冒作性能同进程等待证据。',
 '目前可重连策划文档中的外部参考图与普通附件；仅镜头记录而未进入文档参考集合的外链暂未提供单独操作。素材库原件、档期、账本、画布/色彩工作区继续只列未包含依赖，不自动重连。',
 '类型是有限白名单+文件头/Office包结构校验，不是防病毒或完整格式验证。参考图支持PNG/JPEG/GIF/BMP/TIFF；摘要只安全嵌入自有PNG，外链只记录状态/新路径/hash；普通附件1字节至64MiB。',
 '原文件没有打包内容/hash时，不宣称所选文件等于原内容。继续外链保存选中文件hash，之后文件变化即不可用；需用户重新选择确认。参考替代类型与原扩展名不一致时，项目副本规范路径仍采用原扩展名；建议同类型替代，该格式兼容性仍需后续收紧。',
 '17旧工作树HEAD/branch/status及211现存未提交文件hash、104旧ZIP不变。git ignored枚举有Windows长路径警告，忽略产物清单覆盖不完整；未假称所有忽略目录每个文件都已hash。',
 '报告时区Europe/Berlin；执行主机实际China Standard Time，原始时间保持原样，性能epoch/UTC可独立换算。'
];dump(reports/'LIMITATIONS.json',limitations)
# Record canonical user-facing timezone while retaining raw original host values.
p=reports/'SOURCE_IDENTITY.json';j=json.loads(p.read_text());j['reportTimezone']='Europe/Berlin';dump(p,j)
# Full raw evidence ZIP: no executables, DLLs, mutable DB or original user data.
raw=d/'Home-Reconnect-Raw-Evidence-20261022.zip';manifest=[]
with zipfile.ZipFile(raw,'w',zipfile.ZIP_DEFLATED) as z:
 for base in ['baseline','development-tests','regression-actual-core-new','regression-actual-wpf-affected','final','final-r2','final-r3','final-r4','performance','performance-final-r3','performance-final-r4','host-identity-only']:
  for f in sorted((d/base).rglob('*')):
   if not f.is_file() or f.suffix.lower() not in ['.log','.trx','.json','.csv','.txt']:continue
   rel=f.relative_to(d)
   if any(part in ['app','runtime','test-runtime','desktop-runtime','shared-fixture','temp'] for part in rel.parts):continue
   data=f.read_bytes();name=rel.as_posix();z.writestr(name,data);manifest.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
 for f in sorted(a.glob('*.py')):
  data=f.read_bytes();name='run-scripts/'+f.name;z.writestr(name,data);manifest.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
with zipfile.ZipFile(raw) as z:
 for row in manifest:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
dump(reports/'RAW_EVIDENCE_MANIFEST.json',manifest);dump(reports/'RAW_ZIP_IDENTITY.json',dict(path=str(raw),bytes=raw.stat().st_size,sha256=h(raw),files=len(manifest),readback=True));print('raw',raw.stat().st_size,'assets',len(assets),'rounds',len(rows))


