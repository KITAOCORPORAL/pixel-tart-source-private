from pathlib import Path
r=Path.cwd()/'guangjing-home-reconnect-20261022'
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/PlanningExternalReconnect.cs';s=p.read_text().replace('await stream.ReadExactlyAsync(header, token);','await stream.ReadExactlyAsync(header, token).ConfigureAwait(false);').replace('await SHA256.HashDataAsync(stream, token)', 'await SHA256.HashDataAsync(stream, token).ConfigureAwait(false)');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/PlanningProjectPackage.cs';s=p.read_text().replace('planning.SaveAsync(checkedPackage.State,token)', 'planning.SaveAsync(checkedPackage.State with{Document=RequireLocalReconnect(checkedPackage.State.Document!)},token)');p.write_text(s,encoding='utf8')
