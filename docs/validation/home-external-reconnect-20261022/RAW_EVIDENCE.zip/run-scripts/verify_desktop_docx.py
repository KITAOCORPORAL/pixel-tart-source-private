import pathlib,json,zipfile,hashlib,xml.etree.ElementTree as ET
root=pathlib.Path.cwd();d=root/'Guangjing-Home-Reconnect-Delivery-20261022';p=d/'samples/r3-desktop-reconnected-15-summary.docx';ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
with zipfile.ZipFile(p) as z:
 xml=ET.fromstring(z.read('word/document.xml'));text=''.join(xml.itertext());headings=[]
 for para in xml.findall('.//w:p',ns):
  value=''.join(para.itertext());style=para.find('./w:pPr/w:pStyle',ns)
  if style is not None:headings.append(dict(style=style.get('{'+ns['w']+'}val'),text=value))
 sections=['项目概览','文字','镜头清单与分镜','参考图','情绪板','灯位图','服化道与道具','设备','人员','场地','档期','当天时间表','预算','文件','文档内容'];print(headings)
 result=dict(path=str(p),sha256=hashlib.file_digest(p.open('rb'),'sha256').hexdigest(),allFifteenPresent=all(s in text for s in sections),referenceHashPresent='7DED6D5724784A1D7DA2E7DEC1605BBB31FE71FBD96F7EDEF9CB8169A88FB26B' in text,attachmentHashPresent='D7198B1C531EFA6843A59C1641CA99708D233388C95515D44A46B5F29852BE0A' in text,headings=headings)
 assert result['allFifteenPresent'] and result['referenceHashPresent'] and result['attachmentHashPresent'];(d/'final-r3/desktop-docx-readback.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print('verified 15 sections and both hashes')
