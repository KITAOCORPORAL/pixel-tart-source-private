import pathlib,json,zipfile
r=pathlib.Path.cwd()/'guangjing-home-reconnect-20261022';d=r.parent/'Guangjing-Home-Reconnect-Delivery-20261022';p=d/'samples/current-root-synthetic-v1.ptplan';print(p.exists())
if p.exists():
 with zipfile.ZipFile(p) as z:print(z.namelist())
for f in ['src/RAWSelectionAssistant/Services/PlanningSummaryDocument.cs','src/RAWSelectionAssistant.Core/Services/Projects/PlanningReadableSummary.cs','src/RAWSelectionAssistant/Views/PlanningCenterView.xaml.cs','src/RAWSelectionAssistant/ViewModels/PlanningCenterViewModel.References.cs']:
 lines=(r/f).read_text(encoding='utf-8-sig').splitlines()
 for i,l in enumerate(lines):
  if ('ProjectCopy' in l or 'OriginalPath' in l or 'More_Click' in l or 'ReferenceState' in l):print(f,i+1,'\n'.join(lines[max(0,i-1):min(len(lines),i+3)]))
