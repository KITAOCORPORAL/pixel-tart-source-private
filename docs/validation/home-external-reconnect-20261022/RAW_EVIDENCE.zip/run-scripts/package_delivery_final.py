import pathlib,json,hashlib,zipfile,shutil,subprocess,datetime
root=pathlib.Path.cwd();r=root/'guangjing-home-reconnect-20261022';d=root/'Guangjing-Home-Reconnect-Delivery-20261022';reports=d/'reports';sha=subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD'],text=True).strip();h=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf8')
# Honest physical-volume linkage: original TEMP path is observed; historical disk serial wasn't recorded.
p=reports/'LIMITATIONS.json';limits=json.loads(p.read_text());limits.append('旧失败原始summary只记录N: TEMP路径，未记录当时物理盘序列/卷GUID。本轮该相同绝对路径映射到本地N: NTFS/磁盘3/Samsung SSD 990 EVO Plus 2TB。未找到证明两日间未重映射盘符的历史卷指纹；不能把仅盘符相同冒称物理盘历史身份已完全闭合。');dump(p,limits)
# One immutable, runnable package. Runtime is outside app and never taken from real default data.
pkg=d/'Guangjing-Home-ExternalReconnect-Diagnostic-R4-win-x64';pkg.mkdir();shutil.copytree(d/'final-r4/app',pkg/'app');shutil.copytree(d/'samples',pkg/'samples');shutil.copytree(reports,pkg/'reports');shutil.copy2(d/'Home-Reconnect-Raw-Evidence-20261022.zip',pkg/'reports/RAW_EVIDENCE.zip')
launcher=r'''# Whole-app diagnostic only. Do not distribute as a release or Setup.
param([string]$DataRoot = (Join-Path $PSScriptRoot "SyntheticUserData"))
$ErrorActionPreference = 'Stop'
$DataRoot = [IO.Path]::GetFullPath($DataRoot)
if (-not [IO.Path]::IsPathFullyQualified($DataRoot)) { throw 'DataRoot must be absolute.' }
$env:PIXEL_TART_ISOLATED_RUNTIME = '1'
$env:PIXEL_TART_ISOLATED_RUNTIME_ROOT = $DataRoot
$env:PIXEL_TART_HUMAN_ACCEPTANCE = '1'
$env:PIXEL_TART_ACCEPTANCE_ROOT = $DataRoot
$env:PIXEL_TART_PRODUCT_SOURCE_SHA = '4f57ca5646b1b6e5f831bdecc8c7847114dfa941'
Write-Host '完整范围诊断预览 / 未完成验证 / 不能发行'
Write-Host ('本次明确隔离数据根：' + $DataRoot)
Start-Process -FilePath (Join-Path $PSScriptRoot 'app/KitaoPhotoSelector.exe') -WorkingDirectory (Join-Path $PSScriptRoot 'app') -WindowStyle Normal
'''
(pkg/'Launch-Diagnostic.ps1').write_text(launcher,encoding='utf-8-sig')
(pkg/'README-不能发行.md').write_text('''# 光镜·家用外链重连完整范围诊断版（不能发行）

产品源码 4f57ca5646b1b6e5f831bdecc8c7847114dfa941；起点 2d8db4d9931f58af43025004cb794dc35affb8b3。win-x64，自包含，WholeAppDiagnosticBuild=true / PhotographerTrialBuild=false。不是Setup，不含真实数据库/用户文件。

用 PowerShell 运行本目录 Launch-Diagnostic.ps1，窗口会明确诊断预览，默认数据只写入本包旁 SyntheticUserData。再次用同启动器打开才能重开同一个合成项目。不要直接双击app EXE后误用默认数据根。

策划→导入项目包到当前应用→samples/final-external-reconnect-v1.ptplan→确认隔离根。更多→缺失外链与手动重连：参考图选samples/final-replacement.png并决定外链或副本；附件选samples/final-replacement.txt。看清类型/大小/hash并确认。保存→完全退出→同启动器重开→普通列表打开→更多/导出15区汇总DOCX。继续外链的替代文件搬家后须再次定位；已有项目副本不能被同ID重连覆盖。

样例全为合成。current-root-synthetic-v1.ptplan由公司提交的生成测试在本机基线重新生成；不是公司原f9747e16二进制的逐字节副本，详见LIMITATIONS。已有导入同ID重复操作会拒绝，不会覆写。Word/WPS排版、全软件验证及Setup仍未执行；Core两项符号链接测试在本机权限下失败，详见reports。旧性能失败未唯一解释，不能发行。
''',encoding='utf8')
# Ensure raw/default databases didn't get accidentally packed.
files=[]
for f in sorted(pkg.rglob('*')):
 if not f.is_file():continue
 rel=f.relative_to(pkg)
 if f.suffix.lower() in ['.db','.sqlite','.sqlite3'] or any(x in rel.parts for x in ['UserData','SyntheticUserData','desktop-runtime']):raise RuntimeError('Mutable data in package')
 files.append(dict(path=rel.as_posix(),bytes=f.stat().st_size,sha256=h(f)))
dump(reports/'DIAGNOSTIC_FILES.json',files)
archive=d/(pkg.name+'.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(pkg/f['path'],pkg.name+'/'+f['path'])
with zipfile.ZipFile(archive) as z:
 for f in files:assert hashlib.sha256(z.read(pkg.name+'/'+f['path'])).hexdigest()==f['sha256']
identity=dict(sourceSha=sha,path=str(archive),bytes=archive.stat().st_size,sha256=h(archive),files=len(files),zipReadback=True,diagnosticOnly=True,isSetup=False,databaseIncluded=False,userDataIncluded=False,buildFlags=dict(WholeAppDiagnosticBuild=True,PhotographerTrialBuild=False,selfContained=True,rid='win-x64'))
dump(reports/'DIAGNOSTIC_IDENTITY.json',identity);print(json.dumps(identity))
