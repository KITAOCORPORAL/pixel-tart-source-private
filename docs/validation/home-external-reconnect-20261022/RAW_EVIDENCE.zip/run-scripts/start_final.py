import pathlib,subprocess,os,json,time,hashlib,shutil
root=pathlib.Path.cwd();d=root/'Guangjing-Home-Reconnect-Delivery-20261022';r=root/'guangjing-home-reconnect-20261022';app=d/'final/app';runtime=d/'final/desktop-runtime';env=os.environ.copy();env.update(PIXEL_TART_ISOLATED_RUNTIME='1',PIXEL_TART_ISOLATED_RUNTIME_ROOT=str(runtime),PIXEL_TART_HUMAN_ACCEPTANCE='1',PIXEL_TART_ACCEPTANCE_ROOT=str(runtime));p=subprocess.Popen([str(app/'KitaoPhotoSelector.exe')],env=env,cwd=app);(d/'final/desktop-start.json').write_text(json.dumps(dict(pid=p.pid,startEpoch=time.time(),runtime=str(runtime),sourceSha='9d50bb483abadd7b86e611735e02155ff9ccd453'),indent=2));print(p.pid)
for f in (d/'final-synthetic').glob('*'):
 if f.is_file():shutil.copy2(f,d/'samples'/('final-'+f.name))
print('samples ready')
