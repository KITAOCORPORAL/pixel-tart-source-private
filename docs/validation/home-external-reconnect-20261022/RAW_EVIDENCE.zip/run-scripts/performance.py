import pathlib,subprocess,os,json,time,hashlib,sys
root=pathlib.Path.cwd();r=root/'guangjing-home-reconnect-20261022';d=root/'Guangjing-Home-Reconnect-Delivery-20261022';perf=d/'performance';perf.mkdir();temp=root/'Guangjing-Home-Scenario11-Temp-20261022';temp.mkdir(exist_ok=False);dotnet=r'C:\Program Files\dotnet\dotnet.exe';app=d/'baseline/app';core=r/'tests/RAWSelectionAssistant.Tests/bin/Release/net10.0/RAWSelectionAssistant.Tests.dll';wpf=r/'tests/RAWSelectionAssistant.WpfTests/bin/x64/Release/net10.0-windows10.0.19041.0/RAWSelectionAssistant.WpfTests.dll';probe=r/'tools/CompanySwitchProbe/bin/Release/net10.0/CompanySwitchProbe.dll';sha=subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD'],text=True).strip()
h=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
assert h(app/'RAWSelectionAssistant.Core.dll')==h(core.parent/'RAWSelectionAssistant.Core.dll')==h(probe.parent/'RAWSelectionAssistant.Core.dll')
contract='tests/RAWSelectionAssistant.Tests/AssetLibraryP35AcceptanceTests.cs'
a=subprocess.check_output(['git','-C',str(r),'rev-parse','0e5c3ea7:'+contract],text=True).strip();b=subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD:'+contract],text=True).strip();assert a==b
(perf/'contract.json').write_text(json.dumps(dict(sourceSha=sha,testBlob=a,originalTestBlob=a,sameSourceAs0e5c=False,reason='37 planning source/test files differ; current company HEAD built, performance test exact blob unchanged',temp=str(temp),originalTemporaryDirectory=r'N:\pixart\Guangjing-Home-Planning3-20261020-225855\FINAL_CORE\run-20261020-233512-51dad32f\000\temp',coreSha256=h(app/'RAWSelectionAssistant.Core.dll'),switches=10000,thresholdMs=30000,metadataOutsideTimer=True),indent=2),encoding='utf8')
env=os.environ.copy();env.update(TEMP=str(temp),TMP=str(temp),DOTNET_ROOT=str(pathlib.Path(dotnet).parent),PIXEL_TART_ISOLATED_RUNTIME='1',PIXEL_TART_ISOLATED_RUNTIME_ROOT=str(perf/'runtime'),PIXEL_TART_HUMAN_ACCEPTANCE='0',PIXEL_TART_ACCEPTANCE_ROOT=str(perf/'runtime'),PIXEL_TART_P35_ACCEPTANCE_ROOT=str(perf/'measurements'),KITAO_TEST_RESOURCE_ROOT=str(r),KITAO_PRODUCT_SOURCE_SHA=sha,PIXEL_TART_PRODUCT_SOURCE_SHA=sha)
def run(label,cmd,timeout=240):
 folder=perf/label;folder.mkdir();start=time.time()
 with (folder/'stdout.log').open('wb') as out,(folder/'stderr.log').open('wb') as err:
  p=subprocess.Popen(cmd,stdout=out,stderr=err,env=env,cwd=r,creationflags=subprocess.CREATE_NO_WINDOW)
  try:code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired: p.kill();code=p.wait()
 (folder/'process.json').write_text(json.dumps(dict(command=cmd,pid=p.pid,startEpoch=start,endEpoch=time.time(),exitCode=code,sourceSha=sha),indent=2),encoding='utf8');print(label,code,flush=True);return code
run('original-single',[dotnet,'vstest',str(core),'/TestCaseFilter:FullyQualifiedName=RAWSelectionAssistant.Tests.AssetLibraryP35AcceptanceTests.Scenario11_TenKSwitchAndHundredKMetadataPreview','/Logger:trx;LogFileName=scenario11.trx','/ResultsDirectory:'+str(perf/'original-single')])
fixture=perf/'shared-fixture'
run('warmup-three',[dotnet,str(probe),str(perf/'warm3'),'warm3',str(fixture)])
run('fixed-four-load',[sys.executable,str(r/'tools/company-switch-performance/run_concurrent.py'),'--dotnet',dotnet,'--wpf',str(wpf),'--probe',str(probe),'--fixture',str(fixture),'--out',str(perf/'concurrent')],timeout=360)
