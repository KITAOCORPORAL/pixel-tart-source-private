import pathlib,json,hashlib,zipfile,re,subprocess
root=pathlib.Path.cwd();d=root/'Guangjing-Home-Reconnect-Audit-20261022';r=root/'guangjing-home-reconnect-20261022'
rows=json.loads((d/'all-worktrees-before.json').read_text(encoding='utf-8-sig'));print('worktrees',len(rows),'dirty',[(x['path'],x['status']) for x in rows if x['status']])
old=[]
for folder in root.iterdir():
 if folder.is_dir() and any(s in folder.name.lower() for s in ['guangjing','darkroom','photographer']):
  for p in folder.rglob('*.zip'):
   old.append(dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.file_digest(p.open('rb'),'sha256').hexdigest()))
(d/'old-zips-before.json').write_text(json.dumps(old,indent=2),encoding='utf8');print('old zips',len(old))
hits=[]
for p in (r/'docs/validation').rglob('*'):
 if p.is_file() and p.suffix in ['.json','.md','.csv','.txt'] and p.stat().st_size<5000000:
  text=p.read_text(encoding='utf-8-sig',errors='replace')
  if '32139' in text or 'temporaryDirectory' in text:
   lines=[l[:1600] for l in text.splitlines() if '32139' in l or 'temporaryDirectory' in l]
   hits.append(dict(path=str(p),lines=lines[:12]));print(str(p.relative_to(r)), '\n'.join(lines[:3]))
(d/'original-failure-locations.json').write_text(json.dumps(hits,ensure_ascii=False,indent=2),encoding='utf8')
for p in (r/'docs/validation').rglob('*.zip'):
 with zipfile.ZipFile(p) as z:
  for n in z.namelist():
   if n.endswith(('.trx','.json')):
    text=z.read(n).decode('utf-8-sig',errors='replace')
    if '32139.0909' in text:
     target=d/('original-'+p.parent.name+'-'+pathlib.Path(n).name);target.write_text(text,encoding='utf8');print('ORIGINAL',str(p.relative_to(r)),n)
     print('\n'.join([l[:4000] for l in text.splitlines() if '32139' in l or 'temporaryDirectory' in l][:6]))
