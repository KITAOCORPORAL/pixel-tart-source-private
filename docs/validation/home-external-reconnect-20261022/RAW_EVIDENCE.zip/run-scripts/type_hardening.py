from pathlib import Path
r=Path.cwd()/'guangjing-home-reconnect-20261022';p=r/'src/RAWSelectionAssistant.Core/Services/Projects/PlanningExternalReconnect.cs';s=p.read_text();needle='        var image = Image();';s=s.replace(needle,'''        var originalExtension=Path.GetExtension(original).ToLowerInvariant();
        if(kind=="reference" && ext!=originalExtension && !((ext is ".jpg" or ".jpeg") && (originalExtension is ".jpg" or ".jpeg")) && !((ext is ".tif" or ".tiff") && (originalExtension is ".tif" or ".tiff")))
            throw new InvalidDataException("替代参考图须与原文件格式相同；请先转换为原格式再定位。");
'''+needle);p.write_text(s,encoding='utf8')
p=r/'tests/RAWSelectionAssistant.Tests/PlanningExternalReconnectTests.cs';s=p.read_text();needle='    [TestMethod]public async Task ExternalReceiptRejectsLaterChangesInsteadOfFallingBack()';s=s.replace(needle,'''    [TestMethod]public async Task ReferenceFormatChangeIsRejectedBeforeCopyPathCanMislabelBytes()
    {
        using var t=new TempDirectory();var selected=t.CreateFile("new.png",new byte[]{137,80,78,71,13,10,26,10,1});
        await Assert.ThrowsExactlyAsync<InvalidDataException>(()=>PlanningExternalFile.InspectAsync(Guid.NewGuid(),"reference",t.Combine("old.jpg"),selected));
    }
'''+needle);p.write_text(s,encoding='utf8')
