import pathlib,subprocess,os,json,time,hashlib,shutil,threading
root=pathlib.Path.cwd();r=root/'guangjing-home-reconnect-20261022';d=root/'Guangjing-Home-Reconnect-Delivery-20261022';out=d/'performance-final-r3';out.mkdir();dotnet=r'C:\Program Files\dotnet\dotnet.exe';sha=subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD'],text=True).strip();app=d/'final-r3/app';probe=r/'tools/CompanySwitchProbe/bin/Release/net10.0/CompanySwitchProbe.dll';h=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
with (out/'build-probe.log').open('wb') as f:subprocess.run([dotnet,'build',str(r/'tools/CompanySwitchProbe/CompanySwitchProbe.csproj'),'-c','Release','--no-restore','-p:SourceRevisionId='+sha,'--disable-build-servers','-m:1','-nr:false'],stdout=f,stderr=f,check=True,creationflags=subprocess.CREATE_NO_WINDOW)
for f in app.glob('*.dll'):
 target=probe.parent/f.name
 if target.exists():shutil.copy2(f,target);assert h(f)==h(target)
core=r/'tests/RAWSelectionAssistant.Tests/bin/Release/net10.0/RAWSelectionAssistant.Tests.dll';wpf=r/'tests/RAWSelectionAssistant.WpfTests/bin/x64/Release/net10.0-windows10.0.19041.0/RAWSelectionAssistant.WpfTests.dll';assert h(app/'RAWSelectionAssistant.Core.dll')==h(probe.parent/'RAWSelectionAssistant.Core.dll')==h(core.parent/'RAWSelectionAssistant.Core.dll')
try:import psutil
except ImportError:psutil=None
fixture=d/'performance/shared-fixture';temp=root/'Guangjing-Home-Scenario11-Temp-FinalR3-20261022';temp.mkdir();env=os.environ.copy();env.update(TEMP=str(temp),TMP=str(temp),DOTNET_ROOT=str(pathlib.Path(dotnet).parent),PIXEL_TART_ISOLATED_RUNTIME='1',PIXEL_TART_ISOLATED_RUNTIME_ROOT=str(out/'runtime'),PIXEL_TART_HUMAN_ACCEPTANCE='0',PIXEL_TART_ACCEPTANCE_ROOT=str(out/'runtime'),PIXEL_TART_P35_ACCEPTANCE_ROOT=str(out/'measurements'),KITAO_TEST_RESOURCE_ROOT=str(r),KITAO_PRODUCT_SOURCE_SHA=sha,PIXEL_TART_PRODUCT_SOURCE_SHA=sha)
(out/'identity.json').write_text(json.dumps(dict(sourceSha=sha,coreSha256=h(app/'RAWSelectionAssistant.Core.dll'),testSha256=h(core),probeSha256=h(probe),sharedFixture=str(fixture),temp=str(temp),originalScenario11Untouched=True,purpose='Final product confirmation; earlier company-baseline household runs retained, no retries',psutilAvailable=psutil is not None),indent=2))
def run(label,cmd,limit=300):
 folder=out/label;folder.mkdir();start=time.time();children={}
 with (folder/'stdout.log').open('wb') as f:
  p=subprocess.Popen(cmd,stdout=f,stderr=f,env=env,cwd=r,creationflags=subprocess.CREATE_NO_WINDOW)
  while p.poll() is None:
   if psutil:
    try:
     for child in psutil.Process(p.pid).children(recursive=True):
      try:children[child.pid]=dict(pid=child.pid,parentPid=child.ppid(),name=child.name(),createEpoch=child.create_time(),firstObservedEpoch=children.get(child.pid,{}).get('firstObservedEpoch',time.time()),lastObservedEpoch=time.time())
      except psutil.Error:pass
    except psutil.Error:pass
   if time.time()-start>limit:subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],stdout=f,stderr=f);break
   time.sleep(.02)
  code=p.wait()
 (folder/'process.json').write_text(json.dumps(dict(command=cmd,pid=p.pid,startEpoch=start,endEpoch=time.time(),exitCode=code,children=list(children.values())),indent=2));print(label,code,flush=True)
run('original-single',[dotnet,'vstest',str(core),'/TestCaseFilter:FullyQualifiedName=RAWSelectionAssistant.Tests.AssetLibraryP35AcceptanceTests.Scenario11_TenKSwitchAndHundredKMetadataPreview','/Logger:trx;LogFileName=scenario11.trx','/ResultsDirectory:'+str(out/'original-single')])
run('warmup-three',[dotnet,str(probe),str(out/'warm3'),'warm3',str(fixture)])
run('fixed-four-load',[os.sys.executable,str(r/'tools/company-switch-performance/run_concurrent.py'),'--dotnet',dotnet,'--wpf',str(wpf),'--probe',str(probe),'--fixture',str(fixture),'--out',str(out/'concurrent')])
