import pathlib,zipfile,json,hashlib,subprocess,os,time
root=pathlib.Path.cwd();r=root/'guangjing-home-reconnect-20261022';d=root/'Guangjing-Home-Reconnect-Delivery-20261022';samples=d/'samples';samples.mkdir()
for p in (r/'docs/validation/planning-current-root-import-20261022').glob('*.zip'):
 with zipfile.ZipFile(p) as z:
  for n in z.namelist():
   if n.endswith('.ptplan'):
    data=z.read(n);f=samples/pathlib.Path(n).name;f.write_bytes(data);print('sample',n,len(data),hashlib.sha256(data).hexdigest())
app=d/'baseline/app';runtime=d/'baseline/desktop-runtime';env=os.environ.copy();env.update(PIXEL_TART_ISOLATED_RUNTIME='1',PIXEL_TART_ISOLATED_RUNTIME_ROOT=str(runtime),PIXEL_TART_HUMAN_ACCEPTANCE='1',PIXEL_TART_ACCEPTANCE_ROOT=str(runtime),PIXEL_TART_PRODUCT_SOURCE_SHA='2d8db4d9931f58af43025004cb794dc35affb8b3')
exe=app/'KitaoPhotoSelector.exe';p=subprocess.Popen([str(exe)],cwd=app,env=env);(d/'baseline/desktop-start.json').write_text(json.dumps(dict(pid=p.pid,exe=str(exe),startEpoch=time.time(),runtime=str(runtime)),indent=2));print('desktop pid',p.pid)
