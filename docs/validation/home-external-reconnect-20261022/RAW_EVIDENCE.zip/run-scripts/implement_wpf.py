from pathlib import Path
r=Path.cwd()/'guangjing-home-reconnect-20261022'
def put(p,s): (r/p).write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/PlanningExternalReconnect.cs';s=p.read_text().replace('    public bool SameContent(','''    public static string ResolveVerified(PlanningExternalFile file, Guid id, string kind, string original)
    {
        file.Validate(id, kind, original);
        var actual = InspectAsync(id, kind, original, file.SelectedPath).GetAwaiter().GetResult();
        if (!file.SameContent(actual)) throw new InvalidDataException("重连文件大小、类型或SHA-256已变化；未回退原位置。");
        return file.SelectedPath;
    }
    public bool SameContent(''');p.write_text(s,encoding='utf8')
put('src/RAWSelectionAssistant/ViewModels/PlanningCenterViewModel.ExternalReconnect.cs',r'''using System.IO;
using RAWSelectionAssistant.Core.Services.Projects;
namespace RAWSelectionAssistant.ViewModels;
public sealed record PlanningExternalDependency(Guid Id, string Kind, string Name, string Section, string OriginalPath, string Reason, bool CanReconnect);
public sealed partial class PlanningCenterViewModel
{
    public IReadOnlyList<PlanningExternalDependency> ExternalDependencies => _document.References.Where(x=>x.ProjectCopy is null).Select(x=>
        new PlanningExternalDependency(x.Source.ReferenceId,"reference",x.Source.Title??"未命名参考",x.Category+" / "+x.Group+(x.IsMoodboard?" / 情绪板":""),x.Source.ExternalReference??$"素材库 {x.Source.LibraryId}/{x.Source.AssetId}",
            x.Source.LibraryId is not null?"素材库原件未打包；本功能不定位或扫描素材库":ExternalReason(x.ReconnectedFile,x.Source.ReferenceId,"reference",x.Source.ExternalReference),x.Source.LibraryId is null && x.Source.ExternalReference is not null))
        .Concat(_document.Attachments.Where(x=>x.ProjectCopy is null).Select(x=>new PlanningExternalDependency(x.Id,"attachment",x.Name,"文件",x.Path,ExternalReason(x.ReconnectedFile,x.Id,"attachment",x.Path),true))).ToArray();
    public IReadOnlyList<string> UnsupportedPackageDependencies => _document.Extensions?.TryGetValue("PackageImportExcludedDependencies",out var value)==true && value.ValueKind==System.Text.Json.JsonValueKind.Array
        ? value.EnumerateArray().Select(x=>x.GetString()??"").Where(x=>!string.IsNullOrWhiteSpace(x)).ToArray() : ["素材库原件、档期、账本、画布及色彩方案不在本功能重连范围；不会自动扫描个人目录。"];
    private string ExternalReason(PlanningExternalFile? file, Guid id, string kind, string? original)
    {
        if(file is not null && original is not null)
        {
            try { PlanningExternalFile.ResolveVerified(file,id,kind,original);return "已手动重连 · 类型/大小/SHA-256已核对"; }
            catch(Exception e)when(PackageError(e)){return "手动重连文件不可用："+e.Message;}
        }
        if(IsPackageImported || ImportedPackageRoot is not null)return "项目包未包含原文件；为避免误读同名路径，须手动定位";
        return string.IsNullOrWhiteSpace(original)?"缺少原路径":File.Exists(original)?"外链仍在原位置；未复制":"原路径文件缺失或不可访问";
    }
    public async Task LocateExternalAsync(PlanningExternalDependency item,bool importCopy)
    {
        if(!item.CanReconnect)return;
        var path=_dialogs.ChooseFiles("定位新文件："+item.Name,item.Kind=="reference"?"参考图|*.png;*.jpg;*.jpeg;*.gif;*.bmp;*.tif;*.tiff":"普通附件|*.*",false).FirstOrDefault();
        if(path is null){SaveStatus="已取消定位，策划及已有副本不变";return;}
        try
        {
            var selected=await PlanningExternalFile.InspectAsync(item.Id,item.Kind,item.OriginalPath,path);
            if(!_dialogs.Confirm($"原引用ID：{item.Id}\n分区：{item.Section}\n原路径：{item.OriginalPath}\n新文件：{selected.SelectedPath}\n类型：{selected.FileType} · 大小：{selected.Bytes} bytes\nSHA-256：{selected.Sha256}\n原文件未打包，不能证明与原内容相同，请确认这就是要使用的替代文件。\n"+(importCopy?"导入项目自有副本，原文件不变。":"继续外链，不复制，重启后仍核对本次hash。"),"确认逐项重连")){SaveStatus="已取消确认，策划及已有副本不变";return;}
            await ReconnectExternalAsync(selected,importCopy);
        }
        catch(Exception e)when(PackageError(e)){SaveStatus="重连未完成，策划及已有副本不变："+e.Message;_dialogs.ShowError(SaveStatus);}
    }
    public async Task<bool> ReconnectExternalAsync(PlanningExternalFile selected,bool importCopy,CancellationToken token=default)
    {
        if(ProjectId is not Guid project || !await FlushAsync(token))return false;
        await _saveGate.WaitAsync(token);
        try
        {
            await _planning.ReconnectExternalAsync(project,selected,importCopy,token);
            if(ProjectId==project)
            {
                var saved=(await _planning.LoadAsync(project,CancellationToken.None)).Document!;
                var reference=saved.References.SingleOrDefault(x=>x.Source.ReferenceId==selected.ReferenceId);
                var attachment=saved.Attachments.SingleOrDefault(x=>x.Id==selected.ReferenceId);
                _document=_document with
                {
                    References=_document.References.Select(x=>reference is not null && x.Source.ReferenceId==selected.ReferenceId?x with{ProjectCopy=reference.ProjectCopy,ReconnectedFile=reference.ReconnectedFile}:x).ToArray(),
                    Attachments=_document.Attachments.Select(x=>attachment is not null && x.Id==selected.ReferenceId?x with{ProjectCopy=attachment.ProjectCopy,ReconnectedFile=attachment.ReconnectedFile}:x).ToArray()
                };
                // Preserve edits made while copying; their next save must carry the new receipt.
                if(_pendingDocuments.ContainsKey(project))QueueDocumentSave();
                RefreshAttachments();await RefreshDocumentReferencesAsync();PresentationChanged();
            }
            SaveStatus=importCopy?"已核对并导入项目副本；引用ID、原路径和分区不变":"已核对并保存外链；引用ID、原路径和分区不变";return true;
        }
        finally{_saveGate.Release();}
    }
}
''')
p=r/'src/RAWSelectionAssistant/ViewModels/PlanningCenterViewModel.References.cs';s=p.read_text();s=s.replace('            var owned = reference.ProjectCopy;','''            if (reference.ReconnectedFile is {} reconnected && reference.Source.ExternalReference is {} original)
            {
                try { path=PlanningExternalFile.ResolveVerified(reconnected,reference.Source.ReferenceId,"reference",original); }
                catch(Exception error)when(PackageError(error)){path=null;}
            }
            var owned = reference.ProjectCopy;''');s=s.replace(' : File.Exists(cache) ? cache : available ? path : null, available)', ' : available ? File.Exists(cache) ? cache : path : null, available)');s=s.replace('        return item.Link.Source.ExternalReference ?? (ReferencePathResolver is null ? null : await ReferencePathResolver(item.Link.Source));','''        if(item.Link.ReconnectedFile is {} reconnected && item.Link.Source.ExternalReference is {} original)
        { try { return PlanningExternalFile.ResolveVerified(reconnected,item.Id,"reference",original); } catch(Exception e)when(PackageError(e)){return null;} }
        if(IsPackageImported || ImportedPackageRoot is not null)return null;
        return item.Link.Source.ExternalReference ?? (ReferencePathResolver is null ? null : await ReferencePathResolver(item.Link.Source));''');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/ViewModels/PlanningCenterViewModel.ProjectCopies.cs';s=p.read_text().replace('        if (item.ProjectCopy is not {} copy) return File.Exists(item.Path) ? item.Path : null;','''        if (item.ProjectCopy is not {} copy)
        {
            if(item.ReconnectedFile is {} reconnected)
            {try{return PlanningExternalFile.ResolveVerified(reconnected,item.Id,"attachment",item.Path);}catch(Exception e)when(PackageError(e)){return null;}}
            return IsPackageImported || ImportedPackageRoot is not null ? null : File.Exists(item.Path) ? item.Path : null;
        }''');s=s.replace('"外链 · " + PlanningReadableSummaryBuilder.ReferenceState(item.Path)','"外链 · " + ExternalReason(item.ReconnectedFile,item.Id,"attachment",item.Path)');p.write_text(s,encoding='utf8')
# Do not trust a package author\'s saved local reconnect approval on a new machine.
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/PlanningProjectPackage.cs';s=p.read_text();needle='    private static string Hash(byte[] bytes)';s=s.replace(needle,'''    internal static PlanningDocument RequireLocalReconnect(PlanningDocument document) => document with
    {
        References=document.References.Select(x=>x with{ReconnectedFile=null}).ToArray(),
        Attachments=document.Attachments.Select(x=>x with{ReconnectedFile=null}).ToArray()
    };
'''+needle);s=s.replace('Document=checkedPackage.State.Document! with', 'Document=RequireLocalReconnect(checkedPackage.State.Document!) with');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/PlanningCurrentRootImport.cs';s=p.read_text();s=s.replace('var document=v.State.Document!', 'var document=PlanningProjectPackage.RequireLocalReconnect(v.State.Document!)');s=s.replace('var document=validated.State.Document!', 'var document=PlanningProjectPackage.RequireLocalReconnect(validated.State.Document!)');p.write_text(s,encoding='utf8')
# Entry remains visible when side list collapses at common desktop scale. Real desktop caught this.
p=r/'src/RAWSelectionAssistant/Views/PlanningCenterView.xaml.cs';s=p.read_text();needle='                DocumentContent.Children.Add(empty); return;';s=s.replace(needle,'''                empty.Children.Add(AsyncAction("导入项目包到当前应用",()=>_vm.ImportCurrentProjectPackageCommand.ExecuteAsync(null),"SecondaryButton"));
                foreach(var card in _vm.PlanningProjects)empty.Children.Add(AsyncAction(card.Name+" · "+card.ProjectId,()=>_vm.OpenPlanningProjectCommand.ExecuteAsync(card),"SecondaryButton"));
'''+needle);needle='          var start = MenuEntry';# spacing inspect below separate
s=s.replace('        var start = MenuEntry("开始拍摄", "IconCameraTether");','''        var reconnect=MenuEntry("缺失外链与手动重连","IconPlanning");reconnect.Click+=(_,_)=>ShowExternalReconnect();menu.Items.Add(reconnect);
        var start = MenuEntry("开始拍摄", "IconCameraTether");''');p.write_text(s,encoding='utf8')
put('src/RAWSelectionAssistant/Views/PlanningCenterView.ExternalReconnect.cs',r'''using System.Windows;
using System.Windows.Controls;
using RAWSelectionAssistant.Core.Services.Projects;
namespace RAWSelectionAssistant.Views;
public partial class PlanningCenterView
{
    private void ShowExternalReconnect()
    {
        if(_vm is null)return;
        var panel=new StackPanel{Margin=new Thickness(18),MaxWidth=760};
        panel.Children.Add(Text("缺失外链与手动重连",24,true));
        panel.Children.Add(Text("仅处理逐项明确选择的外部参考图和普通附件。不扫描目录、不猜测同名文件；保留原引用ID、原路径及分区。",14));
        foreach(var item in _vm.ExternalDependencies)
        {
            var row=new StackPanel{Margin=new Thickness(0,18,0,0)};
            row.Children.Add(Text(item.Name+" · "+item.Section,18,true));row.Children.Add(Text("ID："+item.Id+"\n原路径："+item.OriginalPath+"\n原因/状态："+item.Reason,13));
            if(item.CanReconnect)
            {
                var actions=new WrapPanel();
                actions.Children.Add(AsyncAction("定位新文件（继续外链）",async()=>{await _vm.LocateExternalAsync(item,false);ShowExternalReconnect();}));
                actions.Children.Add(AsyncAction("导入项目副本",async()=>{await _vm.LocateExternalAsync(item,true);ShowExternalReconnect();}));row.Children.Add(actions);
            }
            panel.Children.Add(row);
        }
        panel.Children.Add(Text("未支持/原项目包排除依赖（历史清单，不会自动消除）：",16,true));
        foreach(var text in _vm.UnsupportedPackageDependencies)panel.Children.Add(Text(text,12));
        var window=new Window{Title="缺失外链与手动重连",Owner=Window.GetWindow(this),Width=880,Height=740,Background=Brush("SurfacePrimaryBrush"),Content=new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=panel},WindowStartupLocation=WindowStartupLocation.CenterOwner};
        // One modeless owned window; rebuild its content after each individual action.
        if(_externalReconnectWindow is {IsVisible:true} previous){previous.Content=window.Content;return;}
        _externalReconnectWindow=window;window.Show();
    }
    private Window? _externalReconnectWindow;
}
''')
# Summary records new chosen location and verification without embedding external bytes.
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/PlanningReadableSummary.cs';s=p.read_text();s=s.replace('("原位置",attachment.Path),','("原位置",attachment.Path),("手动重连文件",attachment.ReconnectedFile?.SelectedPath),("重连类型",attachment.ReconnectedFile?.FileType),("重连大小",attachment.ReconnectedFile?.Bytes),("重连SHA-256",attachment.ReconnectedFile?.Sha256),');s=s.replace('("备注",r.Note),','("手动重连文件",d.References.FirstOrDefault(link=>link.Source.ReferenceId==r.ReferenceId)?.ReconnectedFile?.SelectedPath),("重连SHA-256",d.References.FirstOrDefault(link=>link.Source.ReferenceId==r.ReferenceId)?.ReconnectedFile?.Sha256),("备注",r.Note),');p.write_text(s,encoding='utf8')
