import pathlib,subprocess,json,time,os
root=pathlib.Path.cwd();r=root/'guangjing-home-reconnect-20261022';d=root/'Guangjing-Home-Reconnect-Delivery-20261022';dotnet=r'C:\Program Files\dotnet\dotnet.exe'
for label,args in [('core-final-dev',['build','tests/RAWSelectionAssistant.Tests/RAWSelectionAssistant.Tests.csproj','-c','Release']),('wpf-final-dev',['build','tests/RAWSelectionAssistant.WpfTests/RAWSelectionAssistant.WpfTests.csproj','-c','Release','-p:Platform=x64','-p:WholeAppDiagnosticBuild=true','-p:PhotographerTrialBuild=false'])]:
 with (d/(label+'.log')).open('wb') as f:p=subprocess.run([dotnet]+args+['--no-restore','--disable-build-servers','-m:1','-nr:false'],stdout=f,stderr=f,cwd=r,creationflags=subprocess.CREATE_NO_WINDOW)
 print(label,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
env=os.environ.copy();env.update(KITAO_TEST_RESOURCE_ROOT=str(r),KITAO_RECONNECT_EVIDENCE=str(d/'reconnect-synthetic-finaldev'),PIXEL_TART_ISOLATED_RUNTIME='1',PIXEL_TART_ISOLATED_RUNTIME_ROOT=str(d/'regression-runtime'))
for label,assembly,filter in [('core-new','tests/RAWSelectionAssistant.Tests/bin/Release/net10.0/RAWSelectionAssistant.Tests.dll','FullyQualifiedName~PlanningExternalReconnectTests'),('wpf-affected','tests/RAWSelectionAssistant.WpfTests/bin/x64/Release/net10.0-windows10.0.19041.0/RAWSelectionAssistant.WpfTests.dll','FullyQualifiedName~Planning|FullyQualifiedName~Docx|FullyQualifiedName~RichFlow')]:
 out=d/('regression-'+label);out.mkdir();cmd=[dotnet,'vstest',str(r/assembly),'/TestCaseFilter:'+filter,'/Logger:trx;LogFileName=results.trx','/ResultsDirectory:'+str(out),'/BlameHangTimeout:120s']
 with (out/'stdout.log').open('wb') as f:p=subprocess.Popen(cmd,stdout=f,stderr=f,env=env,cwd=r,creationflags=subprocess.CREATE_NO_WINDOW);code=p.wait(timeout=400)
 print(label,code,flush=True)
