from pathlib import Path
r=Path.cwd()/'guangjing-home-reconnect-20261022';p=r/'src/RAWSelectionAssistant/Views/PlanningCenterView.ExternalReconnect.cs';s=p.read_text().replace('await _vm.LocateExternalAsync(item,false);ShowExternalReconnect();','await LocateExternalFromWindowAsync(item,false);').replace('await _vm.LocateExternalAsync(item,true);ShowExternalReconnect();','await LocateExternalFromWindowAsync(item,true);');needle='    private Window? _externalReconnectWindow;';s=s.replace(needle,'''    private async Task LocateExternalFromWindowAsync(PlanningExternalDependency item,bool importCopy)
    {
        // IDialogService owns native pickers/confirmation on MainWindow. A modeless owned
        // window must not obscure that modal or remain interactive above its owner.
        var window=_externalReconnectWindow;window?.Hide();
        try{if(_vm is not null)await _vm.LocateExternalAsync(item,importCopy);}
        finally{if(window is not null){window.Show();ShowExternalReconnect();window.Activate();}}
    }
'''+needle);p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/ViewModels/PlanningCenterViewModel.References.cs';s=p.read_text().replace('var key = owned is not null ?', 'var key = reference.ReconnectedFile is {} verified ? verified.ReferenceId.ToString("N")+"/"+verified.Sha256 : owned is not null ?');p.write_text(s,encoding='utf8')
