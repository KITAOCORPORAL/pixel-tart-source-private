import pathlib,json,hashlib,subprocess,xml.etree.ElementTree as ET,zipfile
root=pathlib.Path.cwd();d=root/'Guangjing-Home-Reconnect-Delivery-20261022';a=root/'Guangjing-Home-Reconnect-Audit-20261022';r=root/'guangjing-home-reconnect-20261022'
# File contents of every pre-existing dirty/untracked file remain individually accountable.
rows=json.loads((a/'all-worktrees-before.json').read_text(encoding='utf-8-sig'));inventory=[]
for row in rows:
 p=pathlib.Path(row['path']);raw=subprocess.check_output(['git','-C',str(p),'-c','core.quotepath=false','status','--porcelain=v1','-z','--untracked-files=all'])
 for item in raw.split(b'\0'):
  if not item:continue
  name=item[3:].decode('utf8');f=p/name
  inventory.append(dict(tree=str(p),status=item[:2].decode(),file=name,bytes=f.stat().st_size if f.is_file() else None,sha256=hashlib.file_digest(f.open('rb'),'sha256').hexdigest() if f.is_file() else None))
(a/'dirty-files-content-baseline.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2),encoding='utf8')
# Read actual output; this is not an acceptance assertion based on return code only.
for name in ['baseline-desktop-15-summary.docx']:
 p=d/'samples'/name
 with zipfile.ZipFile(p) as z:
  xml=ET.fromstring(z.read('word/document.xml'));ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'};text=''.join(xml.itertext());headings=[]
  for para in xml.findall('.//w:p',ns):
   st=para.find('./w:pPr/w:pStyle',ns)
   if st is not None:headings.append(dict(style=st.attrib, text=''.join(para.itertext())))
  (d/'baseline/desktop-docx-readback.json').write_text(json.dumps(dict(file=str(p),sha256=hashlib.file_digest(p.open('rb'),'sha256').hexdigest(),titleMarkerPresent='家用实机编辑保存 20261022' in text,headings=headings),ensure_ascii=False,indent=2),encoding='utf8')
perf=d/'performance';load=json.loads((perf/'concurrent/load.json').read_text());span=(load['measurementStartEpoch'],load['measurementEndEpoch']);overlaps=[]
for e in load['events']:overlaps.append(dict(**e,overlapSeconds=max(0,min(span[1],e['endEpoch'])-max(span[0],e['startEpoch']))))
(perf/'overlap-readback.json').write_text(json.dumps(dict(measurementStart=span[0],measurementEnd=span[1],workers=overlaps,allFourWorkersOverlap=all(any(e['worker']==w and e['overlapSeconds']>0 for e in overlaps) for w in range(4))),indent=2))
print('dirty_files',len(inventory),'baseline_docx_readback_saved', 'four_workers_overlap',all(any(e['worker']==w and e['overlapSeconds']>0 for e in overlaps) for w in range(4)))
