from pathlib import Path
r=Path.cwd()/'guangjing-home-reconnect-20261022'
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/PlanningCurrentRootImport.cs';s=p.read_text().replace('Document=state.Document! with{Package=', 'Document=PlanningProjectPackage.RequireLocalReconnect(state.Document!) with{Package=');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/PlanningProjectPackage.cs';s=p.read_text().replace('await planning.SaveAsync(checkedPackage.State,token);','await planning.SaveAsync(checkedPackage.State with{Document=RequireLocalReconnect(checkedPackage.State.Document!)},token);');p.write_text(s,encoding='utf8')
p=r/'src/RAWSelectionAssistant/Views/PlanningCenterView.ExternalReconnect.cs';s=p.read_text().replace('previous.Content=window.Content;return;','window.Content=null;previous.Content=new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=panel};return;');# panel still attached to scroll child; remove first
s=s.replace('window.Content=null;previous.Content=', '((ScrollViewer)window.Content).Content=null;window.Content=null;previous.Content=');p.write_text(s,encoding='utf8')
# Validate persisted receipt identities on every bind, not just at mutation.
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/PlanningProjectCopy.cs';s=p.read_text().replace('ReconnectedFile =','ReconnectedFile =');s=s.replace('r with { ProjectCopy = BindCopy', 'r with { ReconnectedFile = BindExternal(r.ReconnectedFile,r.Source.ReferenceId,"reference",r.Source.ExternalReference), ProjectCopy = BindCopy').replace('a with { ProjectCopy = BindCopy', 'a with { ReconnectedFile = BindExternal(a.ReconnectedFile,a.Id,"attachment",a.Path), ProjectCopy = BindCopy');s=s.replace('    private static PlanningProjectCopy? BindCopy','''    private static PlanningExternalFile? BindExternal(PlanningExternalFile? file,Guid id,string kind,string? original)
    {
        if(file is not null){if(original is null)throw new InvalidDataException("重连无原路径");file.Validate(id,kind,original);}return file;
    }
    private static PlanningProjectCopy? BindCopy''');p.write_text(s,encoding='utf8')
# Core regression coverage.
(r/'tests/RAWSelectionAssistant.Tests/PlanningExternalReconnectTests.cs').write_text(r'''using System.Security.Cryptography;
using RAWSelectionAssistant.Core.Services.Projects;
namespace RAWSelectionAssistant.Tests;
[TestClass]public sealed class PlanningExternalReconnectTests
{
    static string Hash(string path)=>Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path)));
    [TestMethod]public async Task ExplicitReconnectKeepsReferencePartitionAndOriginalAndPersistsCopy()
    {
        using var t=new TempDirectory();var store=new PlanningProjectStore(t.Combine("planning"));var project=Guid.NewGuid();var id=Guid.NewGuid();var original=t.Combine("missing/old.png");var selected=t.CreateFile("selected/new.png",new byte[]{137,80,78,71,13,10,26,10,1});
        var reference=new PlanningDocumentReference(new(id,ShotReferenceKind.Lighting,ExternalReference:original),"灯光",true,true,"侧光");await store.UpdateDocumentAsync(project,new(){References=[reference]},new());
        var file=await PlanningExternalFile.InspectAsync(id,"reference",original,selected);await store.ReconnectExternalAsync(project,file,true);
        var saved=(await new PlanningProjectStore(store.StorageRoot).LoadAsync(project)).Document!.References.Single();Assert.AreEqual(reference.Source,saved.Source);Assert.AreEqual(reference.Category,saved.Category);Assert.AreEqual(reference.Group,saved.Group);Assert.AreEqual(reference.IsHero,saved.IsHero);Assert.AreEqual(reference.IsMoodboard,saved.IsMoodboard);Assert.AreEqual(original,saved.ProjectCopy!.OriginalPath);Assert.AreEqual(Hash(selected),Hash(PlanningProjectCopyStorage.Resolve(saved.ProjectCopy)));
        var before=Hash(Path.Combine(store.StorageRoot,project.ToString("N")+".planning.json"));await Assert.ThrowsExactlyAsync<InvalidDataException>(()=>store.ReconnectExternalAsync(project,file,false));Assert.AreEqual(before,Hash(Path.Combine(store.StorageRoot,project.ToString("N")+".planning.json")));
    }
    [TestMethod]public async Task ChangedCandidateCancellationWrongTypeAndIdentityConflictAreNonDestructive()
    {
        using var t=new TempDirectory();var store=new PlanningProjectStore(t.Combine("planning"));var project=Guid.NewGuid();var id=Guid.NewGuid();var original=t.Combine("gone.txt");var selected=t.CreateFile("new.txt","first"u8.ToArray());
        await store.UpdateDocumentAsync(project,new(){Attachments=[new(id,original,"通告单")]},new());var path=Path.Combine(store.StorageRoot,project.ToString("N")+".planning.json");var before=Hash(path);var file=await PlanningExternalFile.InspectAsync(id,"attachment",original,selected);
        await File.WriteAllTextAsync(selected,"second");await Assert.ThrowsExactlyAsync<InvalidDataException>(()=>store.ReconnectExternalAsync(project,file,true));Assert.AreEqual(before,Hash(path));
        using var canceled=new CancellationTokenSource();canceled.Cancel();await Assert.ThrowsAsync<OperationCanceledException>(()=>store.ReconnectExternalAsync(project,file,true,canceled.Token));Assert.AreEqual(before,Hash(path));
        await Assert.ThrowsExactlyAsync<InvalidDataException>(()=>PlanningExternalFile.InspectAsync(id,"reference",original,selected));
        await store.UpdateDocumentAsync(project,new(){Attachments=[new(id,original,"A"),new(id,original,"B")]},new());before=Hash(path);file=await PlanningExternalFile.InspectAsync(id,"attachment",original,selected);await Assert.ThrowsExactlyAsync<InvalidDataException>(()=>store.ReconnectExternalAsync(project,file,false));Assert.AreEqual(before,Hash(path));
    }
    [TestMethod]public async Task ExternalReceiptRejectsLaterChangesInsteadOfFallingBack()
    {
        using var t=new TempDirectory();var selected=t.CreateFile("file.txt","synthetic"u8.ToArray());var id=Guid.NewGuid();var original=t.Combine("old.txt");var file=await PlanningExternalFile.InspectAsync(id,"attachment",original,selected);Assert.AreEqual(selected,PlanningExternalFile.ResolveVerified(file,id,"attachment",original));await File.WriteAllTextAsync(selected,"changed");Assert.ThrowsExactly<InvalidDataException>(()=>PlanningExternalFile.ResolveVerified(file,id,"attachment",original));
    }
}
''',encoding='utf8')
(r/'tests/RAWSelectionAssistant.WpfTests/PlanningExternalReconnectWpfTests.cs').write_text(r'''using System.IO;
using System.Text.Json;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Validation;
using RAWSelectionAssistant.Core.Services.Projects;
using RAWSelectionAssistant.ViewModels;
using static RAWSelectionAssistant.WpfTests.RuntimeCorrectionWpfTests;
namespace RAWSelectionAssistant.WpfTests;
[TestClass][DoNotParallelize]public sealed class PlanningExternalReconnectWpfTests
{
    [TestMethod]public Task ImportMissingReconnectSaveRecreateAndFifteenSectionSummary()=>RunSta(async()=>
    {
        EnsureTestApplication();using var source=await PlanningFoundationWpfTests.Fixture.Create();using var target=await PlanningFoundationWpfTests.Fixture.Create();var output=Path.GetFullPath(Environment.GetEnvironmentVariable("KITAO_RECONNECT_EVIDENCE")??Path.Combine(target.Root,"evidence"));Directory.CreateDirectory(output);
        await source.Vm.LoadAsync(source.Id);source.Vm.DocumentTitle="外链重连合成项目";var original=Path.Combine(source.Root,"missing-reference.png");var attachment=Path.Combine(source.Root,"missing-attachment.txt");var id=Guid.NewGuid();await source.Vm.AddDocumentReferencesAsync([new(id,ShotReferenceKind.Lighting,ExternalReference:original,Title:"合成灯光参考")]);await source.Vm.AddAttachmentsAsync([attachment]);await source.Vm.FlushAsync();var package=Path.Combine(output,"external-reconnect-v1.ptplan");await source.Vm.ExportProjectPackageAsync(package);
        await target.Vm.ImportPackageToCurrentRootAsync(package);Assert.IsFalse(target.Vm.AllProjectReferences.Single().SourceAvailable);Assert.IsNull(target.Vm.ResolveAttachmentPath(target.Vm.Attachments.Single()));StringAssert.Contains(target.Vm.ExternalDependencies.First().Reason,"手动定位");
        var chosen=Path.Combine(output,"replacement.png");await File.WriteAllBytesAsync(chosen,PlanningRichFlowFixture.ReferencePng(0));var text=Path.Combine(output,"replacement.txt");await File.WriteAllTextAsync(text,"仅合成附件，请勿用于真实拍摄");
        var rf=await PlanningExternalFile.InspectAsync(id,"reference",original,chosen);Assert.IsTrue(await target.Vm.ReconnectExternalAsync(rf,false));var af=target.Vm.Attachments.Single();var selected=await PlanningExternalFile.InspectAsync(af.Id,"attachment",attachment,text);Assert.IsTrue(await target.Vm.ReconnectExternalAsync(selected,true));Assert.IsTrue(await target.Vm.FlushAsync());
        var restarted=target.NewVm();await restarted.ShowOverviewAsync();await restarted.OpenPlanningProjectCommand.ExecuteAsync(restarted.PlanningProjects.Single(x=>x.ProjectId==source.Id));Assert.IsTrue(restarted.AllProjectReferences.Single().SourceAvailable);Assert.AreEqual(chosen,await restarted.ResolveOriginalAsync(restarted.AllProjectReferences.Single()));Assert.IsNotNull(restarted.ResolveAttachmentPath(restarted.Attachments.Single()));
        var summary=Path.Combine(output,"reconnected-fifteen-sections.docx");Assert.IsNotNull(await restarted.ExportPlanningSummaryDocxAsync(summary));using(var document=WordprocessingDocument.Open(summary,false)){Assert.IsFalse(new OpenXmlValidator().Validate(document).Any());StringAssert.Contains(document.MainDocumentPart!.Document.InnerText,rf.Sha256);}
        var view=new RAWSelectionAssistant.Views.PlanningCenterView{DataContext=restarted};view.Measure(new System.Windows.Size(1100,800));view.Arrange(new System.Windows.Rect(0,0,1100,800));view.UpdateLayout();view.DataContext=null;
        // A fresh import never trusts this machine's local selection approval.
        var again=Path.Combine(output,"reexport-with-local-approval.ptplan");await restarted.ExportProjectPackageAsync(again);using var another=await PlanningFoundationWpfTests.Fixture.Create();await another.Vm.ImportPackageToCurrentRootAsync(again);Assert.IsFalse(another.Vm.AllProjectReferences.Single().SourceAvailable);
        await File.WriteAllTextAsync(Path.Combine(output,"RESULT.json"),JsonSerializer.Serialize(new{project=source.Id,reference=id,attachment=af.Id,rf.Sha256,package,summary,ordinaryList=true,viewModelRecreated=true,nativeDesktop=false,sectionCount=15}));
    });
}
''',encoding='utf8')
