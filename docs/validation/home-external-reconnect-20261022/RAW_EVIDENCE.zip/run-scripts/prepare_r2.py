from pathlib import Path
p=Path.cwd()/'Guangjing-Home-Reconnect-Audit-20261022/build_final.py';s=p.read_text().replace("out=d/'final'","out=d/'final-r2'").replace("str(d/'final-synthetic')","str(d/'final-r2-synthetic')").replace("str(d/'final-current-synthetic')","str(d/'final-r2-current-synthetic')");p.with_name('build_final_r2.py').write_text(s,encoding='utf8')
