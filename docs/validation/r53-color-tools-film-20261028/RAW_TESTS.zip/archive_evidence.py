import pathlib,zipfile,hashlib,json
r=pathlib.Path('E:/Kitao-Deliveries/r53-color-tools-film-20261028');doc=pathlib.Path('E:/Kitao-Worktrees/r53-color-tools-film-20261028/docs/validation/r53-color-tools-film-20261028');files=set();folders=['RAW_WIDE_A2_CORE','RAW_WIDE_A2_WPF']+[f'TOOLS_A{n}_{kind}' for n in [4,5,7,8,9,11,12,13,14,15,16,17] for kind in ['CORE','WPF']]+['INDEPENDENT_REOPEN','INDEPENDENT_A13','FINAL_CORE','FINAL_WPF','SEALED_CORE','SEALED_WPF','SEALED_INDEPENDENT']
for name in folders:
 p=r/name
 if p.exists():
  for f in p.rglob('*'):
   if f.is_file() and f.suffix.lower() in ['.json','.trx','.xml','.log','.txt'] and 'runtime' not in f.parts and 'temp' not in f.parts:files.add(f)
for f in r.glob('*'):
 if f.is_file() and f.suffix.lower() in ['.py','.json','.log','.md','.csv','.txt']:files.add(f)
for name in ['workflow-sealed','raw-user-sealed','raw-wide-sealed','native-final-startup']:
 p=r/name
 if p.exists():files.update(p.rglob('*.json'))
z=doc/'RAW_TESTS.zip';manifest=[]
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,6) as out:
 for f in sorted(files):
  b=f.read_bytes();name=f.relative_to(r).as_posix();out.writestr(name,b);manifest.append(dict(path=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
with zipfile.ZipFile(z) as f:
 assert len(f.infolist())==len(manifest)
 for row in manifest:assert hashlib.sha256(f.read(row['path'])).hexdigest()==row['sha256']
(doc/'RAW_MANIFEST.json').write_text(json.dumps(dict(path=z.name,sha256=hashlib.sha256(z.read_bytes()).hexdigest(),bytes=z.stat().st_size,readback=True,files=manifest),indent=2));print(len(manifest),z.stat().st_size)
