import importlib.util,pathlib,os,json
p=pathlib.Path('E:/Kitao-Worktrees/r53-color-tools-film-20261028/tools/whole-app-validation/verified_full_runner.py');spec=importlib.util.spec_from_file_location('verified',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);original=m.execution_units
methods=json.loads(os.environ.get('KITAO_EXACT_METHODS','[]'))
def selected_units(selected,single_process=False,p1_unit='method'):
 if methods:
  allcases=[c for cases in selected.values() for c in cases];wanted=[c for c in allcases if c['fullyQualifiedName'] in methods];assert set(c['fullyQualifiedName'] for c in wanted)==set(methods),'Exact requested method not discovered';return {name:[c for c in wanted if c['fullyQualifiedName']==name] for name in methods}
 return original(selected,single_process,p1_unit)
m.execution_units=selected_units
raise SystemExit(m.main())
