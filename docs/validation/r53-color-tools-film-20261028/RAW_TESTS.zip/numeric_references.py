import pathlib,ctypes,json,numpy as np,math
r=pathlib.Path('E:/Kitao-Deliveries/r53-color-tools-film-20261028');dll=pathlib.Path('E:/Kitao-Worktrees/r53-color-tools-film-20261028/tests/RAWSelectionAssistant.WpfTests/bin/x64/Release/net10.0-windows10.0.19041.0/lcms2.dll')
if not dll.exists():dll=dll.parent/'runtimes/win-x64/native/lcms2.dll'
lib=ctypes.CDLL(str(dll))
class XYZ(ctypes.Structure):_fields_=[('X',ctypes.c_double),('Y',ctypes.c_double),('Z',ctypes.c_double)]
lib.cmsAdaptToIlluminant.argtypes=[ctypes.POINTER(XYZ)]*4;lib.cmsAdaptToIlluminant.restype=ctypes.c_int
B=np.array([[.8951,.2664,-.1614],[-.7502,1.7135,.0367],[.0389,-.0685,1.0296]]);D=np.array([.3457/.3585,1,(1-.3457-.3585)/.3585]);rows=[]
for t in [-100,-30,0,30,100]:
 for tint in [-50,0,50]:
  x=.3457+t*.00025;y=.3585+tint*.0002;S=np.array([x/y,1,(1-x-y)/y]);M=np.linalg.inv(B)@np.diag((B@D)/(B@S))@B
  for v in [[.18,.18,.18],[.9,.1,.02],[-.1,.3,1.2],[2,1,4]]:
   o=XYZ();s=XYZ(*S);d=XYZ(*D);i=XYZ(*v);assert lib.cmsAdaptToIlluminant(ctypes.byref(o),ctypes.byref(s),ctypes.byref(d),ctypes.byref(i));native=[o.X,o.Y,o.Z];expected=M@v;rows.append(dict(temperature=t,tint=tint,input=v,lcms=native,independentBradford=expected.tolist(),maxAbs=float(max(abs(expected-np.array(native))))))
# Tone is a new bounded EV contract, not equal to either mature project's curve controls. Preserve stage-domain differences.
tone=[]
for y in [-.2,0,.001,.018,.18,.75,1,4,16]:
 for contrast in [-.5,0,.5]:
  ours=y if y<=0 else y*2**(contrast*(math.log2(y/.18)/math.sqrt(1+math.log2(y/.18)**2)))
  dt=y if y<=0 else (y/.18)**(1+contrast)*.18
  tone.append(dict(y=y,contrast=contrast,product=ours,darktablePowerContrast=dt,difference=ours-dt,rawtherapee='Histogram-adaptive NURBS not comparable with absent histogram; no equality claim'))
result=dict(whiteBalance=dict(reference1='Little-CMS2.12@924a020d09bfe468c665467caf24aadeb41ff77c src/cmswtpnt.c cmsAdaptToIlluminant, MIT',reference2='RawTherapee5.12@a8a3d1bc7b419ed1c974c39276c97e618a4f9a1b rtengine/color.cc Bradford D50/D65 and adaptation model, GPL3 reference-only',native=str(dll),cases=rows,maxAbs=max(x['maxAbs'] for x in rows)),tone=dict(reference1='darktable5.2.1@be9171cf8bb2feab8bd115efd9b96a4ce7103039 src/iop/basicadj.c get_contrast, GPL3 reference-only',reference2='RawTherapee5.12 rtengine/curves.cc contrast histogram/NURBS toe shoulder, GPL3 reference-only',cases=tone,decision='Independent bounded log-luma EV, no copied code. Negative luminance only exposure; >1 retained; gain preserves RGB ratios, no claimed matching appearance. Full dual tone engine execution remains OPEN'),RawWide=dict(source='LibRaw0.21.1@cccb97647fcee56801fa68231fa8a38aa8b52ef7 colorconst/prophoto_rgb and convert_to_rgb_loop',conversion='Existing LCMS2.12 float transform through profile PCS D50; exact source primaries derived from LibRaw matrix, not conventional D50 primaries relabeled D65'),CalibrationEligible=False)
(r/'NUMERIC_REFERENCES.json').write_text(json.dumps(result,indent=2));print('WB',result['whiteBalance']['maxAbs'],'cases',len(rows),'tone differences',len(tone))

