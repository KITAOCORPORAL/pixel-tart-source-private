import numpy as np,json,pathlib
m=np.array([[.529317,.330092,.140588],[.098368,.873465,.028169],[.016879,.117663,.865457]])
s=np.array([[.4124564,.3575761,.1804375],[.2126729,.7151522,.0721750],[.0193339,.1191920,.9503041]])
r=s@np.linalg.inv(m)
print('derived RGB->XYZ D65',r,'white',r@np.ones(3),'xy primaries',r/r.sum(axis=0))
pathlib.Path('E:/Kitao-Deliveries/r53-color-tools-film-20261028/LIBRAW_MATRIX_DERIVATION.json').write_text(json.dumps(dict(librawSrgbToOutput=m.tolist(),linearSrgbToXyzD65=s.tolist(),outputToXyzD65=r.tolist(),white=(r@np.ones(3)).tolist(),primariesXy=(r/r.sum(axis=0))[:2].T.tolist()),indent=2))
