import pathlib,zipfile,hashlib,json,collections
r=pathlib.Path('E:/Kitao-Deliveries/r53-raw-local-closure-20261027');p=r/'Guangjing-R53-RawLocal-Diagnostic-win-x64';out=p.with_suffix('.zip')
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
files=[dict(path=f.relative_to(p).as_posix(),bytes=f.stat().st_size,sha256=digest(f),type=f.suffix.lower() or '[none]') for f in p.rglob('*') if f.is_file()];(r/'APP_FILES.json').write_text(json.dumps(dict(sourceSha='5fbecc7ecce014bdaa489f5551d985b694488af4',files=files,types=dict(collections.Counter(x['type'] for x in files))),indent=2))
assert not any(x['path'].startswith('UserData/') or x['type'] in ['.db','.sqlite','.arw','.cr3','.raf'] for x in files)
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,6) as z:
 for f in files:z.write(p/f['path'],arcname=p.name+'/'+f['path'])
with zipfile.ZipFile(out) as z:
 assert len(z.infolist())==len(files)
 for row in files:
  h=hashlib.sha256()
  with z.open(p.name+'/'+row['path']) as f:
   for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
  assert h.hexdigest()==row['sha256'],row
result=dict(path=str(out),sha256=digest(out),bytes=out.stat().st_size,files=len(files),readback=True,noUserData=True,notInstaller=True);(r/'ZIP_IDENTITY.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
