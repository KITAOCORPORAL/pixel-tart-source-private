import pathlib,subprocess,json,hashlib
root=pathlib.Path('E:/Kitao-Deliveries/r53-raw-local-closure-20261027');old=pathlib.Path('E:/Kitao-Deliveries/r53-stage-a-completion-20261027/references');r=root/'mask-reference';r.mkdir(exist_ok=True)
src=(old/'darktable-src_develop_masks_brush.c').read_text();start=src.index('static void _brush_falloff(');end=src.index('\n}',start)+2;body=src[start:end].replace('restrict','');head='#include <stdio.h>\n#include <math.h>\n#define MAX(a,b) ((a)>(b)?(a):(b))\n'
main='int main(){float h,d;while(scanf("%f %f",&h,&d)==2){float b[2000]={0};int a[2]={0,0},z[2]={99,0};_brush_falloff(b,a,z,0,0,200,h,d);for(int i=0;i<100;i++)printf("%.9g%c",b[i],i==99?10:32);}return 0;}'
(r/'darktable-falloff.c').write_text(head+body+main)
# Isolated exact GIMP scalar update/erase statements. Not code brought into product.
g=(root/'gimp-reference/app/paint/gimppaintcore-loops.cc').read_text();start=g.index('if (Base::stipple)',g.index('struct CombineMask') if 'struct CombineMask' in g else 0)
(r/'gimp-mask.c').write_text('#include <stdio.h>\nint main(){double w,m,p;int mode;while(scanf("%d %lf %lf %lf",&mode,&w,&m,&p)==4){double out;if(mode==0)out=w+(1.0-w)*m*p;else if(mode==1)out=p>w?w+(p-w)*m*p:w;else out=(1.0-m*p)*w;printf("%.17g\\n",out);}return 0;}')
tcc=old/'tcc-isolated/tcc/tcc.exe'
for name in ['darktable-falloff','gimp-mask']:subprocess.run([str(tcc),str(r/(name+'.c')),'-o',str(r/(name+'.exe'))],check=True)
cases=[(h,d) for h in [0,.25,.5,.75,1] for d in [.25,.5,1]];data=''.join(f'{h} {d}\n' for h,d in cases);actual=subprocess.check_output([str(r/'darktable-falloff.exe')],input=data,text=True).splitlines();rows=[]
for (h,d),line in zip(cases,actual):
 values=list(map(float,line.split()));solid=int(100*h);errors=[]
 for i,v in enumerate(values[:-1]):
  expected=d*(1 if i<=solid else 1-(i-solid)/max(1,100-solid));errors.append(abs(expected-v))
 rows.append(dict(hardness=h,density=d,maxError=max(errors)))
maskcases=[(mode,w,m,p) for mode in range(3) for w in [0,.2,.8,1] for m in [0,.25,.75,1] for p in [.25,.5,1]];data=''.join(f'{mode} {w} {m} {p}\n' for mode,w,m,p in maskcases);actual=list(map(float,subprocess.check_output([str(r/'gimp-mask.exe')],input=data,text=True).splitlines()));grows=[]
for (mode,w,m,p),v in zip(maskcases,actual):
 # Our V1 stipple at density1 and erase agree. Constant-opacity differs unless flow=density.
 ours=w+(1-w)*m*p if mode==0 else (w+max(0,p-w)*m*p if mode==1 else w*(1-m*p));grows.append(dict(mode=mode,w=w,coverage=m,opacity=p,reference=v,productEquivalent=ours,error=abs(v-ours)))
result=dict(darktableCommit='be9171cf8bb2feab8bd115efd9b96a4ce7103039',gimpCommit='a77e8fd05d3d08a58650531a3700100f6a3216b7',licenses='GPL-3 local-only reference, no implementation source in product',darktable=rows,gimp=grows,scope='Extracted falloff function and scalar statements only; not full brush engine. Continuous dab/pressure semantics not claimed equal. V1 per-stroke flow preserved.',maxDarktable=max(x['maxError'] for x in rows),maxGimp=max(x['error'] for x in grows));(root/'MASK_REFERENCE_RESULT.json').write_text(json.dumps(result,indent=2));print(result['maxDarktable'],result['maxGimp'])

