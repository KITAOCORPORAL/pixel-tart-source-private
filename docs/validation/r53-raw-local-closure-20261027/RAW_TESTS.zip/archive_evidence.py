import pathlib,zipfile,json,hashlib
r=pathlib.Path('E:/Kitao-Deliveries/r53-raw-local-closure-20261027');doc=pathlib.Path('E:/Kitao-Worktrees/r53-stage-a-completion-20261027/docs/validation/r53-raw-local-closure-20261027');z=doc/'RAW_TESTS.zip'
folders=["BRUSH_BEFORE","RAW_A2_CORE","RAW_A2_WPF","RAW_A3_CORE","RAW_A3_WPF","RAW_A4_CORE","RAW_A4_WPF","RAW_A5_CORE","RAW_A5_WPF","RAW_A6_CORE","RAW_A6_WPF","RAW_A7_CORE","RAW_A7_WPF","RAW_A8_CORE","RAW_A8_WPF","RAW_A9_CORE","RAW_A9_WPF","RAW_A10_CORE","RAW_A10_WPF","RAW_A11_CORE","RAW_A11_WPF","RAW_A12_CORE","RAW_A12_WPF","RAW_A13_CORE","RAW_A13_WPF","RAW_A14_CORE","RAW_A14_WPF","SEALED_CORE","SEALED_WPF","PERF_CORE","PERF_WPF","FINAL_CORE","FINAL_WPF","FINAL_COLOR_MATRIX","FINAL_PERF_CORE","FINAL_PERF_WPF","LARGE_BRUSH_short","SEALED_LARGE_BRUSH_short","FINAL_LARGE_BRUSH_short","LARGE_BRUSH_long","SEALED_LARGE_BRUSH_long","FINAL_LARGE_BRUSH_long","LARGE_BRUSH_multi","SEALED_LARGE_BRUSH_multi","FINAL_LARGE_BRUSH_multi","SEALED_PROCESS_create","SEALED_PROCESS_reopen","SEALED_COMPARE","SEALED_APP_first","SEALED_APP_upgrade","SEALED_APP_restart_retained","FINAL_PROCESS_create","FINAL_PROCESS_reopen","FINAL_COMPARE","FINAL_APP_first","FINAL_APP_upgrade","FINAL_APP_restart_retained"]
files=set()
for folder in ['process-chain-final','process-chain-final2','sealed-full-app-first','sealed-full-app-upgrade','sealed-full-app-restart-retained','final-full-app-first','final-full-app-upgrade','final-full-app-restart-retained','native-startup','native-final-startup','final-real-local','final-large-compare','final-large-brush-short','final-large-brush-long','final-large-brush-multi']:
 p=r/folder
 if p.exists():
  for f in p.rglob('*.json'):files.add(f)
for folder in folders:
 p=r/folder
 if p.exists():
  for f in p.rglob('*'):
   if f.is_file() and f.suffix.lower() in ['.json','.trx','.xml','.log','.txt'] and 'runtime' not in f.parts and 'temp' not in f.parts:files.add(f)
for f in r.glob('*'):
 if f.is_file() and f.suffix.lower() in ['.py','.json','.log']:files.add(f)
for f in (r/'references').glob('*'):
 if f.is_file() and f.name not in ['darktable-kernel.c','imagemagick-kernel.c'] and f.suffix.lower() not in ['.exe','.zip']:files.add(f)
# GPL/image implementation source remains local isolation, never copied into evidence or product archive.
files={f for f in files if not f.name.startswith(('darktable-src','ImageMagick-MagickCore')) and f.name not in ['darktable-LICENSE','ImageMagick-LICENSE']}
manifest=[]
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,6) as out:
 for f in sorted(files):
  b=f.read_bytes();name=f.relative_to(r).as_posix();out.writestr(name,b);manifest.append(dict(path=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
with zipfile.ZipFile(z) as read:
 assert len(read.infolist())==len(manifest)
 for f in manifest:assert hashlib.sha256(read.read(f['path'])).hexdigest()==f['sha256']
(doc/'RAW_MANIFEST.json').write_text(json.dumps(dict(archive=z.name,sha256=hashlib.sha256(z.read_bytes()).hexdigest(),bytes=z.stat().st_size,readback=True,files=manifest),indent=2));print(len(manifest),z.stat().st_size)
