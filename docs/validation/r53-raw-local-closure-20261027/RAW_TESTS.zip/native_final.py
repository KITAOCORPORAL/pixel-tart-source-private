import pathlib,os,subprocess,json,time,ctypes,hashlib
r=pathlib.Path('E:/Kitao-Deliveries/r53-raw-local-closure-20261027');app=r/'Guangjing-R53-RawLocal-Final-Diagnostic-win-x64/app';env=os.environ.copy();env['PIXEL_TART_ISOLATED_RUNTIME']='1';env['PIXEL_TART_ISOLATED_RUNTIME_ROOT']=str(r/'native-final-startup/runtime');env['PIXEL_TART_ACCEPTANCE_ROOT']=env['PIXEL_TART_ISOLATED_RUNTIME_ROOT'];env['PIXEL_TART_HUMAN_ACCEPTANCE']='0';(r/'native-final-startup').mkdir(exist_ok=True)
p=subprocess.Popen([str(app/'KitaoPhotoSelector.exe')],cwd=app,env=env);time.sleep(6);rows=[]
if p.poll() is None:
 user=ctypes.windll.user32;callback=ctypes.WINFUNCTYPE(ctypes.c_bool,ctypes.c_void_p,ctypes.c_void_p)
 def each(hwnd,param):
  pid=ctypes.c_ulong();user.GetWindowThreadProcessId(hwnd,ctypes.byref(pid))
  if pid.value==p.pid:
   n=user.GetWindowTextLengthW(hwnd);buf=ctypes.create_unicode_buffer(n+1);user.GetWindowTextW(hwnd,buf,n+1);rows.append(dict(hwnd=int(hwnd),title=buf.value));
   if buf.value.startswith('光镜') and user.IsWindowVisible(hwnd):user.PostMessageW(hwnd,0x0010,0,0)
  return True
 user.EnumWindows(callback(each),0)
 try:p.wait(timeout=15)
 except subprocess.TimeoutExpired:pass
result=dict(pid=p.pid,windows=rows,exitCode=p.poll(),closed=p.poll() is not None,exe=str(app/'KitaoPhotoSelector.exe'),exeSha256=hashlib.sha256((app/'KitaoPhotoSelector.exe').read_bytes()).hexdigest(),scope='OS process/window identity and WM_CLOSE only. No pointer edit/save/DPI acceptance, no screenshots.',date='2026-10-27',timezone='America/New_York');(r/'native-final-startup/RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=True))
