import pathlib,struct,json
p=pathlib.Path('D:/AI AGENT/PixelTart-TestAssets/CompanyRAW/DSC09916.ARW');b=p.read_bytes();o=138498;n=struct.unpack_from('<H',b,o)[0];r=[]
for i in range(n):
 pos=o+2+i*12;tag,typ,count,val=struct.unpack_from('<HHII',b,pos);r.append(dict(tag=hex(tag),type=typ,count=count,value=val))
print(json.dumps(r,indent=2));pathlib.Path('E:/Kitao-Deliveries/r53-raw-local-closure-20261027/SONY_RAW_SUBIFD.json').write_text(json.dumps(r,indent=2))
