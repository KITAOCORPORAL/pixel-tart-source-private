import pathlib,os,subprocess,sys,json,time
r=pathlib.Path('E:/Kitao-Worktrees/r53-stage-a-completion-20261027');d=pathlib.Path('E:/Kitao-Deliveries/r53-raw-local-closure-20261027');dotnet='D:/AI AGENT/.dotnet/dotnet.exe';env=os.environ.copy();env['DOTNET_ROOT']=str(pathlib.Path(dotnet).parent);env['PATH']=str(pathlib.Path(dotnet).parent)+os.pathsep+env.get('PATH','')
for case in ['short','long','multi']:
 e=env.copy();e['KITAO_R53_LARGE_BRUSH_RENDER']=str(d/('sealed-large-brush-'+case));e['KITAO_R53_BRUSH_CASE']=case
 with (d/('SEALED_LARGE_BRUSH_'+case+'.log')).open('wb') as f:
  code=subprocess.run([sys.executable,str(r/'tools/whole-app-validation/verified_full_runner.py'),'--assembly',str(r/'tests/RAWSelectionAssistant.Tests/bin/Release/net10.0/RAWSelectionAssistant.Tests.dll'),'--output',str(d/('SEALED_LARGE_BRUSH_'+case)),'--dotnet',dotnet,'--resource-root',str(r),'--timeout','600','--classes','RAWSelectionAssistant.Tests.R53LargeBrushRenderTests'],env=e,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW).returncode
 print(case,code,flush=True)
