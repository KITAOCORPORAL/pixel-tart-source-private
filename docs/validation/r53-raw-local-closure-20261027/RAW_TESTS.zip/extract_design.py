import pathlib,zipfile,hashlib,json
z=pathlib.Path('C:/Users/Administrator/Downloads/光镜-UI-R5.3-定稿.zip');out=pathlib.Path('E:/Kitao-Deliveries/r53-raw-local-closure-20261027/design');out.mkdir(exist_ok=True)
assert hashlib.sha256(z.read_bytes()).hexdigest()=='16f75c0f40b506e4db57f140f389967264040cd8c5930ad24946b11c171e2ca9'
rows=[]
with zipfile.ZipFile(z) as f:
 for i in f.infolist():
  path=(out/i.filename).resolve();assert path.is_relative_to(out.resolve());
  if i.is_dir():path.mkdir(parents=True,exist_ok=True);continue
  path.parent.mkdir(parents=True,exist_ok=True);b=f.read(i);path.write_bytes(b);rows.append(dict(path=i.filename,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
(out.parent/'DESIGN_MANIFEST.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));print('\n'.join(x['path'] for x in rows))
