from PIL import Image
import pathlib
r=pathlib.Path('E:/Kitao-Deliveries/r53-raw-local-closure-20261027/large-fixtures');r.mkdir(exist_ok=True)
for i in range(6):
 im=Image.new('RGB',(6000,4000),(30+i*25,80+i*10,150-i*15));im.save(r/f'large-{i}.jpg',quality=94);im.save(r/f'large-{i}.png')
print(r)
