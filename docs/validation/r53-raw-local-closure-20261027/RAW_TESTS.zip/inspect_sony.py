import pathlib,struct,json
p=pathlib.Path('D:/AI AGENT/PixelTart-TestAssets/CompanyRAW/DSC09916.ARW');b=p.read_bytes();order='<' if b[:2]==b'II' else '>';nxt=struct.unpack_from(order+'I',b,4)[0];seen=set();rows=[]
while nxt and nxt not in seen and nxt<len(b)-2:
 seen.add(nxt);n=struct.unpack_from(order+'H',b,nxt)[0];entries=[]
 for i in range(n):
  pos=nxt+2+i*12
  if pos+12>len(b):break
  tag,typ,count,val=struct.unpack_from(order+'HHII',b,pos);size={1:1,2:1,3:2,4:4,5:8,7:1}.get(typ,1)*count;off=pos+8 if size<=4 else val;data=b[off:off+min(size,128)];entries.append(dict(tag=hex(tag),type=typ,count=count,value=val,ascii=data.rstrip(b'\0').decode('ascii','replace') if typ==2 else None,offsetInBounds=off+size<=len(b)))
 rows.append(dict(offset=nxt,n=n,entries=entries));nxt=struct.unpack_from(order+'I',b,nxt+2+n*12)[0]
out=dict(file=p.name,bytes=len(b),header=b[:16].hex(),ifds=rows);pathlib.Path('E:/Kitao-Deliveries/r53-raw-local-closure-20261027/SONY_TIFF_STRUCTURE.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
