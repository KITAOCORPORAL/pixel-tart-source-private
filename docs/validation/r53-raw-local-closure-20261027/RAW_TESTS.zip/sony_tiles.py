import pathlib,struct,json
p=pathlib.Path('D:/AI AGENT/PixelTart-TestAssets/CompanyRAW/DSC09916.ARW');b=p.read_bytes();offsets=struct.unpack_from('<70I',b,139356);lengths=struct.unpack_from('<70I',b,139636);bits=struct.unpack_from('<3H',b,139254);rows=[]
for o,n in zip(offsets,lengths):rows.append(dict(offset=o,bytes=n,end=o+n,inBounds=o+n<=len(b),marker=b[o:o+4].hex()))
r=dict(rawBits=bits,tiles=rows,allTileRangesValid=all(x['inBounds'] for x in rows),trailingBytes=len(b)-max(x['end'] for x in rows),scope='Structural integrity, not proof of every compressed payload byte or original camera checksum');pathlib.Path('E:/Kitao-Deliveries/r53-raw-local-closure-20261027/SONY_TILE_INTEGRITY.json').write_text(json.dumps(r,indent=2));print(bits,r['allTileRangesValid'],r['trailingBytes'],rows[:3])
