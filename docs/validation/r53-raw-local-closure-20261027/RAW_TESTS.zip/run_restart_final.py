import pathlib,os,subprocess,json,sys,time
r=pathlib.Path("E:/Kitao-Worktrees/r53-stage-a-completion-20261027");d=pathlib.Path("E:/Kitao-Deliveries/r53-raw-local-closure-20261027");dotnet='D:/AI AGENT/.dotnet/dotnet.exe';env=os.environ.copy();env['DOTNET_ROOT']=str(pathlib.Path(dotnet).parent);env['PATH']=str(pathlib.Path(dotnet).parent)+os.pathsep+env.get('PATH','');assembly=r/'tests/RAWSelectionAssistant.WpfTests/bin/x64/Release/net10.0-windows10.0.19041.0/RAWSelectionAssistant.WpfTests.dll';rows=[]
def run(label,cls,extra):
 e=env.copy();e.update(extra);args=[sys.executable,str(d/'method_runner.py'),'--assembly',str(assembly),'--output',str(d/label),'--dotnet',dotnet,'--resource-root',str(r),'--classes','RAWSelectionAssistant.WpfTests.'+cls]
 with (d/(label+'.log')).open('wb') as f:code=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,env=e,creationflags=subprocess.CREATE_NO_WINDOW).returncode
 rows.append(dict(label=label,exitCode=code));(d/'FINAL_SPECIAL_RUNS.json').write_text(json.dumps(rows,indent=2));print(label,code,flush=True)
run('FINAL_APP_restart_retained','TutorialRetirementProductTests',{'KITAO_RETIREMENT_APP_EVIDENCE':str(d/'final-full-app-restart-retained'),'KITAO_RETIREMENT_SCENARIO':'restart','KITAO_R53_RESTART_RUNTIME':"E:\\Kitao-Deliveries\\r53-raw-local-closure-20261027\\FINAL_APP_upgrade\\run-20261027-160138-f7cb6b96\\000\\runtime"})
