from PIL import Image
import pathlib
r=pathlib.Path('E:/Kitao-Deliveries/r53-raw-local-closure-20261027/planning-large-six');r.mkdir(exist_ok=True)
for i in range(6):
 im=Image.new('RGB',(6000,4000),(30+i*25,80+i*10,150-i*15))
 if i%2==0:
  exif=Image.Exif();exif[274]=6;im.save(r/f'large-{i}.jpg',quality=94,exif=exif)
 else:im.rotate(90,expand=True).save(r/f'large-{i}.png')
print(len(list(r.iterdir())))
