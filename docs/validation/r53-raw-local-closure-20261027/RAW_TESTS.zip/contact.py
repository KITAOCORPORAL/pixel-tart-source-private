from PIL import Image,ImageDraw
import pathlib,math
r=pathlib.Path('E:/Kitao-Deliveries/r53-raw-local-closure-20261027/design');files=list(r.rglob('*.png'));w=1440;out=Image.new('RGB',(w,math.ceil(len(files)/3)*330),'#222');d=ImageDraw.Draw(out)
for i,p in enumerate(files):
 im=Image.open(p);im.thumbnail((480,300));x=(i%3)*480;y=(i//3)*330;out.paste(im,(x,y));d.text((x,y+302),f'{i+1}. '+p.name,fill='white')
out.save(r.parent/'design-contact.png')
