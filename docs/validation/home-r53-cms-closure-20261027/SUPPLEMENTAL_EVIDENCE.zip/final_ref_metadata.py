from pathlib import Path
import json,hashlib,shutil
r=Path('N:/pixart/guangjing-r53-stage-b-20261027');o=Path('N:/pixart/Guangjing-R53-Home-20261027-CmsClosure');v=r/'docs/validation/home-r53-cms-closure-20261027'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files=[]
for p in (o/'reference').glob('*'):
 if p.is_file() and p.suffix in ['.cpp','.c','.md']or p.is_file() and p.name=='pdfium-LICENSE':files.append(dict(path=p.name,sha256=h(p),bytes=p.stat().st_size))
(v/'REFERENCE_MANIFEST.json').write_text(json.dumps(dict(Pillow='12.3.0',libjpegRuntime='3.1.4.1',libjpegRuntimeCommit='9217719d3a58633923b096af4c1d50d304768a64',jpegSourceInitialPinned='af9c1c268520a29adf98cad5138dafe612b3d318',pdfium='a84323421e94f484faca52dd9d027934eba42ab8',photocraft='7ac7b8b106acccf6826d45ed5c9e481dfe341035',lcmsProduct='2.12@924a020d09bfe468c665467caf24aadeb41ff77c',lcmsRefWic='WindowsWIC actual run, 8bit quantization/clipping recorded',licenses=dict(pdfium='BSD-style research-only not distributed',photocraft='MIT OR Apache2; independent implementation no copied source',libjpeg='IJG BSD/zlib; only Python reference runtime, no new product codec',lcms='existing MIT component licenses retained',rawtherapee='GPL3 research only no code distribution'),researchSourceAndBinariesNotIncludedInProduct=True,files=files),indent=2),encoding='utf-8')
# Traceable scripts and no algorithm source copies in the repository.
(v/'VALIDATION_SCRIPT_MANIFEST.json').write_text(json.dumps([dict(path=p.name,sha256=h(p),bytes=p.stat().st_size)for p in o.glob('*.py')],indent=2),encoding='utf-8')