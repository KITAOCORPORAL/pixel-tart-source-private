from pathlib import Path
r=Path('N:/pixart/guangjing-r53-stage-b-20261027')
p=r/'tests/RAWSelectionAssistant.WpfTests/R53CmsClosureTests.cs'
p.write_text('''using System.IO;
using System.Text.Json;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using RAWSelectionAssistant.Core.Services.Color;
using RAWSelectionAssistant.Core.Services.Color.ControlledIcc;
using RAWSelectionAssistant.Core.Services.Projects;
using RAWSelectionAssistant.Services;
using static RAWSelectionAssistant.WpfTests.RuntimeCorrectionWpfTests;
namespace RAWSelectionAssistant.WpfTests;
[TestClass][DoNotParallelize]
public sealed class R53CmsClosureTests
{
    static string Output => Environment.GetEnvironmentVariable("KITAO_CMS_CLOSURE") ?? throw new InvalidOperationException("Explicit isolated output required");
    static byte[] Decode(string path) { using var f=File.OpenRead(path);var frame=BitmapDecoder.Create(f,BitmapCreateOptions.PreservePixelFormat,BitmapCacheOption.OnLoad).Frames[0];var rgb=new FormatConvertedBitmap(frame,PixelFormats.Rgb24,null,0);var bytes=new byte[rgb.PixelWidth*rgb.PixelHeight*3];rgb.CopyPixels(bytes,rgb.PixelWidth*3,0);return bytes; }
    static object Errors(byte[] expected,byte[] actual){double sum=0,sq=0;int max=0;for(int i=0;i<actual.Length;i++){int d=Math.Abs(expected[i]-actual[i]);sum+=d;sq+=(double)d*d;max=Math.Max(max,d);}return new{mean=sum/actual.Length,rmse=Math.Sqrt(sq/actual.Length),max};}
    [TestMethod] public Task JpegCodecRootCauseProbe() => RunSta(async()=>
    {
        EnsureTestApplication();var dir=Output;Directory.CreateDirectory(dir);using var cms=new LcmsRgbEngine();var srgb=cms.StandardProfile("sRGB");var rows=new List<object>();
        foreach(var kind in new[]{"gradient","gray","blocks","highfreq"})foreach(var space in new[]{"sRGB","DisplayP3","AdobeRGB","ProPhotoRGB"})
        {
            int w=128,h=64;var floats=new float[w*h*3];
            for(int y=0;y<h;y++)for(int x=0;x<w;x++){int i=(y*w+x)*3;float u=x/(float)(w-1),v=y/(float)(h-1);var rgb=kind switch{"gray"=>new[]{u,u,u},"blocks"=>new[]{x<64?1f:0f,y<32?1f:0f,x<32||x>96?1f:0f},"highfreq"=>new[]{(x%2),y%2,(float)((x+y)%2)},_=>new[]{.1f+.7f*u,.1f+.5f*v,.3f}};Array.Copy(rgb,0,floats,i,3);}
            var profile=cms.StandardProfile(space);using var transform=cms.CreateTransform(srgb,profile);var values=transform.Convert(floats);var bytes=values.Select(x=>(byte)Math.Clamp(Math.Round(Math.Round(x*65535)/257d),0,255)).ToArray();
            var prefix=Path.Combine(dir,kind+"-"+space);await File.WriteAllBytesAsync(prefix+".rgb",bytes);await File.WriteAllBytesAsync(prefix+".icc",profile.Bytes());
            var type=typeof(DocumentColorWorkflowV1).Assembly.GetType("RAWSelectionAssistant.Services.ProfessionalWicRowEncoder")!;
            var method=type.GetMethod("WriteRows",System.Reflection.BindingFlags.Static|System.Reflection.BindingFlags.NonPublic)!;
            Action<int,byte[]> fill=(y,row)=>{for(int x=0;x<w;x++){int i=(y*w+x)*3;row[x*3]=bytes[i+2];row[x*3+1]=bytes[i+1];row[x*3+2]=bytes[i];}};
            method.Invoke(null,[prefix+".jpg",w,h,95,fill,CancellationToken.None,false,true,96,profile.Bytes()]);
            var read=Decode(prefix+".jpg");rows.Add(new{kind,space,w,h,errors=Errors(bytes,read),firstExpected=bytes.Take(9),firstActual=read.Take(9)});
            await File.WriteAllBytesAsync(prefix+".wic.rgb",read);
        }
        await File.WriteAllTextAsync(Path.Combine(dir,"PROBE.json"),JsonSerializer.Serialize(rows,new JsonSerializerOptions{WriteIndented=true}));
    });
}
''',encoding='utf-8')