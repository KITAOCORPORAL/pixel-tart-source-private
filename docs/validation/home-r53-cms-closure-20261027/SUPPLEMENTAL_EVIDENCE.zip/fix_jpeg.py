from pathlib import Path
r=Path('N:/pixart/guangjing-r53-stage-b-20261027');p=r/'tests/RAWSelectionAssistant.WpfTests/R53CmsClosureTests.cs';s=p.read_text(encoding='utf-8');s=s.replace('BitmapCreateOptions.PreservePixelFormat,BitmapCacheOption.OnLoad','BitmapCreateOptions.PreservePixelFormat|BitmapCreateOptions.IgnoreColorProfile,BitmapCacheOption.OnLoad');p.write_text(s,encoding='utf-8')
p=r/'src/RAWSelectionAssistant/Services/DocumentColorWorkflowV1.cs';s=p.read_text(encoding='utf-8');s=s.replace('if(format==StudioExportFormat.Jpeg)throw new NotSupportedException("颜色管理V1目前只放行TIFF16/PNG16；宽色域JPEG编码读回未通过固定误差门槛，未发布或放宽预算。");','')
s=s.replace('var result=Inspect(temp,master,definition,format,token);','var result=InspectStructure(temp,definition,size.Width,size.Height,format,token);')
s=s.replace('BitmapCreateOptions.PreservePixelFormat,BitmapCacheOption.OnLoad).Frames[0];if(frame.PixelWidth!=size.Width','BitmapCreateOptions.PreservePixelFormat|BitmapCreateOptions.IgnoreColorProfile,BitmapCacheOption.OnLoad).Frames[0];if(frame.PixelWidth!=size.Width')
a=s.rfind('\n}');s=s[:a]+'''
 // Interactive integrity gate: decode/ICC/container validation, without rendering the edit twice.
 public static ProfessionalOutputInspection InspectStructure(string file,ProfessionalRawDefinition definition,int width,int height,StudioExportFormat format,CancellationToken token=default)
 {
  token.ThrowIfCancellationRequested();var state=definition.ColorState!.Validate();
  using var input=File.OpenRead(file);var frame=BitmapDecoder.Create(input,BitmapCreateOptions.PreservePixelFormat|BitmapCreateOptions.IgnoreColorProfile,BitmapCacheOption.OnLoad).Frames[0];
  bool jpeg=format==StudioExportFormat.Jpeg;int bits=jpeg?8:16;
  if(frame.PixelWidth!=width||frame.PixelHeight!=height||frame.ColorContexts is not{Count:1}||!jpeg&&frame.Format.BitsPerPixel<48)throw new InvalidDataException("CMS dimensions/depth/profile missing");
  using var stream=frame.ColorContexts[0].OpenProfileStream();using var memory=new MemoryStream();stream.CopyTo(memory);if(!memory.ToArray().AsSpan().SequenceEqual(state.Output.Bytes()))throw new InvalidDataException("CMS ICC identity differs");
  if(jpeg)ValidateJpeg444(file);
  var decoded=new FormatConvertedBitmap(frame,jpeg?PixelFormats.Rgb24:PixelFormats.Rgb48,null,0);var row=new byte[width*(jpeg?3:6)];
  for(int y=0;y<height;y++){token.ThrowIfCancellationRequested();decoded.CopyPixels(new System.Windows.Int32Rect(0,y,width,1),row,row.Length,0);}
  using var cms=new LcmsRgbEngine();return new(width,height,bits,1,state.Output.Sha256==cms.StandardProfile("sRGB").Sha256,jpeg?95:null,0,0,0){EncoderConfiguration="DocumentColorV1-StructureOnly-"+state.Output.Sha256};
 }
 private static void ValidateJpeg444(string path)
 {
  using var stream=File.OpenRead(path);using var reader=new BinaryReader(stream);if(reader.ReadByte()!=255||reader.ReadByte()!=216)throw new InvalidDataException("JPEG SOI missing");
  while(stream.Position<stream.Length){if(reader.ReadByte()!=255)throw new InvalidDataException("JPEG marker invalid");byte marker;do{marker=reader.ReadByte();}while(marker==255);if(marker is 0xd9 or 0xda)break;if(marker==0xd8||marker is >=0xd0 and <=0xd7)continue;int length=(reader.ReadByte()<<8)|reader.ReadByte();if(length<2)throw new InvalidDataException("JPEG segment invalid");if(marker is 0xc0 or 0xc1 or 0xc2){if(reader.ReadByte()!=8)throw new InvalidDataException("JPEG precision invalid");reader.ReadBytes(4);int count=reader.ReadByte();if(count!=3)throw new InvalidDataException("JPEG RGB components invalid");for(int i=0;i<count;i++){reader.ReadByte();if(reader.ReadByte()!=0x11)throw new InvalidDataException("JPEG is not 4:4:4");reader.ReadByte();}return;}stream.Position+=length-2;}throw new InvalidDataException("JPEG frame missing");
 }
'''+s[a:];p.write_text(s,encoding='utf-8')
# Explicitly present real output color/depth in export dialog.
p=r/'src/RAWSelectionAssistant/Views/DarkroomExportDialog.xaml.cs';s=p.read_text(encoding='utf-8-sig');print(s[:2500])