from pathlib import Path
p=Path('C:/Users/Admin/AppData/Local/Temp/guangjing-photocraft-7ac7b8/imagemagick-composite.c');s=p.read_text();
for term in ['SoftLightCompositeOp','OverlayCompositeOp','ColorizeCompositeOp','LuminizeCompositeOp']:
 start=s.find('case '+term);print(term,start);print(s[start:start+1500])