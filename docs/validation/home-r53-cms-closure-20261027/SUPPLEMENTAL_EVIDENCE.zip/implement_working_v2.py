from pathlib import Path
r=Path('N:/pixart/guangjing-r53-stage-b-20261027')
(r/'src/RAWSelectionAssistant.Core/Services/Color/ControlledIcc/DocumentRenderResultV1.cs').write_text('''using RAWSelectionAssistant.Core.Services.Projects;
namespace RAWSelectionAssistant.Core.Services.Color.ControlledIcc;
/// <summary>Owned document pixels before any monitor transform. Alpha is straight and independent.</summary>
public sealed class DocumentRenderResultV1 : IDisposable
{
 public HighBitDepthImageBuffer Pixels {get;}
 public RgbIccIdentityV1 Profile {get;}
 public ReadOnlyMemory<float> Alpha {get;}
 public Guid? EditVersionId {get;}
 public string GeometryIdentity {get;}
 public string PixelFormat => "RGB-float32";
 public string AlphaPolicy => Alpha.IsEmpty ? "Opaque" : "StraightIndependentV1";
 public DocumentRenderResultV1(HighBitDepthImageBuffer pixels,RgbIccIdentityV1 profile,Guid? version,string geometry,ReadOnlyMemory<float> alpha=default)
 {profile.Bytes();if(!alpha.IsEmpty&&(alpha.Length!=pixels.PixelCount||alpha.Span.ToArray().Any(x=>!float.IsFinite(x)||x<0||x>1)))throw new InvalidDataException("Invalid independent alpha");Pixels=pixels;Profile=profile;EditVersionId=version;GeometryIdentity=geometry;Alpha=alpha;}
 public void RequireOpaque(){if(!Alpha.IsEmpty&&Alpha.Span.ToArray().Any(x=>x<1))throw new NotSupportedException("透明像素需要明确背景或独立Alpha出口；未静默压白。");}
 public DocumentRenderResultV1 ConvertTo(RgbIccIdentityV1 target,CancellationToken token=default)
 {using var cms=new LcmsRgbEngine();using var t=cms.CreateTransform(Profile,target);return new(new(Pixels.Width,Pixels.Height,t.Convert(Pixels.Rgb32.Span,token),"32f",target.Label,Pixels.Orientation),target,EditVersionId,GeometryIdentity,Alpha.IsEmpty?default:Alpha.ToArray());}
 public void Dispose()=>Pixels.Dispose();
}
''',encoding='utf-8')
p=r/'src/RAWSelectionAssistant.Core/Services/Color/ControlledIcc/LcmsRgbEngine.cs';s=p.read_text(encoding='utf-8');s=s.replace('case "ProPhotoRGB":srgb=false;','case "LinearProPhotoD50V2":case "ProPhotoRGB":srgb=false;');s=s.replace('var curve=srgb?', 'var curve=id=="LinearProPhotoD50V2"?Fn<Gamma>("cmsBuildGamma")(0,1):srgb?');p.write_text(s,encoding='utf-8')
p=r/'src/RAWSelectionAssistant.Core/Services/Color/ControlledIcc/DocumentColorStateV1.cs';s=p.read_text(encoding='utf-8');s=s.replace('if(Version!=1||Engine!=','if(Version is not(1 or 2)||Engine!=');s=s.replace('Input.Bytes();Working.Bytes();Output.Bytes();return this;','Input.Bytes();Working.Bytes();Output.Bytes();using var cms=new LcmsRgbEngine();if(Working.Sha256!=cms.StandardProfile(Version==2?"LinearProPhotoD50V2":"sRGB").Sha256)throw new NotSupportedException("Working profile does not match the versioned calculation domain");return this;');p.write_text(s,encoding='utf-8')
(r/'src/RAWSelectionAssistant.Core/Services/Projects/DocumentWorkingRendererV2.cs').write_text('''using RAWSelectionAssistant.Core.Services.Color;
using RAWSelectionAssistant.Core.Services.Color.ControlledIcc;
namespace RAWSelectionAssistant.Core.Services.Projects;
/// <summary>Minimum admitted scene-independent linear RGB path: D50 ROMM primaries, gamma1, float32. No legacy SDR tools.</summary>
public static class DocumentWorkingRendererV2
{
 public const string Space="LinearProPhotoD50V2";
 public static void Validate(ProfessionalRawDefinition d)
 {
  if(d.ColorState?.Version!=2)return;
  foreach(var n in d.LocalEdits?.Stack.Nodes??[])
   if(n.Type!=ColorStudioNodeType.BasicTone||n.Blend!=StudioLayerBlend.Normal||n.NumericParameters.Any(p=>p.Key!="exposure"&&p.Value!=0)||Math.Abs(n.NumericParameters.GetValueOrDefault("exposure"))>10)
    throw new NotSupportedException("宽色域编辑V2仅支持线性曝光、Normal强度/蒙版与几何；其他encoded-sRGB工具尚未适配。");
 }
 public static HighBitDepthImageBuffer Region(ProfessionalRawMaster m,ProfessionalRawDefinition d,int left,int top,int w,int h,CancellationToken token)
 {
  ProfessionalRawPipeline.ValidateMaster(m,d);Validate(d);var size=ProfessionalRawLocalRenderer.Size(m,d);if(left<0||top<0||w<=0||h<=0||left+w>size.Width||top+h>size.Height)throw new ArgumentOutOfRangeException();
  var oriented=ProfessionalRawPipeline.OrientedSize(m);var g=d.Geometry??new();var data=new float[w*h*3];var input=m.Image.Rgb32.Span;
  var nodes=(d.LocalEdits?.Stack.Nodes.Where(n=>n.Enabled)??[]).Select(n=>(Node:n,Mask:n.LocalMask?.Compile((double)oriented.Width/oriented.Height,token))).ToArray();
  for(int y=0;y<h;y++){token.ThrowIfCancellationRequested();for(int x=0;x<w;x++){
   var p=g.SourceTuple((left+x+.5)/size.Width,(top+y+.5)/size.Height,(double)oriented.Width/oriented.Height);
   double sx=p.X*oriented.Width-.5,sy=p.Y*oriented.Height-.5;int x0=(int)Math.Floor(sx),y0=(int)Math.Floor(sy);double fx=sx-x0,fy=sy-y0;
   for(int c=0;c<3;c++){
    double Read(int ox,int oy){if(ox<0||oy<0||ox>=oriented.Width||oy>=oriented.Height)return 0;int iw=m.Image.Width,ih=m.Image.Height;var (ax,ay)=m.Image.Orientation switch{2=>(iw-1-ox,oy),3=>(iw-1-ox,ih-1-oy),4=>(ox,ih-1-oy),5=>(oy,ox),6=>(oy,ih-1-ox),7=>(iw-1-oy,ih-1-ox),8=>(iw-1-oy,ox),_=>(ox,oy)};return m.Image.Rgb32.Span[(ay*iw+ax)*3+c];}
    double value=g.Version==2?(Read(x0,y0)*(1-fx)+Read(x0+1,y0)*fx)*(1-fy)+(Read(x0,y0+1)*(1-fx)+Read(x0+1,y0+1)*fx)*fy:Read(Math.Clamp((int)(p.X*oriented.Width),0,oriented.Width-1),Math.Clamp((int)(p.Y*oriented.Height),0,oriented.Height-1));
    foreach(var item in nodes){double amount=item.Node.Opacity*(item.Mask?.Invoke(p.X,p.Y)??1);double ev=item.Node.NumericParameters.GetValueOrDefault("exposure");value+=value*(Math.Pow(2,ev)-1)*amount;}
    data[(y*w+x)*3+c]=(float)value;
   }
  }}return new(w,h,data,"32f",Space,1);
 }
 public static HighBitDepthImageBuffer Preview(ProfessionalRawMaster m,ProfessionalRawDefinition d,int edge,CancellationToken token)
 {
  var size=ProfessionalRawLocalRenderer.Size(m,d);using var full=Region(m,d,0,0,size.Width,size.Height,token);using var cms=new LcmsRgbEngine();using var t=cms.CreateTransform(d.ColorState!.Working,cms.StandardProfile("sRGB"));var srgb=t.Convert(full.Rgb32.Span,token);
  double scale=edge>0?Math.Min(1,edge/(double)Math.Max(size.Width,size.Height)):1;int w=Math.Max(1,(int)Math.Round(size.Width*scale)),h=Math.Max(1,(int)Math.Round(size.Height*scale));var rgb=new float[w*h*3];for(int y=0;y<h;y++){token.ThrowIfCancellationRequested();for(int x=0;x<w;x++)for(int c=0;c<3;c++)rgb[(y*w+x)*3+c]=srgb[(Math.Min(size.Height-1,(int)((y+.5)/scale))*size.Width+Math.Min(size.Width-1,(int)((x+.5)/scale)))*3+c];}return new(w,h,rgb,"32f","sRGB",1);
 }
}
''',encoding='utf-8')
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/ProfessionalRawLocalEdits.cs';s=p.read_text(encoding='utf-8');s=s.replace('public static bool Active(ProfessionalRawDefinition d)=>','public static bool Active(ProfessionalRawDefinition d)=>d.ColorState?.Version==2||');s=s.replace('  prepared??=new Prepared(m,d,token);d=prepared.Definition;','  if(d.ColorState?.Version==2)return DocumentWorkingRendererV2.Region(m,d,left,top,width,height,token);\n  prepared??=new Prepared(m,d,token);d=prepared.Definition;');s=s.replace('  var prepared=new Prepared(m,d,token);d=prepared.Definition;var size=Size(m,d);','  if(d.ColorState?.Version==2)return DocumentWorkingRendererV2.Preview(m,d,edge,token);\n  var prepared=new Prepared(m,d,token);d=prepared.Definition;var size=Size(m,d);');p.write_text(s,encoding='utf-8')
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/ProfessionalRawPipeline.cs';s=p.read_text(encoding='utf-8');s=s.replace('InstantFilm?.Validate();ColorState?.Validate();','InstantFilm?.Validate();ColorState?.Validate();DocumentWorkingRendererV2.Validate(this);');s=s.replace('master.Image.WorkingColorSpace!="sRGB"||master.Contract.DecodeKey','master.Image.WorkingColorSpace!=(definition.ColorState?.Version==2?DocumentWorkingRendererV2.Space:"sRGB")||master.Contract.DecodeKey');s=s.replace('+ColorState.InputPolicy)', '+ColorState.InputPolicy+":working:"+ColorState.Version+":"+ColorState.Working.Sha256)');p.write_text(s,encoding='utf-8')
# Workflow owns profile-specific output; use independently retained alpha for future canvas.
p=r/'src/RAWSelectionAssistant/Services/DocumentColorWorkflowV1.cs';s=p.read_text(encoding='utf-8');s=s.replace('if(state.Working.Sha256!=cms.StandardProfile("sRGB").Sha256)throw new NotSupportedException("ColorV1 working edits are encoded sRGB; no fake ProPhoto editing");','');s=s.replace('var image=new HighBitDepthImageBuffer(w,h,data,"16","sRGB",orientation);','var image=new HighBitDepthImageBuffer(w,h,data,"16",state.Version==2?DocumentWorkingRendererV2.Space:"sRGB",orientation);');
a=s.index(' public static async Task<ProfessionalOutputInspection> WriteAsync');s=s[:a]+'''
 public static DocumentRenderResultV1 RenderResult(ProfessionalRawMaster master,ProfessionalRawDefinition definition,Guid? editVersionId,CancellationToken token=default)
 {
  var state=definition.ColorState!.Validate();var size=ProfessionalRawPipeline.OutputSize(master,definition);
  var pixels=ProfessionalRawPipeline.RenderRegion(master,definition,0,0,size.Width,size.Height,token);
  return new(pixels,state.Working,editVersionId,System.Text.Json.JsonSerializer.Serialize(definition.Geometry));
 }
 public static async Task<DocumentRenderResultV1> ReadIndependentAlphaAsync(string file,RgbIccIdentityV1 input,RgbIccIdentityV1 working,Guid? version,CancellationToken token=default)
 {
  return await Task.Run(()=>{using var stream=File.OpenRead(file);var frame=BitmapDecoder.Create(stream,BitmapCreateOptions.PreservePixelFormat|BitmapCreateOptions.IgnoreColorProfile,BitmapCacheOption.OnLoad).Frames[0];int w=frame.PixelWidth,h=frame.PixelHeight;var rgba=new FormatConvertedBitmap(frame,PixelFormats.Rgba64,null,0);var words=new ushort[w*h*4];rgba.CopyPixels(words,w*8,0);var rgb=new float[w*h*3];var alpha=new float[w*h];for(int i=0;i<alpha.Length;i++){token.ThrowIfCancellationRequested();alpha[i]=words[i*4+3]/65535f;for(int c=0;c<3;c++)rgb[i*3+c]=words[i*4+c]/65535f;}using var cms=new LcmsRgbEngine();using var t=cms.CreateTransform(input,working);return new DocumentRenderResultV1(new(w,h,t.Convert(rgb,token),"32f",working.Label),working,version,"SourceOrientation",alpha);},token);
 }
'''+s[a:];# V2 no silent alpha flatten; keep V1 compatibility documented
s=s.replace('double alpha=row[x*4+3]/65535d;for(int c=0;c<3;c++)data', 'double alpha=row[x*4+3]/65535d;if(state.Version==2&&alpha<1)throw new NotSupportedException("V2照片编辑需要不透明输入；透明素材使用独立Alpha合同，未静默压白。");for(int c=0;c<3;c++)data');p.write_text(s,encoding='utf-8')
# UI new explicit work variant with guard; normal V1 unaffected.
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.ColorManagement.cs';s=p.read_text(encoding='utf-8');s=s.replace('public async Task CreateManagedColorVariantAsync(bool assign=false)','public async Task CreateManagedColorVariantAsync(bool assign=false,bool linearWide=false)');s=s.replace('cms.StandardProfile("sRGB"),cms.StandardProfile(ManagedOutputSpace),input.Item2)', 'cms.StandardProfile(linearWide?"LinearProPhotoD50V2":"sRGB"),cms.StandardProfile(ManagedOutputSpace),input.Item2,Version:linearWide?2:1)');s=s.replace('→ 编辑 sRGB → 输出','→ 编辑 {(s.Version==2?"线性ProPhoto D50·V2仅曝光":"encoded sRGB·V1")} → 输出');p.write_text(s,encoding='utf-8')
p=r/'src/RAWSelectionAssistant/Views/PhotoGradePageView.ColorManagement.cs';s=p.read_text(encoding='utf-8');marker='  var update=new Button';i=s.index(marker);s=s[:i]+'''  var wide=new Button{Content="新建线性ProPhoto D50 V2（仅曝光/蒙版/几何）",ToolTip="显式float32工作空间；其他旧sRGB工具拒绝，不暗迁当前变体"};wide.Click+=async(_,_)=>{wide.IsEnabled=false;try{await vm.CreateManagedColorVariantAsync(linearWide:true);}finally{wide.IsEnabled=true;}};panel.Children.Add(wide);
'''+s[i:];p.write_text(s,encoding='utf-8')
# Wide path must never use old fast-base SDR; choose fine V2 preview instead.
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.RawLocal.cs';s=p.read_text(encoding='utf-8');s=s.replace('var key=FastBaseKey(frame.Master,frame.Definition);','if(frame.Definition.ColorState?.Version==2){using var wide=await Task.Run(()=>DocumentWorkingRendererV2.Preview(frame.Master,frame.Definition,800,token),token);return RawDisplayBitmapAdapter.ToBitmap(wide.ToVisualRgb24(token));}\n   var key=FastBaseKey(frame.Master,frame.Definition);');p.write_text(s,encoding='utf-8')