from pathlib import Path
import re,zipfile,subprocess,json,math,hashlib,numpy as np
out=Path('N:/pixart/Guangjing-R53-Home-20261027-CmsClosure');ref=out/'reference';compiler=out/'research-compiler'
if not compiler.exists():
 with zipfile.ZipFile('N:/pixart/Guangjing-R53-Home-20261027/tcc-reference.zip') as z:z.extractall(compiler)
src=(ref/'pdfium-blend.cpp').read_text(encoding='utf-8-sig');array=re.search(r'kColorSqrt = \{(.*?)\};',src,re.S)[1]
fn=src[src.index('int Blend('):src.rindex('}  // namespace fxge')];fn=re.sub(r'  DCHECK_.*?;','',fn);fn=fn.replace('BlendMode blend_mode','int blend_mode').replace('BlendMode::','').replace('std::abs','abs').replace('std::min','min').replace('std::max','max').replace('kColorSqrt[static_cast<uint8_t>(back_color)]','kColorSqrt[back_color]').replace('NOTREACHED();','return 0;')
names=list(dict.fromkeys(re.findall(r'case (k\w+):',fn)))
# Directly compile the fixed PDFium integer branch body; no product source involved.
code='#include <stdio.h>\n#define min(a,b) ((a)<(b)?(a):(b))\n#define max(a,b) ((a)>(b)?(a):(b))\nenum {'+','.join(names)+'};\nstatic unsigned char kColorSqrt[256]={'+array+'};\n'+fn+'\nint main(){int mode,a,b;while(scanf("%d %d %d",&mode,&a,&b)==3)printf("%d\\n",Blend(mode,a,b));return 0;}';(ref/'pdfium-adapter.c').write_text(code);subprocess.run([str(compiler/'tcc/tcc.exe'),str(ref/'pdfium-adapter.c'),'-o',str(ref/'pdfium-adapter.exe')],check=True,capture_output=True)
rows=json.loads((out/'sealed-final/samples/blend/SAMPLES.json').read_text());calls=[];indices=[]
for i,row in enumerate(rows):
 if row['mode'] not in [3,4]:continue
 for c in range(3):calls.append(f"{names.index('kOverlay' if row['mode']==3 else 'kSoftLight')} {round(row['a'][c]*255)} {round(row['b'][c]*255)}");indices.append((i,c))
p=subprocess.run([str(ref/'pdfium-adapter.exe')],input='\n'.join(calls)+'\n',text=True,capture_output=True,check=True);errors={}
for (i,c),value in zip(indices,p.stdout.split()):errors.setdefault(str(rows[i]['mode']),[]).append(abs(rows[i]['result'][c]*255-int(value)))
# Independently evaluated PhotoCraft pinned float formula, not compiled full Rust renderer.
def lum(c):return np.float32(.3)*c[0]+np.float32(.59)*c[1]+np.float32(.11)*c[2]
def setlum(c,l):
 c=c+np.float32(l-lum(c));l=lum(c);n=min(c);x=max(c)
 if n<0:c=l+(c-l)*l/(l-n) if l>0 and l-n>0 else np.full(3,l)
 if x>1:c=l+(c-l)*(1-l)/(x-l) if l<1 and x-l>0 else np.full(3,l)
 return c
stats={}
for row in rows:
 a=np.array(row['a'],np.float32);b=np.array(row['b'],np.float32);mode=row['mode']
 if mode==3:v=np.where(a<=.5,2*a*b,1-2*(1-a)*(1-b))
 elif mode==4:v=np.where(b<=.5,2*a*b+a*a*(1-2*b),2*a*(1-b)+np.where(a<=.25,((16*a-12)*a+4)*a,np.sqrt(a))*(2*b-1))
 else:v=setlum(b,lum(a)) if mode==7 else setlum(a,lum(b))
 stats.setdefault(str(mode),[]).extend(abs(np.array(row['result'])-v))
report=dict(photocraftCommit='7ac7b8b106acccf6826d45ed5c9e481dfe341035',photocraftEvaluation='independent numpy float32 scalar port of pinned formula, not full Rust binary',photocraft={k:dict(maxFloat=float(max(v)),meanFloat=float(np.mean(v)))for k,v in stats.items()},pdfiumCommit='a84323421e94f484faca52dd9d027934eba42ab8',pdfiumEvaluation='actual fixed Blend integer branch compiled with TCC external isolated research adapter; 8bit quantization',pdfium={k:dict(max8=max(v),mean8=sum(v)/len(v))for k,v in errors.items()},scope='Adjust-result encoded sRGB, not pixel-layer alpha/HDR; PDF integer quantization measured, not exact float equality')
(out/'BLEND_REFERENCE.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))