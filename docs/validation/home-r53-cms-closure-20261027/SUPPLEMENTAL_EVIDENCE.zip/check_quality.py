from pathlib import Path
import json
p=Path('N:/pixart/Guangjing-R53-Home-20261027-CmsClosure/jpeg-after/PROBE.json');a=json.loads(p.read_text());print([(x['kind'],x['space'],x['errors'])for x in a])