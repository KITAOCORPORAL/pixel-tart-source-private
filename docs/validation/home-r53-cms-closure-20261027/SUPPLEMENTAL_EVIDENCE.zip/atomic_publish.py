from pathlib import Path
r=Path('N:/pixart/guangjing-r53-stage-b-20261027');p=r/'src/RAWSelectionAssistant/Services/Publishing/WpfPublishingRenderer.cs';s=p.read_text(encoding='utf-8');old='''            if(File.Exists(destinationPath))throw new IOException("出版目的已存在，未覆盖。");
            try { await Task.Run(() => Render(sourcePath, destinationPath, options, cancellationToken), cancellationToken); }
            catch { if(File.Exists(destinationPath))File.Delete(destinationPath); throw; }''';new='''            if(File.Exists(destinationPath))throw new IOException("出版目的已存在，未覆盖。");
            var ownStage=destinationPath+".render-"+Guid.NewGuid().ToString("N");
            try { await Task.Run(() => Render(sourcePath, ownStage, options, cancellationToken), cancellationToken); cancellationToken.ThrowIfCancellationRequested(); File.Move(ownStage,destinationPath,false); }
            finally { if(File.Exists(ownStage))File.Delete(ownStage); }''';assert old in s;s=s.replace(old,new);p.write_text(s,encoding='utf-8')
p=r/'src/RAWSelectionAssistant.Core/Services/Color/ControlledIcc/DocumentRenderResultV1.cs';s=p.read_text(encoding='utf-8').replace('public string PixelFormat => "RGB-float32";','public string PixelFormat => "RGB-float32";\n public int BitsPerChannel => 32;\n public string Precision => "IEEE754-float32";');p.write_text(s,encoding='utf-8')
p=r/'src/RAWSelectionAssistant/Services/DocumentColorWorkflowV1.cs';s=p.read_text(encoding='utf-8');s=s.replace('bool jpeg=format==StudioExportFormat.Jpeg;var image=', 'bool jpeg=format==StudioExportFormat.Jpeg;if(jpeg)ValidateJpeg444(file);var image=');p.write_text(s,encoding='utf-8')
# Explicit UI clone remains a bounded minimum, no broad claim on all tools.
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.ColorManagement.cs';s=p.read_text(encoding='utf-8').replace('$"颜色变体 V1 · {s.InputPolicy}', '$"颜色变体 V{s.Version} · {s.InputPolicy}');p.write_text(s,encoding='utf-8')