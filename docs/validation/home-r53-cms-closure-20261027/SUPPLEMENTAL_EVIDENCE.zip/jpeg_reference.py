from pathlib import Path
from PIL import Image,ImageCms,features
import numpy as np,json
p=Path('N:/pixart/Guangjing-R53-Home-20261027-CmsClosure/jpeg-before');rows=[]
for row in json.loads((p/'PROBE.json').read_text()):
 prefix=p/(row['kind']+'-'+row['space']);rgb=np.frombuffer(prefix.with_suffix('.rgb').read_bytes(),np.uint8).reshape(row['h'],row['w'],3);wic=np.array(Image.open(prefix.with_suffix('.jpg')));image=Image.fromarray(rgb);image.save(str(prefix)+'.pillow.jpg',quality=95,subsampling=0,icc_profile=prefix.with_suffix('.icc').read_bytes());ref=np.array(Image.open(str(prefix)+'.pillow.jpg'))
 def err(a,b):
  d=a.astype(float)-b.astype(float);return dict(mean=float(np.abs(d).mean()),rmse=float(np.sqrt((d*d).mean())),max=float(np.abs(d).max()))
 rows.append(dict(kind=row['kind'],space=row['space'],wicInput=row['errors'],pillowInput=err(rgb,ref),wicPillow=err(wic,ref),samples=Image.open(prefix.with_suffix('.jpg')).layer))
(p/'INDEPENDENT_JPEG.json').write_text(json.dumps(dict(pillow=Image.__version__,libjpeg=features.version('jpg'),rows=rows),indent=2));print(json.dumps(rows[:4],indent=2))