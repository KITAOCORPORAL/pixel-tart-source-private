from pathlib import Path
import subprocess,time,os,json,hashlib,shutil
r=Path('N:/pixart/guangjing-r53-stage-b-20261027');o=Path('N:/pixart/Guangjing-R53-Home-20261027-CmsClosure');f=o/'final-r3';f.mkdir();dotnet=r'C:\Program Files\dotnet\dotnet.exe';sha=subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD'],text=True).strip();props=['-p:WholeAppDiagnosticBuild=true','-p:PhotographerTrialBuild=false','-p:SourceRevisionId='+sha,'-p:IncludeSourceRevisionInInformationalVersion=true']
def h(p):
 with p.open('rb') as b:return hashlib.file_digest(b,'sha256').hexdigest()
for label,args in [('publish',['publish','src/RAWSelectionAssistant/RAWSelectionAssistant.csproj','-c','Release','-r','win-x64','--self-contained','true','-o',str(f/'app')]),('core',['build','tests/RAWSelectionAssistant.Tests/RAWSelectionAssistant.Tests.csproj','-c','Release']),('wpf',['build','tests/RAWSelectionAssistant.WpfTests/RAWSelectionAssistant.WpfTests.csproj','-c','Release','-p:Platform=x64'])]:
 cmd=[dotnet]+args+props+['--disable-build-servers','-m:1','-nr:false'];start=time.time()
 with (f/(label+'-build.log')).open('wb') as log:p=subprocess.Popen(cmd,cwd=r,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW);code=p.wait()
 (f/(label+'-build.json')).write_text(json.dumps(dict(command=cmd,pid=p.pid,exitCode=code,sourceSha=sha,startEpoch=start,endEpoch=time.time()),indent=2));print(label,code,flush=True)
 if code:raise SystemExit(code)
assemblies={'core':r/'tests/RAWSelectionAssistant.Tests/bin/Release/net10.0/RAWSelectionAssistant.Tests.dll','wpf':r/'tests/RAWSelectionAssistant.WpfTests/bin/x64/Release/net10.0-windows10.0.19041.0/RAWSelectionAssistant.WpfTests.dll'};bindings=[]
for name,a in assemblies.items():
 for p in (f/'app').glob('*.dll'):
  dest=a.parent/p.name
  if dest.exists():shutil.copy2(p,dest);assert h(dest)==h(p);bindings.append(dict(host=name,published=str(p),test=str(dest),sha256=h(p)))
(f/'bindings.json').write_text(json.dumps(dict(sourceSha=sha,bindings=bindings,testAssemblies=[dict(path=str(a),sha256=h(a))for a in assemblies.values()]),indent=2))
core=['R53CmsClosureCoreTests','ControlledIccTests','ProfessionalRawPipelineTests','ProfessionalRawTiffTests','ProfessionalPipelineNoOpPrecisionTests','R53LocalCompositeTests','R53ProfessionalLocalTests','ColorStudioSessionStateTests','ColorStudioToolProcessorTests','StudioVersion','PublishingCoreTests','PublishingTiffAndXmpBatchTests','BatchEightInstantFilmTests','BatchNineInstantFilmTests']
wpf=['R53CmsClosureTests','R53DocumentColorTests','LightPrintR3Tests','PhotoGradePageV1Tests','BatchNinePublishingTests','BatchEightPublishingOracleTests','PublishingRenderingTests','WholeAppDiagnosticPackageTests','TutorialRetirementProductTests.RealShell','TutorialRetirementProductTests.ProductXaml']
for name,names in [('core',core),('wpf',wpf)]:
 folder=f/('tests-'+name);folder.mkdir();tmp=folder/'temp';tmp.mkdir();env=os.environ.copy();env.update(KITAO_TEST_RESOURCE_ROOT=str(r),KITAO_CMS_CLOSURE=str(f/'samples'),KITAO_HOME_CMS=str(f/'cms'),KITAO_TEST_EVIDENCE_ROOT=str(f/'visual'),KITAO_PHOTO_PAGE_AUTHORIZED_MANIFEST=str(o/'authorized-photo-page-manifest.json'),PIXEL_TART_ISOLATED_RUNTIME='1',PIXEL_TART_ISOLATED_RUNTIME_ROOT=str(f/'test-runtime'),TEMP=str(tmp),TMP=str(tmp))
 filter='('+'|'.join('FullyQualifiedName~'+x for x in names)+')&FullyQualifiedName!~ManagedFilmPersistentSampleReopensInIndependentTestProcess';cmd=[dotnet,'vstest',str(assemblies[name]),'/TestCaseFilter:'+filter,'/Logger:trx;LogFileName=results.trx','/ResultsDirectory:'+str(folder)];start=time.time()
 with (folder/'stdout.log').open('wb') as log:
  p=subprocess.Popen(cmd,cwd=r,env=env,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
  try:code=p.wait(timeout=300)
  except subprocess.TimeoutExpired:subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],stdout=log,stderr=log);code=-999
 (folder/'process.json').write_text(json.dumps(dict(command=cmd,pid=p.pid,exitCode=code,sourceSha=sha,startEpoch=start,endEpoch=time.time()),indent=2));print('test-'+name,code,flush=True)
# A true fresh testhost reopens persistent flow sample instead of reconstructing the same VM.
folder=f/'process-reopen';folder.mkdir();env=os.environ.copy();env.update(KITAO_TEST_RESOURCE_ROOT=str(r),KITAO_CMS_CLOSURE=str(f/'samples'),KITAO_CMS_REOPEN_SESSION=str(f/'samples/flow/workflow.ptstudio.json'),PIXEL_TART_ISOLATED_RUNTIME='1',PIXEL_TART_ISOLATED_RUNTIME_ROOT=str(f/'test-runtime-reopened'))
cmd=[dotnet,'vstest',str(assemblies['wpf']),'/TestCaseFilter:FullyQualifiedName~ManagedFilmPersistentSampleReopensInIndependentTestProcess','/Logger:trx;LogFileName=results.trx','/ResultsDirectory:'+str(folder)];start=time.time()
with (folder/'stdout.log').open('wb') as log:p=subprocess.Popen(cmd,cwd=r,env=env,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW);code=p.wait(timeout=180)
(folder/'process.json').write_text(json.dumps(dict(command=cmd,pid=p.pid,exitCode=code,sourceSha=sha,startEpoch=start,endEpoch=time.time()),indent=2));print('process-reopen',code,flush=True)