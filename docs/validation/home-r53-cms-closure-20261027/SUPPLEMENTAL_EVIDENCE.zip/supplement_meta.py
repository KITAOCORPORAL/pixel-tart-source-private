from pathlib import Path
import json,hashlib,zipfile,shutil,xml.etree.ElementTree as E,subprocess
r=Path('N:/pixart/guangjing-r53-stage-b-20261027');o=Path('N:/pixart/Guangjing-R53-Home-20261027-CmsClosure');v=r/'docs/validation/home-r53-cms-closure-20261027';pkg=o/'Guangjing-R53-CMS-Closure-Final-Diagnostic-win-x64';ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def js(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
summary=json.loads((v/'TEST_SUMMARY.json').read_text());doc=E.parse(o/'alpha-final/results.trx');tests=doc.findall('t:Results/t:UnitTestResult',ns);summary['authoritative']['alphaSupplement']=dict(passed=1,failed=0,notRun=0,total=1,process=json.loads((o/'alpha-final/process.json').read_text()));summary['unique']='Core68; WPF57 unique (55main +1 fresh-process-reopen test +1 independent alpha supplement), repeats not accumulated';assert all(x.get('outcome')=='Passed'for x in tests);js(v/'TEST_SUMMARY.json',summary)
shutil.copy2(o/'alpha-final/bindings.json',v/'ALPHA_SUPPLEMENT_BINDINGS.json');shutil.copy2(o/'alpha-final/samples/blend-alpha/RESULT.json',v/'BLEND_ALPHA.json')
js(v/'SOURCE_EQUIVALENCE.json',dict(binarySourceSha='b843670653dcb1899f77b873e31a11455d754f36',supplementTestSha='303b562e1d4aeadf66a2b609ac8e3bdc8e7afd3b',srcDiff=subprocess.check_output(['git','-C',str(r),'diff','--name-status','b8436706','303b562e','--','src'],text=True).splitlines(),sourceUnchanged=True,supplement='alpha edge/PNG reopen actual final published DLL binding; separate test assembly hash retained'))
# Complete test evidence after raw main archive, no runtime/private photo or research binaries.
paths=[]
for folder in [o/'alpha-final',o/'publish-numeric-tests',o/'supplemental-final',o/'user-total-r2-tests']:
 for p in folder.rglob('*'):
  if p.is_file() and p.suffix in ['.json','.log','.trx'] and not any(x=='runtime'for x in p.relative_to(folder).parts):paths.append(p)
paths.extend(p for p in o.glob('*.py') if p.name not in [x.name for x in paths])
for name in ['build-alpha-blends.log','build-user-total-r2.log','build-publish-numeric.log','wic-linear-reference.log','JPEG_INDEPENDENT_FINAL.json','BLEND_REFERENCE.json','LINEAR_WORKING_WIC.json']:
 p=o/name
 if p.exists():paths.append(p)
paths=list(dict.fromkeys(paths))
with zipfile.ZipFile(v/'SUPPLEMENTAL_EVIDENCE.zip','x',zipfile.ZIP_DEFLATED,6)as z:
 for p in paths:z.write(p,str(p.relative_to(o)).replace('\\','/'))
with zipfile.ZipFile(v/'SUPPLEMENTAL_EVIDENCE.zip')as z:
 assert z.testzip() is None
 for p in paths:assert hashlib.sha256(z.read(str(p.relative_to(o)).replace('\\','/'))).hexdigest()==h(p)
js(v/'SUPPLEMENTAL_MANIFEST.json',dict(path='SUPPLEMENTAL_EVIDENCE.zip',sha256=h(v/'SUPPLEMENTAL_EVIDENCE.zip'),bytes=(v/'SUPPLEMENTAL_EVIDENCE.zip').stat().st_size,readback=True,files=[dict(path=str(p.relative_to(o)),sha256=h(p))for p in paths]))
for p in [v/'FINAL_REPORT.md',r/'HANDOFF.MD',pkg/'README-DIAGNOSTIC.md']:
 s=p.read_text(encoding='utf-8');s=s.replace('WPF受影响回归|55|0|0|','WPF主受影响回归|55|0|0|\n|透明边缘独立补充|1|0|0|');s=s.replace('WPF55PASS/0FAIL/0NOT_RUN，另独立新进程重开1PASS', 'WPF主55PASS＋透明边缘补充1PASS/0FAIL/0NOT_RUN，另独立新进程重开1PASS');s=s.replace('原像素未改。**没有真的填满磁盘', '原像素未改。透明边缘新增四模式Alpha0/64/128/255与PNG重开独立补测PASS，颜色处理不再乘第二次源Alpha。**没有真的填满磁盘');p.write_text(s,encoding='utf-8')
# Re-evaluate prepared sample source equivalence/hash, no natural photograph in deliverable.
for p in (v/'images').glob('*.png'):assert p.stat().st_size>0
print('supplement recorded; tests68 +55 +1reopen +1alpha')