from pathlib import Path
import json,hashlib,subprocess,zipfile,shutil,xml.etree.ElementTree as E
r=Path('N:/pixart/guangjing-r53-stage-b-20261027');o=Path('N:/pixart/Guangjing-R53-Home-20261027-CmsClosure');v=r/'docs/validation/home-r53-cms-closure-20261027';f=o/'sealed-final';pkg=o/'Guangjing-R53-CMS-Closure-Final-Diagnostic-win-x64';sha='b843670653dcb1899f77b873e31a11455d754f36';base='047e51bf7ad156aaf94427cad93dd45380b6fbd1';ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def js(p,data):p.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
def h(p):
 with p.open('rb') as b:return hashlib.file_digest(b,'sha256').hexdigest()
summary={};nonpass=[]
for label,folder in [('core',f/'tests-core'),('wpf',f/'tests-wpf'),('processReopen',f/'process-reopen')]:
 doc=E.parse(folder/'results.trx');tests=doc.findall('t:Results/t:UnitTestResult',ns);summary[label]=dict(passed=sum(x.get('outcome')=='Passed' for x in tests),failed=sum(x.get('outcome')=='Failed' for x in tests),notRun=sum(x.get('outcome')=='NotExecuted' for x in tests),total=len(tests),process=json.loads((folder/'process.json').read_text()))
 for x in tests:
  if x.get('outcome')!='Passed':nonpass.append(dict(host=label,name=x.get('testName'),outcome=x.get('outcome')))
js(v/'TEST_SUMMARY.json',dict(sourceSha=sha,authoritative=summary,unique='Core68 + WPF56 (53+2 new closure tests now 55 plus1 independent process test); no adding repeated historic runs',scope='Bounded affected regression, not whole product release/native mouse'))
js(v/'NONPASS.json',dict(currentSelected=nonpass,priorUnrelatedRetained=['TwentyFourMpMultilayerLongStrokeActualRenderAndExportMeasurement','LargeSourceLongStrokeOverlaySamplingMeasurement','TwoPinnedNativeReferenceKernelsRecordNumericalMatrix (historical full gate not rerun; new blend2actual kernels separate)','CreateDistinctNativeSyntheticPackages'],relevantPriorAuthorizedPage='Executed using exact prior authorized Canon derivative manifest; PASS in current WPF',nativePointer='NOT_RUN user prohibition; no Computer Use/WebView/CDP enabled',physicalMonitorAcmHdrMultiscreen='NOT_RUN',realDiskFull='NOT_RUN physical disk not filled; fault injection0x80070070 tested',fullResolutionExportPerformance='NOT_MEASURED_THIS_BATCH;512x342 derivative and64x48 synthetic only',allCameraCalibration=False))
shutil.copy2(f/'bindings.json',v/'COMPONENT_BINDINGS.json');js(v/'BUILD.json',{key:json.loads((f/(key+'-build.json')).read_text())for key in ['publish','core','wpf']})
js(v/'PRODUCT.json',dict(baseline=base,previousProduct='b6eaa32e08bb37d79dcdfde7db17613a1558f5c6',sourceSha=sha,branch='home/r53-stage-b-20261027',worktree=str(r),delivery=str(pkg),sdk='10.0.401',diagnosticOnly=True,isInstaller=False,clientDate='2026-10-27',clientTimezone='Asia/Shanghai',hostTimezone='China Standard Time',rawUtcEpochRetained=True,scope='Product implementation source fixed; final evidence HEAD later, see push receipt'))
js(v/'CHANGED_FILES.json',dict(base=base,sourceSha=sha,files=subprocess.check_output(['git','-C',str(r),'diff','--name-status',base,sha],text=True).splitlines(),commits=subprocess.check_output(['git','-C',str(r),'log','--format=%H %s',base+'..'+sha],text=True).splitlines()))
for src,name in [(o/'JPEG_INDEPENDENT_FINAL.json','JPEG_INDEPENDENT.json'),(o/'BLEND_REFERENCE.json','BLEND_REFERENCE.json'),(o/'LINEAR_WORKING_WIC.json','LINEAR_WORKING_WIC.json'),(f/'samples/user-export/RESULT.json','USER_EXPORT_AND_GAMUT.json'),(f/'samples/natural/RESULT.json','EXPORT_PERFORMANCE.json'),(f/'samples/managed/RESULT.json','LOSSLESS_AND_OUTPUT_PROFILES.json'),(f/'samples/wide-boundary/RESULT.json','WIDE_GAMUT_BOUNDARIES.json'),(f/'samples/flow/RESULT.json','WORKFLOW.json'),(f/'samples/r3/RESULT.json','R3_WORKFLOW.json'),(f/'samples/service-flow/RESULT.json','PUBLISHING_OUTLETS.json'),(f/'samples/process-reopen/RESULT.json','NEW_PROCESS_REOPEN.json'),(f/'samples/recovery/RESULT.json','FAILURE_RECOVERY.json'),(f/'samples/publish-numeric/RESULT.json','PUBLISHING_NUMERICAL.json'),(o/'authorized-photo-page-manifest.json','AUTHORIZED_DERIVATIVE_MANIFEST.json'),(f/'visual/AUTHORIZED_PAGE.json','AUTHORIZED_PAGE_RESULT.json')]:shutil.copy2(src,v/name)
# Sample script preserves every field except known supplied image path.
checks=[]
for folder,name in [('flow','film-current-edits'),('wide-boundary','wide-linear-v2')]:
 project='workflow.ptstudio.json' if folder=='flow' else 'wide.ptstudio.json';a=json.loads((f/'samples'/folder/project).read_text());b=json.loads((o/'prepared-sealed-synthetic'/name/project).read_text());a['targets'][0]['path']=b['targets'][0]['path'];assert a==b and Path(b['targets'][0]['path']).is_file();checks.append(dict(project=name,onlyPathChanged=True))
js(v/'SAMPLE_PREPARATION.json',dict(requires='PowerShell7.5+ -DateKind String',executed=True,checks=checks,privateDirectoriesScanned=False,receiptRewritten=False))
app=pkg/'app';deps=json.loads((app/'KitaoPhotoSelector.deps.json').read_text());assets=[]
for target,libs in deps['targets'].items():
 for lib,entry in libs.items():
  for kind in ['runtime','native','resources']:
   for path in entry.get(kind,{}):
    p=app/path
    if not p.exists() and kind!='resources':p=app/Path(path).name
    assets.append(dict(library=lib,path=path,kind=kind,present=p.is_file()))
assert all(x['present'] for x in assets);js(v/'DEPENDENCIES.json',assets)
files=[dict(path=str(p.relative_to(app)).replace('\\','/'),bytes=p.stat().st_size,sha256=h(p))for p in sorted(app.rglob('*'))if p.is_file()];js(v/'APP_FILES.json',dict(sourceSha=sha,count=len(files),files=files))
# Raw generated evidence only; no private natural image data, research binaries/source, design resources or user DB.
raw=[]
for p in sorted(o.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(o);parts=rel.parts
 if any(x in ['app','runtime','test-runtime','temp','research-compiler','reference','wic-linear-reference','native-runtime','native-sealed-runtime'] or 'Diagnostic-win-x64' in x for x in parts):continue
 if p.suffix.lower() not in ['.log','.trx','.json','.py','.ps1'] or p.stat().st_size>8*1024*1024:continue
 if any(x.startswith('runtime-') for x in parts):continue
 raw.append((p,str(rel).replace('\\','/')))
with zipfile.ZipFile(v/'RAW_EVIDENCE.zip','x',zipfile.ZIP_DEFLATED,6) as z:
 for p,name in raw:z.write(p,name)
with zipfile.ZipFile(v/'RAW_EVIDENCE.zip')as z:
 assert z.testzip() is None
 for p,name in raw:assert hashlib.sha256(z.read(name)).hexdigest()==h(p)
js(v/'RAW_MANIFEST.json',dict(path='RAW_EVIDENCE.zip',sha256=h(v/'RAW_EVIDENCE.zip'),bytes=(v/'RAW_EVIDENCE.zip').stat().st_size,readback=True,files=[dict(path=n,bytes=p.stat().st_size,sha256=h(p))for p,n in raw]))
# Keep original failed JPEG samples and all final synthetic independent controls, no full natural files.
with zipfile.ZipFile(v/'JPEG_SAMPLES.zip','x',zipfile.ZIP_DEFLATED,6) as z:
 for folder,prefix in [(o/'jpeg-before','before'),(f/'samples','final')]:
  for p in folder.iterdir():
   if p.is_file() and p.suffix in ['.jpg','.icc','.rgb','.json']:z.write(p,prefix+'/'+p.name)
with zipfile.ZipFile(v/'JPEG_SAMPLES.zip')as z:assert z.testzip() is None
js(v/'JPEG_SAMPLES_MANIFEST.json',dict(sha256=h(v/'JPEG_SAMPLES.zip'),bytes=(v/'JPEG_SAMPLES.zip').stat().st_size,scope='Original WPF auto-profile wrong-comparison samples retained with raw expected values; final synthetic codec controls; no natural photograph distributed'))
# Offscreen evidence explicitly labeled; not desktop capture.
(v/'images').mkdir()
for p in (f/'samples/visual').glob('*-OFFSCREEN.png'):shutil.copy2(p,v/'images'/p.name)
shutil.copy2(f/'samples/visual/PROVENANCE.json',v/'VISUAL_PROVENANCE.json')
# development tests retained as failures, never sum a retry into authority.
runs=[]
for p in o.rglob('*.trx'):
 if any('Diagnostic-win-x64' in x for x in p.parts):continue
 try:
  doc=E.parse(p);tests=doc.findall('t:Results/t:UnitTestResult',ns);runs.append(dict(path=str(p.relative_to(o)),sha256=h(p),passed=sum(x.get('outcome')=='Passed'for x in tests),failed=sum(x.get('outcome')=='Failed'for x in tests),notRun=sum(x.get('outcome')=='NotExecuted'for x in tests),failures=[dict(name=x.get('testName'),message=' '.join(t.strip()for t in x.itertext()if t.strip())[:1800])for x in tests if x.get('outcome')=='Failed']))
 except E.ParseError:pass
js(v/'DEVELOPMENT_RUNS.json',runs)
js(v/'JPEG_SUPPORT.json',dict(sourceSha=sha,quality=95,sampling='4:4:4',depth=8,spaces={k:dict(status='ADMITTED_DIAGNOSTIC',default=k=='sRGB',recommendation='Explicit only, not a normal delivery default'if k=='ProPhotoRGB'else 'Actual pixel transform and embedded ICC')for k in ['sRGB','DisplayP3','AdobeRGB-compatible','ProPhotoRGB-compatible']},lossless='PNG16/TIFF16 actual transforms, all four profiles0codes mismatch',errorBudget=dict(MAE8=5,RMSE8=15,changed=False),rootCause='WPF auto ICC interpretation during FormatConvertedBitmap readback; compared interpreted values against output encoding; fixed IgnoreColorProfile in explicit input/raw readback',regressionGuarantee='Not claiming JPEG lossless or all arbitrary high-frequency inputs below budget'))
js(v/'COLOR_BOUNDARIES.json',dict(V1='encoded sRGB float; LCMS input alone retains negative/>1, but legacy tool EncodeGamut/levels/curves clip/compress',V2=dict(space='linear public ROMM/ProPhoto primaries D50',white='xy .3457,.3585',transfer='gamma1',precision='float32',tools=['BasicTone exposure only','Normal opacity and source-coordinate mask','linear-space GeometryV1/V2'],notSupported=['legacy encoded-sRGB WB/curves/levels/colorbalance','HDR photographic blending','LUT/CMYK ICC','full wide-gamut all-tool pipeline'],unknownTools='refuse before save/render',output='direct working→target transform then quantize',preview='linear working result area-average→sRGB display pixels, monitor only afterward',oldDefaultUnchanged=True),alpha='Independent straight alpha result available; new opaque photo action rejects transparent input, no implicit white; legacy stored V1 white policy retained',film='frozen document definition/variant/profile→full result→encoded-sRGB film + paper, not display ICC preview',publishing='already rendered file pixels honor actual embedded ICC→encoded-sRGB float bilinear→WPF8 watermark coverage→targetICC; photo retained float/16, not linear-light watermark claim',monitor='defaultoff SDR explicit path unchanged; WPF/device/systemACM/HDR physical multi-screen NOT_RUN; no calibration claim',CalibrationEligible=False))
js(v/'STAGE_C_STATUS.json',dict(status='PARTIAL_CONTINUED_THIS_BATCH',implemented=['unique grouped paper selector moved to left resource entrance','explicit original/current source with Chinese labels','fixed seed and reroll draft preview','frozen input profile+variant summary after develop','animationoff develop and repeat-click guard','cancel draft and reshoot retain variants'],retained=['V3 emulsion/grain/defects/surface/highlight/double-exposure existing capabilities','paper/image separation','read-only developed recipe'],notCompleted=['licensed real scanned/collaboration frames not distributed','full R3 prototype176 audit not completed','physical pointer/window flow','all authorized full-resolution camera corpus'],notClaimed='prototype175 passed is not WPF product acceptance'))
js(v/'DESKTOP_STATUS.json',dict(native='Full EXE startup+OS empty close identity only',nativeMouseWorkflow='NOT_RUN',toolPolicy='User AGENTS prohibits Computer Use Browser WebView CDP; not reenabled',physicalDisplay='NOT_RUN including ACM/HDR/multi-monitor',automatedWorkflow='Actual product VM/WPF shared pipeline+new testhost reopen hash equal; not native',images='RenderTargetBitmap OFFSCREEN only'))
js(v/'RELEASE_GATE.json',dict(sourceSha=sha,releaseAllowed=False,diagnosticOnly=True,isInstaller=False,calibrationEligible=False,oldTutorialRestored=False,fullAppModulesRetained=True,planning15Retained=True,physicalPointerNotRun=True,fullR53NotComplete=True))
(v/'.gitattributes').write_text('*.json text eol=lf\n*.md text eol=lf\n*.zip -text\n*.png -text\n',encoding='utf-8')
print(json.dumps(dict(core=summary['core']['passed'],wpf=summary['wpf']['passed'],reopen=summary['processReopen']['passed'],bindings=len(json.loads((f/'bindings.json').read_text())['bindings']),assets=len(assets),appFiles=len(files),rawBytes=(v/'RAW_EVIDENCE.zip').stat().st_size),indent=2))