from pathlib import Path
r=Path('N:/pixart/guangjing-r53-stage-b-20261027')
# Raw codes must not be auto-converted by WIC before an explicit LCMS input transform either.
p=r/'src/RAWSelectionAssistant/Services/DocumentColorWorkflowV1.cs';s=p.read_text(encoding='utf-8');s=s.replace('BitmapCreateOptions.PreservePixelFormat,BitmapCacheOption.OnDemand','BitmapCreateOptions.PreservePixelFormat|BitmapCreateOptions.IgnoreColorProfile,BitmapCacheOption.OnDemand');p.write_text(s,encoding='utf-8')
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/InstantInputRecipe.cs';s=p.read_text(encoding='utf-8');s=s.replace('public LegacyRawEditInputContract? LegacyRaw {get;init;}','''public LegacyRawEditInputContract? LegacyRaw {get;init;}
    [System.Text.Json.Serialization.JsonIgnore(Condition=System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    public ProfessionalRawDefinition? ColorDocument {get;init;}''');p.write_text(s,encoding='utf-8')
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/ProfessionalRawPipeline.cs';s=p.read_text(encoding='utf-8');old='else if(input.Version!=1||input.LegacyRaw is not null';new='''else if(input.ColorDocument is{} document){if(input.Version!=3||input.OriginVersionId is null||document.ColorState is null||document.InstantInput is not null||document.InstantFilm is not null||input.Look is not null||input.Stack is not null||input.Film is not null||input.LegacyRaw is not null||input.Mode is not("Original" or "CurrentEdits")||RenderedInputVersion!=2)throw new InvalidDataException("Invalid frozen document input");document.Validate();}
            else if(input.Version!=1||input.LegacyRaw is not null''';assert old in s;s=s.replace(old,new);p.write_text(s,encoding='utf-8')
p=r/'src/RAWSelectionAssistant/Services/RenderedSrgbInput.cs';s=p.read_text(encoding='utf-8');needle='  var input=await Task.Run';i=s.index(needle);s=s[:i]+'''  if(definition.InstantInput?.ColorDocument is{} frozen)
  {
   var input=await DocumentColorWorkflowV1.ReadAsync(path,frozen,token);using var owner=input.Image;
   using var document=DocumentColorWorkflowV1.RenderResult(input,frozen,definition.InstantInput.OriginVersionId,token);document.RequireOpaque();
   using var cms=new RAWSelectionAssistant.Core.Services.Color.ControlledIcc.LcmsRgbEngine();
   using var srgb=document.ConvertTo(cms.StandardProfile("sRGB"),token);
   var pixels=new HighBitDepthImageBuffer(srgb.Pixels.Width,srgb.Pixels.Height,srgb.Pixels.Rgb32.ToArray(),"32f","sRGB",1);
   return new(pixels,input.Contract with{DecodeKey=definition.DecodeKey,OutputSpace="sRGB",Gamma="sRGB",Characterization="Frozen document result converted once to encoded sRGB film domain; no monitor pixels"});
  }
'''+s[i:];p.write_text(s,encoding='utf-8')
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.InstantFilm.cs';s=p.read_text(encoding='utf-8');old='if(target.RawDefinition?.ColorState is not null&&InstantInputMode=="CurrentEdits")throw new NotSupportedException("颜色管理变体的即时胶片当前编辑入口未完成；请选择原图或切回兼容变体，不静默丢弃ICC状态。");';assert old in s;s=s.replace(old,'');needle='            if(InstantEngineVersion=="V3"&&InstantInputMode=="Original"';i=s.index(needle);s=s[:i]+'''            if(previous?.ColorState is not null)
            {
                var frozen=InstantInputMode=="Original"?previous with{LocalEdits=null,Geometry=null}:previous;
                if(frozen.InstantInput is not null)throw new NotSupportedException("Nested document input unsupported");
                basis=InstantFilmJpegInput.Definition with{RenderedInputVersion=2,InstantInput=new InstantInputRecipe(3,InstantInputMode,version){ColorDocument=frozen with{LocalEdits=frozen.LocalEdits?.Freeze()}}};
            }
'''+s[i:];p.write_text(s,encoding='utf-8')
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.LightPrint.cs';s=p.read_text(encoding='utf-8');s=s.replace('if(RawMatchTiff16ProductPipeline.IsRaw(target.Path))master=', 'if(RawMatchTiff16ProductPipeline.IsRaw(target.Path)||definition.InstantInput?.ColorDocument is not null)master=');p.write_text(s,encoding='utf-8')
# Keep re-shoot frozen document input rather than replacing it with current state.
# JPEG enabled output labeling; ProPhoto8 explicit warning, never default.
p=r/'src/RAWSelectionAssistant/Views/DarkroomExportDialog.cs';s=p.read_text(encoding='utf-8-sig').replace('ICC V1：PNG16 / TIFF16；JPEG尚未放行','PNG16 / TIFF16 / JPEG8 · JPEG95/4:4:4；实际目标ICC转换');p.write_text(s,encoding='utf-8')
# Admit existing independently implemented W3C-domain modes after new numerical/roundtrip tests.
p=r/'src/RAWSelectionAssistant/ViewModels/TetherReferenceModeViewModel.LocalMask.cs';s=p.read_text(encoding='utf-8');s=s.replace('StudioLayerBlend.Darken,StudioLayerBlend.Lighten];','StudioLayerBlend.Darken,StudioLayerBlend.Lighten,StudioLayerBlend.Overlay,StudioLayerBlend.SoftLight,StudioLayerBlend.Color,StudioLayerBlend.Luminosity];');p.write_text(s,encoding='utf-8')
# Existing 'not admitted' test is now a positive selected-state check, preserving image parity part.
p=r/'tests/RAWSelectionAssistant.WpfTests/R53DocumentColorTests.cs';s=p.read_text(encoding='utf-8-sig');s=s.replace('Assert.AreEqual(StudioLayerBlend.Darken,vm.Editor.SelectedLayerBlend,"Unadmitted mode cannot bypass menu through setter");','Assert.AreEqual(StudioLayerBlend.Overlay,vm.Editor.SelectedLayerBlend);');old='await Assert.ThrowsExactlyAsync<NotSupportedException>(async()=>await DocumentColorWorkflowV1.WriteAsync(master,d,file,StudioExportFormat.Jpeg,CancellationToken.None));Assert.IsFalse(File.Exists(file));var check=new{state="JPEG_BLOCKED",reason="wide-gamut JPEG readback mean5.4156 max49 beyond prior budget; no silent output"};';new='await DocumentColorWorkflowV1.WriteAsync(master,d,file,StudioExportFormat.Jpeg,CancellationToken.None);var check=DocumentColorWorkflowV1.Inspect(file,master,d,StudioExportFormat.Jpeg);Assert.IsTrue(check.MeanAbsoluteError<=5);';assert old in s;s=s.replace(old,new);p.write_text(s,encoding='utf-8')