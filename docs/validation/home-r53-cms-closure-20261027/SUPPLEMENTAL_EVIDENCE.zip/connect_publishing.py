from pathlib import Path
r=Path('N:/pixart/guangjing-r53-stage-b-20261027');p=r/'src/RAWSelectionAssistant/Services/Publishing/WpfPublishingRenderer.cs';s=p.read_text(encoding='utf-8-sig');s=s.replace('public sealed class WpfPublishingRenderer','public sealed partial class WpfPublishingRenderer')
s=s.replace('    {\n        var isProfessional=false;','    {\n        if(IsManagedDocumentSource(sourcePath)){RenderManagedDocument(sourcePath,destinationPath,options,cancellationToken);return;}\n        var isProfessional=false;')
s=s.replace('''        if(upstream.RecipeSnapshot.RawDefinition.ColorState is not null)throw new NotSupportedException("颜色管理成片保留其实际输出ICC；出版重采样/水印尚未接入该色彩状态，禁止误标sRGB。可直接使用暗室输出成片。");''','')
s=s.replace('''        if(options.OutputFormat==PublishingOutputFormat.Tiff && (!options.EffectiveDimensions.Enabled''','''        if(IsManagedDocumentSource(source))return VerifyManagedDocument(source,output,options,token);
        if(options.OutputFormat==PublishingOutputFormat.Tiff && (!options.EffectiveDimensions.Enabled''',1)
# Render overlay images into explicitly converted sRGB as opposed to their raw tagged codes.
s=s.replace('int outputHeight, CancellationToken cancellationToken)\n    {\n        layer.Validate()', 'int outputHeight, CancellationToken cancellationToken,bool managed=false)\n    {\n        layer.Validate()')
s=s.replace('var adjusted = Adjust(source, layer.EffectiveColorAdjustments, cancellationToken);','''BitmapSource interpreted=source;
            if(managed)
            {
                using var cms=new RAWSelectionAssistant.Core.Services.Color.ControlledIcc.LcmsRgbEngine();
                var inputProfile=DocumentColorWorkflowV1.InspectInput(layer.ImagePath!,cms).Profile;
                using var document=DocumentColorWorkflowV1.ReadIndependentAlphaAsync(layer.ImagePath!,inputProfile,cms.StandardProfile("sRGB"),null,cancellationToken).GetAwaiter().GetResult();
                var values=document.Pixels.Rgb32.Span;var alpha=document.Alpha.Span;var b=new byte[document.Pixels.PixelCount*4];for(int i=0;i<document.Pixels.PixelCount;i++){float a=alpha.IsEmpty?1:alpha[i];for(int c=0;c<3;c++)b[i*4+c]=(byte)Math.Clamp(Math.Round(values[i*3+2-c]*a*255),0,255);b[i*4+3]=(byte)Math.Round(a*255);}
                interpreted=BitmapSource.Create(document.Pixels.Width,document.Pixels.Height,96,96,PixelFormats.Pbgra32,null,b,document.Pixels.Width*4);interpreted.Freeze();
            }
            var adjusted = Adjust(interpreted, layer.EffectiveColorAdjustments, cancellationToken);''')
p.write_text(s,encoding='utf-8')
(r/'src/RAWSelectionAssistant/Services/Publishing/WpfPublishingRenderer.ManagedColor.cs').write_text('''using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using RAWSelectionAssistant.Core.Models;
using RAWSelectionAssistant.Core.Services.Color;
using RAWSelectionAssistant.Core.Services.Color.ControlledIcc;
using RAWSelectionAssistant.Core.Services.Export;
using RAWSelectionAssistant.Core.Services.Projects;
namespace RAWSelectionAssistant.Services.Publishing;
public sealed partial class WpfPublishingRenderer
{
 private static bool IsManagedDocumentSource(string path)
 {
  if(!File.Exists(path+".kitao-export.json"))return false;
  var receipt=JsonSerializer.Deserialize<StudioExportReceipt>(File.ReadAllText(path+".kitao-export.json"));
  return receipt?.RecipeSnapshot?.RawDefinition is{ColorState:not null}||receipt?.RecipeSnapshot?.RawDefinition?.InstantInput?.ColorDocument is not null;
 }
 private static string ManagedTarget(string value)=>value switch{"sRGB"=>"sRGB","DisplayP3" or "Display P3"=>"DisplayP3","AdobeRGB" or "Adobe RGB (1998)"=>"AdobeRGB","ProPhotoRGB"=>"ProPhotoRGB",_=>throw new NotSupportedException("未知出版RGB输出配置")};
 private static void RenderManagedDocument(string source,string destination,PublishingOptions options,CancellationToken token)
 {
  options.Validate();if(File.Exists(destination))throw new IOException("Output exists");if(options.OutputFormat==PublishingOutputFormat.Jpeg&&options.OutputBitDepth!=PublishingOutputBitDepth.Eight)throw new NotSupportedException("JPEG实际仅8位");
  using var cms=new LcmsRgbEngine();var sourceProfile=DocumentColorWorkflowV1.InspectInput(source,cms).Profile;
  // A receipt freezes upstream edit identity; the already exported file's actual ICC describes its pixels.
  var receipt=JsonSerializer.Deserialize<StudioExportReceipt>(File.ReadAllText(source+".kitao-export.json"));
  using var input=DocumentColorWorkflowV1.ReadIndependentAlphaAsync(source,sourceProfile,cms.StandardProfile("sRGB"),receipt?.EditVersionId,token).GetAwaiter().GetResult();input.RequireOpaque();
  var size=OutputSize(input.Pixels.Width,input.Pixels.Height,options.EffectiveDimensions);using var resized=ResizeRgb48(input.Pixels,size.Width,size.Height,token);
  var data=resized.Rgb32.ToArray();
  if(options.WatermarksEnabled&&options.EffectiveWatermarkLayers.Any(x=>x.Enabled))
  {
   // Explicit legacy-compatible encoded-sRGB composition. WPF produces only a watermark coverage/color layer.
   var drawing=new DrawingVisual();using(var dc=drawing.RenderOpen())foreach(var layer in options.EffectiveWatermarkLayers.Where(x=>x.Enabled))DrawLayer(dc,layer,size.Width,size.Height,token,managed:true);
   var overlay=new RenderTargetBitmap(size.Width,size.Height,96,96,PixelFormats.Pbgra32);overlay.Render(drawing);var row=new byte[size.Width*4];
   for(int y=0;y<size.Height;y++){token.ThrowIfCancellationRequested();overlay.CopyPixels(new Int32Rect(0,y,size.Width,1),row,row.Length,0);for(int x=0;x<size.Width;x++){double a=row[x*4+3]/255d;for(int c=0;c<3;c++){int i=(y*size.Width+x)*3+c;data[i]=(float)(data[i]*(1-a)+row[x*4+2-c]/255d);}}}
  }
  var target=cms.StandardProfile(ManagedTarget(options.ColorSpaceProfile));using var result=new DocumentRenderResultV1(new(size.Width,size.Height,data,"32f","sRGB"),cms.StandardProfile("sRGB"),receipt?.EditVersionId,"PublishingEncodedSrgbBilinearV1");using var converted=result.ConvertTo(target,token);var rgb=converted.Pixels.Rgb32.ToArray();
  bool high=options.OutputBitDepth==PublishingOutputBitDepth.Sixteen;
  void Fill(int y,Memory<byte> row){token.ThrowIfCancellationRequested();for(int x=0;x<size.Width*3;x++){ushort code=(ushort)Math.Clamp(Math.Round(rgb[y*size.Width*3+x]*65535),0,65535);System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian(row.Span[(x*2)..],code);}}
  if(options.OutputFormat==PublishingOutputFormat.Tiff)AtomicTiffWriter.WriteRowsAsync(destination,size.Width,size.Height,Fill,new(IccProfile:target.Bytes(),Dpi:options.EffectiveDimensions.Dpi,Software:"光镜 Publishing document float32 → encoded sRGB resample/composite → targetICC"),token).GetAwaiter().GetResult();
  else ProfessionalWicRowEncoder.WriteRows(destination,size.Width,size.Height,options.EffectiveDimensions.JpegQuality,(y,row)=>{var words=new byte[size.Width*6];Fill(y,words);if(options.OutputFormat==PublishingOutputFormat.Png&&high)words.CopyTo(row,0);else for(int x=0;x<size.Width;x++)for(int c=0;c<3;c++){int sourceChannel=2-c;row[x*3+c]=(byte)Math.Round(System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian(words.AsSpan(x*6+sourceChannel*2))/257d);}},token,png:options.OutputFormat==PublishingOutputFormat.Png,highDepth:high,dpi:options.EffectiveDimensions.Dpi,outputProfile:target.Bytes());
 }
 private static string VerifyManagedDocument(string source,string output,PublishingOptions options,CancellationToken token)
 {
  using var stream=File.OpenRead(output);var frame=BitmapDecoder.Create(stream,BitmapCreateOptions.PreservePixelFormat|BitmapCreateOptions.IgnoreColorProfile,BitmapCacheOption.OnLoad).Frames[0];using var cms=new LcmsRgbEngine();var expected=cms.StandardProfile(ManagedTarget(options.ColorSpaceProfile));if(frame.ColorContexts is not{Count:1})throw new InvalidDataException("出版ICC缺失");using var icc=frame.ColorContexts[0].OpenProfileStream();using var bytes=new MemoryStream();icc.CopyTo(bytes);if(!bytes.ToArray().AsSpan().SequenceEqual(expected.Bytes()))throw new InvalidDataException("出版ICC不一致");using var sourceStream=File.OpenRead(source);var input=BitmapDecoder.Create(sourceStream,BitmapCreateOptions.PreservePixelFormat|BitmapCreateOptions.IgnoreColorProfile,BitmapCacheOption.OnLoad).Frames[0];var size=OutputSize(input.PixelWidth,input.PixelHeight,options.EffectiveDimensions);if(frame.PixelWidth!=size.Width||frame.PixelHeight!=size.Height||options.OutputBitDepth==PublishingOutputBitDepth.Sixteen&&frame.Format.BitsPerPixel<48)throw new InvalidDataException("出版尺寸/位深不一致");token.ThrowIfCancellationRequested();return JsonSerializer.Serialize(new{mode="DocumentResultStructureIntegrityV1",frame.PixelWidth,frame.PixelHeight,outputIcc=expected.Sha256,resampling="encoded sRGB float32 bilinear",watermark="encoded sRGB coverage compositing",secondRender=false});
 }
}
''',encoding='utf-8')