from pathlib import Path
r=Path('N:/pixart/guangjing-r53-stage-b-20261027')
p=r/'src/RAWSelectionAssistant/Services/DocumentColorWorkflowV1.cs';s=p.read_text(encoding='utf-8');marker=' public static async Task<DocumentRenderResultV1> ReadIndependentAlphaAsync';i=s.index(marker);s=s[:i]+''' public static async Task RequireOpaqueInputAsync(string file,CancellationToken token=default)
 {
  await Task.Run(()=>{using var stream=File.OpenRead(file);var frame=BitmapDecoder.Create(stream,BitmapCreateOptions.PreservePixelFormat|BitmapCreateOptions.IgnoreColorProfile,BitmapCacheOption.OnDemand).Frames[0];using var reservation=StudioGlobalResources.ReserveWork(checked((long)frame.PixelWidth*8));var rgba=new FormatConvertedBitmap(frame,PixelFormats.Rgba64,null,0);var row=new ushort[frame.PixelWidth*4];for(int y=0;y<frame.PixelHeight;y++){token.ThrowIfCancellationRequested();rgba.CopyPixels(new System.Windows.Int32Rect(0,y,frame.PixelWidth,1),row,frame.PixelWidth*8,0);for(int x=0;x<frame.PixelWidth;x++)if(row[x*4+3]!=65535)throw new NotSupportedException("透明素材需要独立Alpha出口或明确背景；不创建白底照片变体。");}},token);
 }
'''+s[i:];# bounded allocations, no new cache
s=s.replace('int w=frame.PixelWidth,h=frame.PixelHeight;var rgba=', 'int w=frame.PixelWidth,h=frame.PixelHeight;using var reservation=StudioGlobalResources.ReserveWork(checked((long)w*h*48));var rgba=');p.write_text(s,encoding='utf-8')
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.ColorManagement.cs';s=p.read_text(encoding='utf-8').replace('using(var alphaCheck=await DocumentColorWorkflowV1.ReadIndependentAlphaAsync(target.Path,input.Item1,cms.StandardProfile("sRGB"),target.ActiveEditVersionId))alphaCheck.RequireOpaque();','await DocumentColorWorkflowV1.RequireOpaqueInputAsync(target.Path);');p.write_text(s,encoding='utf-8')
# Avoid default converter creating visible enum labels on the new source selector.
# Validate source identity before accepting a current-input result; old doc remains frozen in its own version.
p=r/'src/RAWSelectionAssistant/Core*'