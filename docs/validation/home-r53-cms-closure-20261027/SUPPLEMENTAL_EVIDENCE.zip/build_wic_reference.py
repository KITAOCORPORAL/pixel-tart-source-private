from pathlib import Path
import json,base64
r=Path('N:/pixart/Guangjing-R53-Home-20261027-CmsClosure');s=json.loads((r/'final-r3/samples/wide-boundary/wide.ptstudio.json').read_text());state=s['targets'][0]['rawDefinition']['colorState'];p=r/'wic-linear-reference'
for name,key in [('input','input'),('working','working')]: (p/(name+'.icc')).write_bytes(base64.b64decode(state[key]['bytesBase64']))
(p/'WicLinear.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net10.0-windows</TargetFramework><UseWPF>true</UseWPF><ImplicitUsings>enable</ImplicitUsings></PropertyGroup></Project>')
(p/'Program.cs').write_text('''using System.IO;using System.Text.Json;using System.Windows.Media;using System.Windows.Media.Imaging;
var root=Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)!;var directory=System.Environment.GetCommandLineArgs()[1];
var source=BitmapSource.Create(4,1,96,96,PixelFormats.Bgra32,null,new byte[]{0,0,255,255,0,255,0,255,255,0,0,255,128,128,128,255},16);
var converted=new ColorConvertedBitmap(source,new ColorContext(new Uri(Path.Combine(directory,"input.icc"))),new ColorContext(new Uri(Path.Combine(directory,"working.icc"))),PixelFormats.Bgra32);var pixels=new byte[16];converted.CopyPixels(pixels,16,0);var rgb=Enumerable.Range(0,12).Select(i=>pixels[i/3*4+2-i%3]/255d).ToArray();File.WriteAllText(Path.Combine(directory,"WIC.json"),JsonSerializer.Serialize(new{rgb,outputDomain="linear ROMM primaries D50 gamma1, raw8bit codes; original gray input128/255",engine="WindowsWIC",pixelFormat="BGRA32",scope="Independent system engine/quantized comparison, not physical display"}));
''')