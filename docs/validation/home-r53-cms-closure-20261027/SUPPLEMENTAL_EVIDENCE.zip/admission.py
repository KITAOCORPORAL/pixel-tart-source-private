from pathlib import Path
r=Path('N:/pixart/guangjing-r53-stage-b-20261027');v=r/'docs/validation/home-r53-cms-closure-20261027'
(v/'NODE_COMPARISON.md').write_text('''# CMS闭环变更准入记录（实施前）

继承前批 NODE_COMPARISON / PHOTOCRAFT_REFERENCE 的固定版本与许可证，不重复已验场景曝光/缓存/几何研究。

- JPEG：RGB float工作结果 → LCMS相对色度intent1/no-cache/no-opt0x140输出ICC → RGB16量化 → BGR8量化 → Windows WIC JPEG95/444，ICC只描述已经转换的输出码值。解码按未转换编码值比较；另统一到sRGB对照。参考Pillow12.3（PIL BSD-like，固定依赖）/libjpeg-turbo3.1.3@af9c1c268520a29adf98cad5138dafe612b3d318（IJG/BSD/zlib，研究编码不分发新codec），现有WIC为系统编码。保留旧MAE5/RMSE15门槛，用不同频率样例分离codec本身误差，不把标签当转换。
- 工作空间V2：显式linear ROMM/ProPhoto primaries D50，gamma1，float32；input/working/output三ICC身份+新Version2。仅线性曝光节点（BasicTone exposure其余为0）与几何/Normal有蒙版强度，其他旧encoded工具拒绝；旧V1encoded sRGB/PV4/5/6不迁。参考LCMS2.12@924a020d09bfe468c665467caf24aadeb41ff77c与RawTherapee5.12@a8a3d1bc7b419ed1c974c39276c97e618a4f9a1b iccstore，PhotoCraft7ac7b8b106acccf6826d45ed5c9e481dfe341035 profile/transform/pipeline作架构。MIT既有LCMS随包，GPL只研究不复制。先保持过范围float，输出才量化裁切；预览转换sRGB不进导出。
- 统一结果：profile字节/SHA、float32RGB、独立straight-alpha、原始方向/结果几何/版本ID。背景不明确不允许丢Alpha；V1旧白底仍标为兼容策略，不复用贴纸。出版重采样和水印明确在encoded-sRGB（float重采样，8bitWPF水印蒙版/颜色）域，最后转换输出ICC；不是线性光合成宣称。即时film输入完整冻结文档定义→相同float结果→明确转换sRGB，边框/配方解释sRGB，不读monitor。
- BlendV2：使用既有W3C/PDF .3/.59/.11非分离公式与SoftLight立方toe/sqrt，参考固定PhotoCraft psblend和ImageMagick7.1.2@既有REFERENCE及W3C公开公式，独立实现。不是Pillow不同SoftLight或darktable HSL。调整层effect完整结果再opacity*mask混合，Alpha不再乘一次；旧三模式不变。负/>1在V2 blend输入限制SDR，未受影响原HDR由caller插值保留，不声称scene/HDR混合。

数值/保存重开/输出/失败恢复必须由本批真实增量测试填入最终结果，不能以本文件作为通过证据。显示默认off、物理多屏/ACM/HDR未验保留。
''',encoding='utf-8')