from pathlib import Path
import subprocess,json,hashlib
out=Path('N:/pixart/Guangjing-R53-Home-20261027-CmsClosure');ref=out/'reference';ref.mkdir(exist_ok=True)
items=[('libjpeg-turbo/libjpeg-turbo','af9c1c268520a29adf98cad5138dafe612b3d318','src/jcapimin.c'),('libjpeg-turbo/libjpeg-turbo','af9c1c268520a29adf98cad5138dafe612b3d318','LICENSE.md')]
rows=[]
for repo,sha,file in items:
 p=ref/Path(file).name
 with p.open('wb') as f:subprocess.run(['gh','api',f'repos/{repo}/contents/{file}?ref={sha}','-H','Accept: application/vnd.github.raw+json'],stdout=f,check=True)
 rows.append(dict(repo=repo,sha=sha,file=file,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(out/'reference-manifest.json').write_text(json.dumps(rows,indent=2))