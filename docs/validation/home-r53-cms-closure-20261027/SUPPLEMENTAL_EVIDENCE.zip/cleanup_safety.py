from pathlib import Path
r=Path('N:/pixart/guangjing-r53-stage-b-20261027')
for f in ['src/RAWSelectionAssistant/Services/Publishing/WpfPublishingRenderer.cs','src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.InstantFilm.cs']:
 p=r/f;s=p.read_text(encoding='utf-8');p.write_text('\n'.join(line.rstrip() for line in s.splitlines())+'\n',encoding='utf-8')
# Publish render ownership cleanup never deletes a pre-existing user's file (already checked before own creation).
# Carry actual managed profile in the intermediate receipt too.
p=r/'src/RAWSelectionAssistant/ViewModels/ReferenceColorWorkspaceViewModel.cs';s=p.read_text(encoding='utf-8');s=s.replace('"TIFF orientation preserved","Not applied",RawDefinition:item.RawDefinition','"TIFF orientation preserved","Not applied",RawDefinition:item.RawDefinition');s=s.replace('null,null,"None","sRGB","TIFF orientation preserved"','null,null,"None",item.RawDefinition?.ColorState?.Output.Label??"sRGB","TIFF orientation preserved"');p.write_text(s,encoding='utf-8')
# Avoid reusing incompatible cache domain for V2 in public fast helper as well.
p=r/'src/RAWSelectionAssistant.Core/Services/Projects/ProfessionalRawLocalEdits.cs';s=p.read_text(encoding='utf-8');s=s.replace('''  var prepared=new Prepared(m,d,token);d=prepared.Definition;var current=basis?.Clone()''','''  if(d.ColorState?.Version==2)return DocumentWorkingRendererV2.Preview(m,d,800,token);
  var prepared=new Prepared(m,d,token);d=prepared.Definition;var current=basis?.Clone()''');p.write_text(s,encoding='utf-8')
# Explicit actual input contract for V2; not merely a string and never repeated WB.
p=r/'src/RAWSelectionAssistant/Services/DocumentColorWorkflowV1.cs';s=p.read_text(encoding='utf-8');s=s.replace('OutputSpace:"sRGB",WhiteBalanceApplied:false,CameraMatrixApplied:false,Gamma:"sRGB",Characterization:"Explicit embedded/assigned ICC converted once by LCMS;', 'OutputSpace:state.Version==2?DocumentWorkingRendererV2.Space:"sRGB",WhiteBalanceApplied:false,CameraMatrixApplied:false,Gamma:state.Version==2?"linear gamma1 D50":"sRGB",Characterization:"Explicit embedded/assigned ICC converted once by LCMS;');p.write_text(s,encoding='utf-8')