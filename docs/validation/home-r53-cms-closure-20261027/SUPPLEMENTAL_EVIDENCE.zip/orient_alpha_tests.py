from pathlib import Path
r=Path('N:/pixart/guangjing-r53-stage-b-20261027')
p=r/'src/RAWSelectionAssistant.Core/Services/Color/ControlledIcc/DocumentRenderResultV1.cs';s=p.read_text(encoding='utf-8');i=s.index(' public void Dispose()');s=s[:i]+''' public DocumentRenderResultV1 NormalizeOrientation(CancellationToken token=default)
 {
  int sw=Pixels.Width,sh=Pixels.Height;ushort orientation=Pixels.Orientation;int w=orientation>=5?sh:sw,h=orientation>=5?sw:sh;var rgb=new float[w*h*3];var alpha=Alpha.IsEmpty?null:new float[w*h];
  for(int y=0;y<h;y++){token.ThrowIfCancellationRequested();for(int x=0;x<w;x++){var (sx,sy)=orientation switch{2=>(sw-1-x,y),3=>(sw-1-x,sh-1-y),4=>(x,sh-1-y),5=>(y,x),6=>(y,sh-1-x),7=>(sw-1-y,sh-1-x),8=>(sw-1-y,x),_=>(x,y)};int source=(sy*sw+sx)*3,target=(y*w+x)*3;Pixels.Rgb32.Span.Slice(source,3).CopyTo(rgb.AsSpan(target));if(alpha is not null)alpha[y*w+x]=Alpha.Span[sy*sw+sx];}}
  return new(new(w,h,rgb,"32f",Pixels.WorkingColorSpace,1),Profile,EditVersionId,GeometryIdentity+"/Upright",alpha is null?default:alpha);
 }
'''+s[i:];p.write_text(s,encoding='utf-8')
p=r/'src/RAWSelectionAssistant/Services/Publishing/WpfPublishingRenderer.ManagedColor.cs';s=p.read_text(encoding='utf-8').replace('input.RequireOpaque();\n  var size=OutputSize(input.Pixels.Width,input.Pixels.Height','input.RequireOpaque();using var upright=input.NormalizeOrientation(token);\n  var size=OutputSize(upright.Pixels.Width,upright.Pixels.Height').replace('ResizeRgb48(input.Pixels,size.Width','ResizeRgb48(upright.Pixels,size.Width');s=s.replace('var size=OutputSize(input.PixelWidth,input.PixelHeight,options.EffectiveDimensions);','var orientation=ReadOrientation(input);var size=OutputSize(orientation>=5?input.PixelHeight:input.PixelWidth,orientation>=5?input.PixelWidth:input.PixelHeight,options.EffectiveDimensions);');p.write_text(s,encoding='utf-8')
p=r/'src/RAWSelectionAssistant/Services/Publishing/WpfPublishingRenderer.cs';s=p.read_text(encoding='utf-8').replace('var values=document.Pixels.Rgb32.Span;var alpha=document.Alpha.Span;var b=new byte[document.Pixels.PixelCount*4];for(int i=0;i<document.Pixels.PixelCount;i++)','using var upright=document.NormalizeOrientation(cancellationToken);var values=upright.Pixels.Rgb32.Span;var alpha=upright.Alpha.Span;var b=new byte[upright.Pixels.PixelCount*4];for(int i=0;i<upright.Pixels.PixelCount;i++)').replace('BitmapSource.Create(document.Pixels.Width,document.Pixels.Height,96,96,PixelFormats.Pbgra32,null,b,document.Pixels.Width*4)','BitmapSource.Create(upright.Pixels.Width,upright.Pixels.Height,96,96,PixelFormats.Pbgra32,null,b,upright.Pixels.Width*4)');p.write_text(s,encoding='utf-8')
# Two new core tests describe linear exposure and independent-alpha semantics without new UI assumptions.
p=r/'tests/RAWSelectionAssistant.Tests/R53CmsClosureCoreTests.cs';p.write_text('''using RAWSelectionAssistant.Core.Services.Color;
using RAWSelectionAssistant.Core.Services.Color.ControlledIcc;
using RAWSelectionAssistant.Core.Services.Projects;
namespace RAWSelectionAssistant.Tests;
[TestClass]public sealed class R53CmsClosureCoreTests
{
 [TestMethod]public void NewBlendsFiniteBoundedAndOpacityZeroPreservesHdrLegacyModes()
 {
  using var source=new HighBitDepthImageBuffer(4,1,new float[]{-.5f,1.3f,.2f,.3f,.5f,.7f,0,0,0,1,1,1});using var effect=new HighBitDepthImageBuffer(4,1,new float[]{1.5f,-.2f,.8f,.7f,.2f,.1f,.3f,.6f,.9f,.8f,.6f,.4f});
  foreach(var mode in new[]{StudioLayerBlend.Overlay,StudioLayerBlend.SoftLight,StudioLayerBlend.Color,StudioLayerBlend.Luminosity})
  {var node=new ColorAdjustmentStackNode(Guid.NewGuid(),ColorStudioNodeType.BasicTone,"admitted"){CompositeVersion=2,Blend=mode,Opacity=0};using(var identity=StudioLayerComposite.Apply(source,effect,node))CollectionAssert.AreEqual(source.Rgb32.ToArray(),identity.Rgb32.ToArray());using var result=StudioLayerComposite.Apply(source,effect,node with{Opacity=.5,LocalMask=new([new([new(.5,.5)],.8,.8,.7,1)])});Assert.IsTrue(result.Rgb32.ToArray().All(float.IsFinite));var mix=PhotographicBlendV2.Blend(new(-.5,1.3,.2),new(1.5,-.2,.8),mode);Assert.IsTrue(new[]{mix.X,mix.Y,mix.Z}.All(x=>x>=-1e-12&&x<=1+1e-12));}
  foreach(var mode in new[]{StudioLayerBlend.Normal,StudioLayerBlend.Multiply,StudioLayerBlend.Screen}){var node=new ColorAdjustmentStackNode(Guid.NewGuid(),ColorStudioNodeType.BasicTone,"legacy"){CompositeVersion=1,Blend=mode,Opacity=.3};using var actual=StudioLayerComposite.Apply(source,effect,node);for(int i=0;i<source.Rgb32.Length;i++){float a=source.Rgb32.Span[i],b=effect.Rgb32.Span[i];double mixed=mode switch{StudioLayerBlend.Multiply=>a*b,StudioLayerBlend.Screen=>1-(1-a)*(1-b),_=>b};Assert.AreEqual((float)(a+(mixed-a)*.3),actual.Rgb32.Span[i],0);}}
 }
 [TestMethod]public void IndependentAlphaOrientationKeepsStraightValuesWithoutBackgroundFlatten()
 {
  using var cms=new LcmsRgbEngine();using var document=new DocumentRenderResultV1(new(2,1,new float[]{.8f,.1f,.2f,.2f,.7f,.3f},orientation:6),cms.StandardProfile("sRGB"),Guid.NewGuid(),"EXIF6",new float[]{.25f,0});using var upright=document.NormalizeOrientation();Assert.AreEqual(1,upright.Pixels.Width);Assert.AreEqual(2,upright.Pixels.Height);CollectionAssert.AreEqual(document.Pixels.Rgb32.ToArray(),upright.Pixels.Rgb32.ToArray());CollectionAssert.AreEqual(new float[]{.25f,0},upright.Alpha.ToArray());Assert.Throws<NotSupportedException>(()=>upright.RequireOpaque());
 }
}
''',encoding='utf-8')