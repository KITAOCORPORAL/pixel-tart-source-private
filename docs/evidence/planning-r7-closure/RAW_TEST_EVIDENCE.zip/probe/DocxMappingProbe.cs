using System.Runtime.InteropServices;
using System.Text;
namespace RAWSelectionAssistant.Services;
internal static class DocxMappingProbe
{
 [StructLayout(LayoutKind.Sequential)] struct Mbi{public IntPtr BaseAddress,AllocationBase;public uint AllocationProtect;public ushort PartitionId;public UIntPtr RegionSize;public uint State,Protect,Type;}
 [DllImport("kernel32.dll")]static extern UIntPtr VirtualQuery(IntPtr p,out Mbi b,UIntPtr size);
 [DllImport("psapi.dll",CharSet=CharSet.Unicode)]static extern uint GetMappedFileName(IntPtr process,IntPtr address,StringBuilder path,uint size);
 internal static string[] Maps(string file){var result=new List<string>();long address=0;while(VirtualQuery((IntPtr)address,out var b,(UIntPtr)Marshal.SizeOf<Mbi>())!=UIntPtr.Zero){if(b.Type==0x40000||b.Type==0x1000000){var path=new StringBuilder(2048);if(GetMappedFileName(System.Diagnostics.Process.GetCurrentProcess().Handle,b.BaseAddress,path,2048)>0&&path.ToString().Contains(System.IO.Path.GetFileName(file)))result.Add(path.ToString());}var next=b.BaseAddress.ToInt64()+(long)b.RegionSize.ToUInt64();if(next<=address)break;address=next;}return result.ToArray();}
}
