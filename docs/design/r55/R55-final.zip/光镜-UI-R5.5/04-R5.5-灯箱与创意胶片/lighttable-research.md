# 观片灯箱调研（R5.5）
- 专业观片灯/灯箱使用 5000K（D50）光源，这是印刷与摄影的行业标准中性色温，保证换一台灯箱看起来一致。来源：B&H 灯箱目录 https://static.bhphotovideo.com/FrameWork/Product_Resources/SourceBookProPhoto/Section10Lightboxes.pdf
- 面板为防眩、耐刮的乳白亚克力（磨砂扩散板）：关灯时是哑光偏暖的白色板，开灯时整面均匀发光、无热点、无投影。来源：https://www.kaiser-fototechnik.de/en/produkte/artikel.php?nr=2453 、https://www.bhphotovideo.com/c/product/1325594-REG/kaiser_202453_slimlite_plano_5000k_battery.html
- 典型规格：5000K、CRI 95、亮度约 750 cd/m²，可调光（为了舒适观看）。来源：Kaiser slimlite plano 页面（同上）
- 发光区四周是一圈窄边框（金属/银色或深色），边框上常印 cm/inch 刻度；发光区边缘均匀到边。来源：Kaiser、B&H（同上）
- 用法：幻灯片（白色或黑色片框）、负片条、反转片平放在发光面上排序挑选；配合 4×–10× 放大镜（loupe）直接放在片子上看细节。来源：https://acephoto.net/accessories/darkroom-equipment/lightboxes-loupes-and-slide-viewers/
- 大型观片台可加「片框压条/覆板」整排夹住幻灯片（如 Accustand Slide Overlay，72 张）。来源：B&H 目录 PDF（同上）
- 设计结论：开灯 = 近白 #FBFBF7 均匀面 + 窄深色边框，片子用黑色片框，文字落在片框上；关灯 = 哑光米白 #DEDBD3，卡片如相纸/片框，只有极淡接触阴影；四周软件界面保持深色，避免刺眼。
